# Source Target Recon

> **Going live?** Follow [DEPLOY.md](DEPLOY.md). It has step-by-step instructions for Linux + nginx, Docker and Windows, plus the go-live checklist.

A multi-user web app for comparing source and target data. Everyone signs in at one URL with their own account.

**What it does**

- **Compare records:** column-wise match of source vs target, with TRUE/FALSE flags and an Excel export.
- **Statistics:** sum, mean, median, min, max and more, source vs target.
- **Data quality:** null validation and duplicate validation.
- **Code compare:** paste two pieces of code side by side and see the differences.
- **DDL compare:** paste or load CREATE TABLE statements (Hive, Spark, Oracle, SQL Server, Postgres, MySQL, Teradata). Columns, types, nullability, defaults, partitions, storage format and TBLPROPERTIES are compared table by table.
- **JSON compare:** paste or load two JSON documents (or JSON Lines). Every difference is listed by path, with options to ignore array order, match array items by a key, and ignore keys.
- **Trends:** monthly SUM of selected CDEs, source against target, with graphs for increasing, decreasing and unusual changes over time.
- **Audit report:** every run's systems, executed queries, timestamps, result and discrepancies, with an Excel audit report. Every reconciliation report carries an Audit sheet.

**Downloads:** after a compare, a bar under the results lets you type your own report name. Today's date is added automatically, e.g. `customer_recon_2026-10-20.xlsx`, and the app remembers your last name per tool.

**Each user gets their own space**

- **Team history:** every run is saved under the name of the person who ran it. Anyone on the team can open it and download the report. Runs are deleted automatically after 7 days (`RECON_RETENTION_DAYS`).
- **Saved Excel reports:** download any past report again.
- **Rule presets:** save key columns, null and duplicate rules and options, then reapply them to new files.

**Admins** can add users, reset passwords, enable or disable accounts, and see everyone's runs and activity.

Uploaded files are compared inside each user's browser. Only the results (summary and Excel report) are stored on the server.

---

## 1. Install

You need Python 3.9 or later.

```bash
cd recon_app
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### Excel library (one-time)

The page needs `xlsx.bundle.js` (the SheetJS build with cell styling, which produces the colored Excel files).

If your network can reach jsDelivr, the page loads it automatically. On a closed internal network, download it once and put it in `static/`:

```
https://cdn.jsdelivr.net/npm/xlsx-js-style@1.2.0/dist/xlsx.bundle.js   →   static/xlsx.bundle.js
```

## 2. First start

```bash
export RECON_ADMIN_PASSWORD='ChooseAStrongOne'   # optional; otherwise one is generated and printed
python app.py                                     # http://127.0.0.1:5000
```

The first start creates the admin account and prints its username and password. The admin is asked to set a new password at first sign-in.

## 3. Add users

1. Sign in as admin and open the **Admin** tab.
2. Create a user. A temporary password is shown.
3. Share the temporary password privately. Users must change it at first sign-in.

## 4. Run for everyone (production)

```bash
pip install waitress
export RECON_SECRET_KEY='long-random-string'   # keeps sessions valid across restarts
waitress-serve --host 0.0.0.0 --port 8080 app:app
```

Colleagues then open `http://<your-server>:8080`.

Put it behind your HTTPS reverse proxy (nginx or IIS) and set `RECON_HTTPS=1` so the session cookie is only sent over HTTPS. If the proxy has an upload limit, raise it to match `RECON_MAX_UPLOAD_MB`.

## Settings (environment variables)

| Variable | Default | Purpose |
|---|---|---|
| `RECON_DATA_DIR` | `./data` | Where the SQLite database and saved reports live. Back this folder up. |
| `RECON_SECRET_KEY` | auto-generated in `data/secret.key` | Session signing key |
| `RECON_ADMIN_USER` / `RECON_ADMIN_PASSWORD` | `admin` / random | First admin account (used only when the database is empty) |
| `RECON_HTTPS` | `0` | Set to `1` behind HTTPS |
| `RECON_MAX_UPLOAD_MB` | `100` | Largest Excel report that can be saved |
| `RECON_HOST` / `RECON_PORT` | `127.0.0.1` / `5000` | Only used by `python app.py` |

## Files

```
app.py              Flask server: sign-in, users, history, reports, presets, admin
templates/login.html
templates/index.html  the Recon screens
static/app.js       history, presets, admin and password screens
static/logo.png     login logo (replace with any PNG)
data/               created at first start: recon.db, reports/, secret.key
```

## Security notes

- **Passwords:** hashed with Werkzeug (scrypt or pbkdf2) and never stored in plain text.
- **Lockout:** an account is locked for 5 minutes after 5 failed sign-ins.
- **CSRF:** every change goes through a CSRF token check.
- **Report access:** users can only open their own runs and reports. Admins can open all of them.

To use company single sign-on instead of local passwords, put the app behind your SSO proxy and replace the `login()` route with a check on the header your proxy sets.

## Next step for very large files

Today the comparison runs in the browser, which comfortably handles files up to a few hundred thousand rows.

For bigger loads, add a `/api/compare` endpoint that does the same match with pandas, or with Spark over Hive tables. Then have the page send table names instead of files.
