"""Job monitoring dashboard backend (TWS job schedule table).

Run:  pip install fastapi uvicorn pyhive thrift sasl thrift_sasl itsdangerous
      uvicorn app:app --host 0.0.0.0 --port 8000
"""
import os
import time
import hmac
from typing import Optional

from fastapi import FastAPI, Query, Request, Form, Depends, HTTPException
from fastapi.responses import FileResponse, RedirectResponse
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from pyhive import hive

# ---- CONFIG: edit these (or set env vars) ---------------------------------
HIVE_HOST = os.getenv("HIVE_HOST", "localhost")
HIVE_PORT = int(os.getenv("HIVE_PORT", "10000"))
HIVE_USER = os.getenv("HIVE_USER", "hive")
HIVE_DB = os.getenv("HIVE_DB", "default")
TABLE = os.getenv("JOB_TABLE", "tws_job_details")

# ---- Auth config ------------------------------------------------------
# Set real values via environment variables in production - do not ship
# the defaults below. Generate SESSION_SECRET with: openssl rand -hex 32
APP_USERNAME = os.getenv("APP_USERNAME", "admin")
APP_PASSWORD = os.getenv("APP_PASSWORD", "changeme")
SESSION_SECRET = os.getenv("SESSION_SECRET", "dev-only-change-me")
SESSION_MAX_AGE = 8 * 60 * 60  # 8 hour login
COOKIE_NAME = "job_dashboard_session"

_signer = URLSafeTimedSerializer(SESSION_SECRET, salt="job-dashboard-auth")


def _check_credentials(username: str, password: str) -> bool:
    return hmac.compare_digest(username, APP_USERNAME) and hmac.compare_digest(password, APP_PASSWORD)


def _current_user(request: Request) -> Optional[str]:
    token = request.cookies.get(COOKIE_NAME)
    if not token:
        return None
    try:
        return _signer.loads(token, max_age=SESSION_MAX_AGE)
    except (BadSignature, SignatureExpired):
        return None


def require_login(request: Request):
    user = _current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    return user

# Column mapping — matches the TWS job table screenshot.
# Change the right-hand side to your ACTUAL Hive column names if they differ.
COL = {
    "sr_no": "sr_no",                    # Sr. No.
    "environment": "environment",        # Environment — known values: OSH, P2, AWS
    "job_stream": "job_stream_name",     # Job Stream Name
    "job": "job_name",                   # Job Name
    "frequency": "frequency",            # Frequency
    "exec_day": "execution_day",         # Execution Day
    "exec_time": "execution_time",       # Execution Time
    "status": "status",                  # Status (SUCCESS / FAILED / ...)
    "updated_by": "updated_by",          # Updated By
    "last_updated": "last_updated",      # Last Updated (timestamp) — used for date filtering
}
# ---------------------------------------------------------------------------

app = FastAPI(title="TWS Jobs Dashboard")
_cache: dict = {}
CACHE_TTL = 60  # seconds; Hive is slow, so cache results briefly


def run_query(sql: str, params: Optional[dict] = None):
    key = (sql, tuple(sorted((params or {}).items())))
    hit = _cache.get(key)
    if hit and time.time() - hit[0] < CACHE_TTL:
        return hit[1]
    conn = hive.Connection(host=HIVE_HOST, port=HIVE_PORT,
                           username=HIVE_USER, database=HIVE_DB)
    try:
        cur = conn.cursor()
        cur.execute(sql, params)
        cols = [c[0].split(".")[-1] for c in cur.description]
        rows = [dict(zip(cols, r)) for r in cur.fetchall()]
    finally:
        conn.close()
    _cache[key] = (time.time(), rows)
    return rows


def where(days: int, environment: Optional[str], job_stream: Optional[str]):
    clause = f"WHERE to_date({COL['last_updated']}) >= date_sub(current_date, {int(days)})"
    params = {}
    if environment and environment != "all":
        clause += f" AND {COL['environment']} = %(environment)s"
        params["environment"] = environment
    if job_stream and job_stream != "all":
        clause += f" AND {COL['job_stream']} = %(job_stream)s"
        params["job_stream"] = job_stream
    return clause, params


@app.get("/login")
def login_page():
    return FileResponse("login.html")


@app.post("/login")
def login_submit(username: str = Form(...), password: str = Form(...)):
    if not _check_credentials(username, password):
        return RedirectResponse(url="/login?error=1", status_code=303)
    token = _signer.dumps(username)
    resp = RedirectResponse(url="/", status_code=303)
    resp.set_cookie(COOKIE_NAME, token, max_age=SESSION_MAX_AGE, httponly=True, samesite="lax")
    return resp


@app.get("/logout")
def logout():
    resp = RedirectResponse(url="/login", status_code=303)
    resp.delete_cookie(COOKIE_NAME)
    return resp


@app.get("/")
def index(request: Request):
    if not _current_user(request):
        return RedirectResponse(url="/login")
    return FileResponse("index.html")


@app.get("/api/environments")
def environments(user: str = Depends(require_login)):
    sql = f"SELECT DISTINCT {COL['environment']} AS environment FROM {TABLE} ORDER BY environment"
    return [r["environment"] for r in run_query(sql)]


@app.get("/api/job-streams")
def job_streams(user: str = Depends(require_login)):
    sql = f"SELECT DISTINCT {COL['job_stream']} AS job_stream FROM {TABLE} ORDER BY job_stream"
    return [r["job_stream"] for r in run_query(sql)]


@app.get("/api/summary")
def summary(days: int = Query(7, ge=1, le=365), environment: Optional[str] = None,
            job_stream: Optional[str] = None, user: str = Depends(require_login)):
    w, p = where(days, environment, job_stream)
    sql = f"""
        SELECT COUNT(*) AS total,
               SUM(CASE WHEN upper({COL['status']})='SUCCESS' THEN 1 ELSE 0 END) AS success,
               SUM(CASE WHEN upper({COL['status']})='FAILED'  THEN 1 ELSE 0 END) AS failed
        FROM {TABLE} {w}"""
    return run_query(sql, p)[0]


@app.get("/api/by-environment")
def by_environment(days: int = Query(7, ge=1, le=365), environment: Optional[str] = None,
                    job_stream: Optional[str] = None, user: str = Depends(require_login)):
    w, p = where(days, environment, job_stream)
    sql = f"""
        SELECT {COL['environment']} AS environment,
               SUM(CASE WHEN upper({COL['status']})='SUCCESS' THEN 1 ELSE 0 END) AS success,
               SUM(CASE WHEN upper({COL['status']})='FAILED'  THEN 1 ELSE 0 END) AS failed
        FROM {TABLE} {w}
        GROUP BY {COL['environment']} ORDER BY failed DESC"""
    return run_query(sql, p)


@app.get("/api/by-job-stream")
def by_job_stream(days: int = Query(7, ge=1, le=365), environment: Optional[str] = None,
                   job_stream: Optional[str] = None, user: str = Depends(require_login)):
    w, p = where(days, environment, job_stream)
    sql = f"""
        SELECT {COL['job_stream']} AS job_stream,
               SUM(CASE WHEN upper({COL['status']})='SUCCESS' THEN 1 ELSE 0 END) AS success,
               SUM(CASE WHEN upper({COL['status']})='FAILED'  THEN 1 ELSE 0 END) AS failed
        FROM {TABLE} {w}
        GROUP BY {COL['job_stream']} ORDER BY failed DESC LIMIT 12"""
    return run_query(sql, p)


@app.get("/api/trend")
def trend(days: int = Query(7, ge=1, le=365), environment: Optional[str] = None,
          job_stream: Optional[str] = None, user: str = Depends(require_login)):
    w, p = where(days, environment, job_stream)
    sql = f"""
        SELECT to_date({COL['last_updated']}) AS day,
               SUM(CASE WHEN upper({COL['status']})='SUCCESS' THEN 1 ELSE 0 END) AS success,
               SUM(CASE WHEN upper({COL['status']})='FAILED'  THEN 1 ELSE 0 END) AS failed
        FROM {TABLE} {w}
        GROUP BY to_date({COL['last_updated']}) ORDER BY day"""
    return [{**r, "day": str(r["day"])} for r in run_query(sql, p)]


@app.get("/api/top-failing")
def top_failing(days: int = Query(7, ge=1, le=365), environment: Optional[str] = None,
                 job_stream: Optional[str] = None, user: str = Depends(require_login)):
    w, p = where(days, environment, job_stream)
    sql = f"""
        SELECT {COL['job']} AS job, {COL['job_stream']} AS job_stream, COUNT(*) AS failures
        FROM {TABLE} {w} AND upper({COL['status']})='FAILED'
        GROUP BY {COL['job']}, {COL['job_stream']}
        ORDER BY failures DESC LIMIT 10"""
    return run_query(sql, p)


@app.get("/api/recent")
def recent(days: int = Query(7, ge=1, le=365), environment: Optional[str] = None,
           job_stream: Optional[str] = None, status: Optional[str] = None,
           limit: int = Query(200, le=1000), user: str = Depends(require_login)):
    w, p = where(days, environment, job_stream)
    if status and status != "all":
        w += f" AND upper({COL['status']}) = %(status)s"
        p["status"] = status.upper()
    sql = f"""
        SELECT {COL['sr_no']} AS sr_no, {COL['environment']} AS environment,
               {COL['job_stream']} AS job_stream, {COL['job']} AS job,
               {COL['frequency']} AS frequency, {COL['exec_day']} AS exec_day,
               {COL['exec_time']} AS exec_time, {COL['status']} AS status,
               {COL['updated_by']} AS updated_by, {COL['last_updated']} AS last_updated
        FROM {TABLE} {w} ORDER BY {COL['last_updated']} DESC LIMIT {int(limit)}"""
    return [{k: (str(v) if v is not None else None) for k, v in r.items()}
            for r in run_query(sql, p)]
