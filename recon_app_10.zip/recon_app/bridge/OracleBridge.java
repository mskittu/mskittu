import java.io.*;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.sql.*;

/**
 * Runs ONE read-only query through a JDBC driver (the ojdbc driver that ships with SQL Developer)
 * and prints the result as JSON lines. Used by Source Target Recon when python-oracledb is not installed.
 *
 * stdin  : url \n user \n password \n timeoutSeconds \n maxRows \n SQL (rest of input)
 * stdout : {"columns":[...]} then one JSON array per row, then {"done":true,"truncated":..,"rows":n}
 * errors : message on stderr, exit code 3 (database) or 2 (usage)
 */
public class OracleBridge {
    public static void main(String[] args) throws Exception {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        String url = in.readLine(), user = in.readLine(), password = in.readLine();
        String timeoutS = in.readLine(), maxS = in.readLine();
        if (url == null || user == null || password == null || timeoutS == null || maxS == null) {
            System.err.println("usage: url, user, password, timeout, maxRows and SQL on stdin"); System.exit(2);
        }
        StringBuilder sb = new StringBuilder(); String line;
        while ((line = in.readLine()) != null) sb.append(line).append('\n');
        String sql = sb.toString().trim();
        while (sql.endsWith(";")) sql = sql.substring(0, sql.length() - 1).trim();
        int timeout = Integer.parseInt(timeoutS.trim()), maxRows = Integer.parseInt(maxS.trim());
        PrintStream out = new PrintStream(new BufferedOutputStream(new FileOutputStream(FileDescriptor.out), 1 << 16), false, "UTF-8");
        try { Class.forName("oracle.jdbc.OracleDriver"); } catch (Throwable ignore) { /* driver registers itself */ }
        DriverManager.setLoginTimeout(Math.min(60, Math.max(5, timeout)));
        try (Connection c = DriverManager.getConnection(url, user, password)) {
            try { c.setReadOnly(true); } catch (SQLException ignore) { }
            try (Statement st = c.createStatement()) {
                if (url.startsWith("jdbc:oracle:")) st.execute("SET TRANSACTION READ ONLY");
                st.setQueryTimeout(timeout);
                st.setFetchSize(5000);
                try (ResultSet rs = st.executeQuery(sql)) {
                    ResultSetMetaData md = rs.getMetaData();
                    int n = md.getColumnCount();
                    int[] types = new int[n];
                    StringBuilder h = new StringBuilder("{\"columns\":[");
                    for (int i = 1; i <= n; i++) {
                        types[i - 1] = md.getColumnType(i);
                        if (i > 1) h.append(',');
                        h.append(js(md.getColumnLabel(i)));
                    }
                    out.println(h.append("]}"));
                    int count = 0; boolean truncated = false;
                    while (rs.next()) {
                        if (count >= maxRows) { truncated = true; break; }
                        StringBuilder r = new StringBuilder("[");
                        for (int i = 1; i <= n; i++) {
                            if (i > 1) r.append(',');
                            r.append(js(value(rs, i, types[i - 1])));
                        }
                        out.println(r.append(']'));
                        count++;
                    }
                    out.println("{\"done\":true,\"truncated\":" + truncated + ",\"rows\":" + count + "}");
                }
            } finally {
                try { c.rollback(); } catch (SQLException ignore) { }
            }
        } catch (SQLException e) {
            out.flush();
            String m = e.getMessage() == null ? e.toString() : e.getMessage();
            System.err.println(m.split("\\R")[0]);
            System.exit(3);
        }
        out.flush();
    }

    static String value(ResultSet rs, int i, int type) throws SQLException {
        switch (type) {
            case Types.NUMERIC: case Types.DECIMAL: case Types.INTEGER: case Types.BIGINT: case Types.SMALLINT:
            case Types.TINYINT: case Types.DOUBLE: case Types.FLOAT: case Types.REAL: {
                BigDecimal b = rs.getBigDecimal(i);
                if (b == null) return null;
                b = b.stripTrailingZeros();
                return (b.scale() < 0 ? b.setScale(0) : b).toPlainString();
            }
            case Types.DATE: case Types.TIMESTAMP: case Types.TIMESTAMP_WITH_TIMEZONE: case -101: case -102: {
                Timestamp t = rs.getTimestamp(i);
                if (t == null) return null;
                String s = t.toString();                       // yyyy-mm-dd hh:mm:ss.fffffffff
                return t.getNanos() == 0 ? s.substring(0, 19) : s.replaceAll("0+$", "");
            }
            case Types.BLOB: case Types.BINARY: case Types.VARBINARY: case Types.LONGVARBINARY:
                return rs.getObject(i) == null ? null : "(binary)";
            default:
                return rs.getString(i);
        }
    }

    static String js(String s) {
        if (s == null) return "null";
        StringBuilder b = new StringBuilder(s.length() + 2).append('"');
        for (int k = 0; k < s.length(); k++) {
            char ch = s.charAt(k);
            switch (ch) {
                case '"': b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                default:
                    if (ch < 0x20) b.append(String.format("\\u%04x", (int) ch)); else b.append(ch);
            }
        }
        return b.append('"').toString();
    }
}
