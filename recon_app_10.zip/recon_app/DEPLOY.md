# Source Target Recon: go-live guide

This guide takes the app from the zip file to a live HTTPS website that the whole data engineering team signs in to.

Pick **one** hosting option in step 4. Option A (a Linux server with nginx) is recommended.

---

## 1. How it works

```
 Browser (each user)                 Server (your project)                        Storage / systems
 ───────────────────                 ─────────────────────                        ─────────────────
 Picks connections, types   HTTPS    nginx / IIS  ──►  Waitress  ──►  Flask app    SQLite: data/recon.db
 SQL, compares results,  ◄────────►  (TLS, port 443)   (port 8080)    (app.py)     Reports: data/reports/
 builds Excel reports                                                 │
                                                                      └─ read-only SELECT ─► Hive · Oracle
                                                                                             Athena · Redshift
```

- **Query mode (the main way to use it):** a user picks a source connection (e.g. Hive or Oracle) and a target connection (e.g. AWS Athena or Redshift), and types one SELECT per side. The server runs both queries **at the same time, read-only, with a time limit and a row limit**, then sends the two result sets to the browser, where they're compared column by column. Section 11 explains how to connect each system.
- **File mode** is still there for one-off checks. Uploaded files never leave the user's browser.
- **The server stores:**
  - user accounts (passwords are hashed)
  - connection settings (hosts, databases, credential *references*, never passwords)
  - run history (summaries and SQL text) and each run's Excel report, for 7 days
  - audit records (who, when, which systems, which SQL, result), for 365 days
  - rule presets
  - an activity log, for 90 days
- **Query results are not stored.** They pass through the server's memory to the browser and are compared there.
- **Team history** shows every run from the last 7 days with the name of the person who ran it. Anyone signed in can open a run and download its report. Runs older than `RECON_RETENTION_DAYS` (default 7) are deleted automatically, Excel file included: the app checks every hour and at start-up.
- **One Python process** (Waitress) serves the app. A reverse proxy in front of it handles HTTPS.

## 2. What you need

| Item | Recommended |
|---|---|
| Server | Linux VM (RHEL 8/9 or Ubuntu 22.04+), or Windows Server 2019+ |
| Size | 2 vCPU, 4 GB RAM, 20 GB disk for the data folder (grows with saved reports) |
| Python | **3.11** (tested on 3.11.16 / 3.11.17), with `venv` and `pip` (or Docker instead) |
| Network | A DNS name, e.g. `recon.<your-domain>`, and port 443 open from the corporate network |
| Certificate | TLS certificate and key for that DNS name from your internal CA |
| Approvals | Info-security review and data-classification sign-off. Saved reports can contain row-level values (see section 9). |
| Packages | Access to PyPI, or your internal Artifactory/Nexus mirror |

## 3. Add the Excel library (one-time, required)

The page needs `static/xlsx.bundle.js` (SheetJS with cell styling) to build the colored Excel files. Bank networks often block public CDNs, so ship this file with the app.

**Option A: from a machine with internet access.** Download this URL and save it as `recon_app/static/xlsx.bundle.js`:

```
https://cdn.jsdelivr.net/npm/xlsx-js-style@1.2.0/dist/xlsx.bundle.js
```

**Option B: through your internal npm mirror (Artifactory/Nexus).**

```bash
npm pack xlsx-js-style@1.2.0            # uses your configured registry
tar -xzf xlsx-js-style-1.2.0.tgz package/dist/xlsx.bundle.js
cp package/dist/xlsx.bundle.js recon_app/static/xlsx.bundle.js
```

If the file is missing and the CDN is blocked, the app still works, but it shows a red banner and the Excel downloads are switched off.

> **Fonts:** the page uses Google Fonts (Sora, Manrope, JetBrains Mono). If those are blocked, it falls back to the system fonts automatically, so no action is needed.

---

## 4A. Linux server with nginx (recommended)

### 4A.1 Create the folders and service user

```bash
sudo useradd --system --home /opt/recon --shell /sbin/nologin recon
sudo mkdir -p /opt/recon/app /opt/recon/data /opt/recon/backups
```

### 4A.2 Copy the app

```bash
unzip recon_app.zip
sudo cp -r recon_app/. /opt/recon/app/          # the "/." also copies .env.example
cd /opt/recon/app
```

### 4A.3 Install Python packages

```bash
sudo python3.11 -m venv .venv
sudo .venv/bin/pip install -r requirements.txt -r requirements-connectors.txt
# behind a mirror:  sudo .venv/bin/pip install -r requirements.txt --index-url https://artifactory.<your-domain>/api/pypi/pypi/simple
```

### 4A.4 Configure

```bash
sudo cp .env.example .env
python3 -c "import secrets; print(secrets.token_hex(32))"   # paste the output as RECON_SECRET_KEY
sudo vi .env
```

Set at least the following in `.env`:

```
RECON_SECRET_KEY=<the long random string>
RECON_ADMIN_USER=admin
RECON_ADMIN_PASSWORD=<a strong temporary password>
RECON_DATA_DIR=/opt/recon/data
RECON_HTTPS=1
RECON_BEHIND_PROXY=1
RECON_RETENTION_DAYS=7
```

Then lock down the permissions:

```bash
sudo chown -R recon:recon /opt/recon
sudo chmod 600 /opt/recon/app/.env
```

### 4A.5 Trial run

```bash
sudo -u recon /opt/recon/app/.venv/bin/waitress-serve --host 127.0.0.1 --port 8080 app:app
# in a second terminal:
curl http://127.0.0.1:8080/healthz        # → {"status":"ok"}
```

The first start prints `First admin account created: admin / ...`. Press Ctrl+C to stop the trial.

### 4A.6 Run as a service

```bash
sudo cp /opt/recon/app/deploy/recon.service /etc/systemd/system/recon.service
sudo systemctl daemon-reload
sudo systemctl enable --now recon
sudo systemctl status recon
journalctl -u recon -f                     # live logs
```

### 4A.7 HTTPS with nginx

```bash
sudo dnf install nginx        # Ubuntu: sudo apt install nginx
sudo cp /opt/recon/app/deploy/nginx.conf /etc/nginx/conf.d/recon.conf
sudo vi /etc/nginx/conf.d/recon.conf      # set server_name and the certificate paths
sudo nginx -t && sudo systemctl enable --now nginx && sudo systemctl reload nginx
```

On RHEL with SELinux and firewalld, also run:

```bash
sudo setsebool -P httpd_can_network_connect 1
sudo firewall-cmd --permanent --add-service=https && sudo firewall-cmd --reload
```

**To host under a sub-path** (e.g. `https://tools.<your-domain>/recon/`): use the commented `location /recon/` block in `nginx.conf`. The app picks up the prefix automatically.

### 4A.8 Nightly backup

```bash
sudo dnf install sqlite        # Ubuntu: sudo apt install sqlite3
sudo crontab -u recon -e
# add:
30 2 * * * /opt/recon/app/deploy/backup.sh >> /opt/recon/backups/backup.log 2>&1
```

---

## 4B. Docker / OpenShift / Kubernetes

1. Add `static/xlsx.bundle.js` (step 3), then build and run:

   ```bash
   cd recon_app
   cp .env.example .env && vi .env           # set RECON_SECRET_KEY and RECON_ADMIN_PASSWORD; RECON_DATA_DIR is set to /data
   docker compose up -d --build
   curl http://localhost:8080/healthz
   ```

2. Keep the `/data` volume on persistent storage. In Kubernetes, use a PersistentVolumeClaim and **exactly 1 replica**, because SQLite is a single-writer database.
3. Put your ingress or route in front with TLS, and set `RECON_BEHIND_PROXY=1` and `RECON_HTTPS=1`.
4. Point liveness and readiness probes at `GET /healthz`.

---

## 4C. Windows Server

1. Install Python 3.11 (tick "Add to PATH").
2. Unzip to `D:\Recon\app`, then add `static\xlsx.bundle.js` (step 3).
3. Install the packages:

   ```bat
   cd /d D:\Recon\app
   py -3.11 -m venv .venv
   .venv\Scripts\pip install -r requirements.txt
   copy .env.example .env
   notepad .env
   ```

   Set `RECON_DATA_DIR=D:\Recon\data`.
4. Do a trial run with `deploy\run_windows.bat`, then open `http://localhost:8080`.
5. Run it as a service with [NSSM](https://nssm.cc). The commands are at the top of `run_windows.bat`.
6. **HTTPS:** in IIS, install URL Rewrite and Application Request Routing (ARR). Add an HTTPS binding with your certificate, then add a reverse-proxy rule to `http://127.0.0.1:8080`. Set `RECON_BEHIND_PROXY=1` and `RECON_HTTPS=1`.
7. **Backup:** use Task Scheduler to copy `D:\Recon\data` nightly while the service is stopped, or use `sqlite3 recon.db ".backup ..."`.

---

## 5. First sign-in and onboarding the team

1. Open `https://recon.<your-domain>` and sign in as `admin` with the password from `.env`.
2. Choose a new password when asked. After that, clear `RECON_ADMIN_PASSWORD` from `.env`, since it's no longer used.
3. Go to the **Admin** tab, then **Add a user** for each team member. Tick **Admin** for anyone else who should manage users (for example Harleen and Kushal).
4. Share each temporary password privately (Teams chat, not email). Everyone sets their own password at first sign-in.
5. Send the team the URL and a one-line intro, for example: *"Recon is live at https://recon.<your-domain>. Sign in with the username I sent you."*

## 6. Go-live checklist

- [ ] `static/xlsx.bundle.js` is present (no red banner on the page)
- [ ] `.env` has a unique `RECON_SECRET_KEY`, and the file is readable only by the service account
- [ ] `https://` works with a valid internal certificate, and `http://` redirects to it
- [ ] `/healthz` returns `{"status":"ok"}`, and monitoring is set up for it
- [ ] The admin password has been changed, and at least two admins exist
- [ ] Each real connection passes **Test** (Hive, Oracle, Athena, Redshift), and `RECON_DEMO_CONNECTIONS=0`
- [ ] A real source and target query pair compares correctly, and a `DELETE` query is refused
- [ ] One test run of each tool works (Compare, Statistics, Data quality, Trends, Code, DDL fetch, JSON), and an Excel download opens with colors and an **Audit** sheet (try a custom file name)
- [ ] Each tool's run appears in **Team history** under your name, and a colleague can open it and download the report
- [ ] `RECON_RETENTION_DAYS` is set to the period info-security approved (default 7)
- [ ] The **Audit report** shows the test runs with both queries, and its Excel download works
- [ ] `RECON_AUDIT_DAYS` and the audit sheet contents are agreed with your audit or controls team
- [ ] For Hive with Kerberos, the ticket refresh cron is running (section 11.5)
- [ ] Nightly backup is scheduled, and one restore has been tested (section 7)
- [ ] Info-security and data-classification approval is recorded

## 7. Running it day to day

| Task | How |
|---|---|
| See logs | `journalctl -u recon -f` (Linux), the NSSM log (Windows), `docker compose logs -f` |
| Restart | `sudo systemctl restart recon` |
| Reset someone's password | Admin tab → **Reset password** → share the temporary password |
| Remove a leaver | Admin tab → **Disable**. Their history is kept. |
| Back up | `deploy/backup.sh` (database and reports) |
| Restore | Stop the service, copy `recon_<date>.db` to `data/recon.db`, unpack `reports_<date>.tar.gz` into `data/`, start the service |
| Update to a new version | Back up first. Then replace the app files but **keep `.env` and `data/`**, run `pip install -r requirements.txt`, and restart. The database schema is created and upgraded automatically. |
| Remove old runs right now | `python app.py purge` (also runs automatically every hour) |
| Change how long runs are kept | Set `RECON_RETENTION_DAYS` in `.env` and restart |
| Sign everyone out | Change `RECON_SECRET_KEY` and restart |

## 8. Troubleshooting

| What you see | Fix |
|---|---|
| Red banner: "Excel downloads are switched off" | Add `static/xlsx.bundle.js` (step 3) |
| "Your session expired. Reload the page" | Reload. If it happens constantly, check `RECON_HTTPS=1` is only set when the site really is on HTTPS. |
| Sign-in works, then you're immediately signed out | Same cause: the secure cookie is set over plain HTTP. Use HTTPS or set `RECON_HTTPS=0` for a trial. |
| Query says "driver is not installed" | `pip install -r requirements-connectors.txt`, then restart |
| Hive: `GSSAPI` / `No Kerberos credentials` | Ticket missing or expired: run `deploy/kinit_refresh.sh` and check `klist` (section 11.5) |
| Athena: `AccessDenied` or "output location" errors | Check the IAM permissions in 11.3, and set the results S3 path on the connection |
| Query stops at "Timed out after 300 seconds" | Filter or aggregate, or raise `RECON_QUERY_TIMEOUT` (and nginx `proxy_read_timeout` above it) |
| "Stopped at 200,000 rows" warning | Compare a filtered slice or aggregates, or raise `RECON_QUERY_MAX_ROWS` (watch browser memory) |
| 502 Bad Gateway from nginx | The service isn't running (`systemctl status recon`), or SELinux is blocking it (`setsebool -P httpd_can_network_connect 1`). |
| "The report is too large to save" | Raise `RECON_MAX_UPLOAD_MB` and nginx `client_max_body_size` together |
| Activity log shows the proxy's IP for everyone | Set `RECON_BEHIND_PROXY=1`, and make sure nginx sends `X-Forwarded-For` |
| "Too many failed attempts" | Wait 5 minutes, or have an admin reset the password |
| Browser slows down on very large files | The in-browser compare is comfortable up to a few hundred thousand rows. Split bigger files, or see section 10. |
| Lost the admin password | On the server: `sudo -u recon /opt/recon/app/.venv/bin/python /opt/recon/app/app.py reset-password admin` prints a new temporary password (Windows: `.venv\Scripts\python app.py reset-password admin`). |

## 9. Security and data notes

- **Where data goes:** query results pass through the server's memory to the user's browser and are compared there. They are not written to disk, but the server and the network path to it carry production data, so treat the server like any other system that reads these tables. Uploaded files stay on the user's computer.
- **Saved Excel reports can include row-level values** (names, IDs, amounts), and **everyone signed in can download every report in Team history**. Only create accounts for people allowed to see this data, and confirm this with info-security.
- **Retention:** runs and reports are deleted after `RECON_RETENTION_DAYS` (default 7). Backups follow the same period by default (`RECON_BACKUP_KEEP_DAYS`). Audit records, which hold SQL text and results but no row data, are kept for `RECON_AUDIT_DAYS` (default 365).
- **Credentials:** database passwords and AWS keys are never stored in the app (section 11.4). Use read-only accounts on every system (section 11.3).
- **Deleting runs:** only the person who ran it, or an admin, can delete it early. Downloads of someone else's report are recorded in the activity log.
- **Sign-in protection:**
  - Passwords are hashed with Werkzeug's scrypt/pbkdf2.
  - An account locks for 5 minutes after 5 failed sign-ins.
  - Every change requires a CSRF token, and cookies are HttpOnly, SameSite=Lax, and Secure under HTTPS.
  - Everyone signed in can open and download every report in Team history. Only the person who ran it, or an admin, can delete it. Admin pages and connection settings are admin-only.
- **Single sign-on:** if your organisation requires SSO, put the app behind your SSO gateway and change the `login()` route in `app.py` to trust the user header your gateway sets.
- **Updates:** keep Python, Flask and Waitress patched (`pip install -U -r requirements.txt` during maintenance).

## 10. Customising and scaling

| Change | Where |
|---|---|
| Logo on the sign-in card | Replace `static/logo.png` (PNG, about 400 px wide, transparent background) |
| "Implemented by" team credit | `templates/login.html`, the `credit` block |
| Colors | The `:root` tokens at the top of the theme layer in `templates/index.html` and `templates/login.html` |
| Tool descriptions | The `pane-head` blocks in `templates/index.html` |

**Scale:** SQLite is fine for a team of tens of users. For hundreds of users, or more than one server, move to PostgreSQL. For very large data sets, add a server-side compare with pandas, or Spark over Hive tables.

---

## 11. Query mode: connecting Hive, Oracle and AWS

Users never type hostnames or ports. **Admins** set up each system once in **Admin → Connections**. Everyone then just picks it from a dropdown in the Source or Target panel.

### 11.1 How it works

```
 Browser                         Recon server                              Your systems
 ───────                         ────────────                              ────────────
 pick Source + Target  ─HTTPS─►  check: one SELECT only, no DML/DDL  ─┬─►  Hive  (PyHive / impyla)
 type one SELECT each            run both in parallel, read-only      ├─►  Oracle (python-oracledb)
                                 time limit + row limit + cancel      ├─►  AWS Athena  (boto3)
 compare + Excel  ◄─────────────  return both result sets ◄────────────┴─►  AWS Redshift (redshift_connector)
```

**Read-only protection** comes in three layers:

1. The app only accepts **one** statement, and it must start with `SELECT` or `WITH`. INSERT, UPDATE, DELETE, MERGE, DROP, CREATE, ALTER, TRUNCATE, GRANT, CALL, `FOR UPDATE` and similar keywords are refused before anything is sent.
2. Oracle sessions run `SET TRANSACTION READ ONLY` first, and every connection is rolled back and closed after the query.
3. **Use read-only database accounts** (11.3). This is the real control. Layers 1 and 2 are safety nets.

**Values are normalised** so different platforms compare fairly:

- `125000.00` and `125000` match.
- NULL becomes an empty value.
- `true`/`True` match.
- With the "Treat 2026-09-30 00:00:00 as 2026-09-30" box ticked (the default), a midnight timestamp matches a plain date, and `2026-09-30 10:00:00.000` matches `2026-09-30 10:00:00`.

**Limits** are set in `.env`:

| Setting | Default | What it does |
|---|---|---|
| `RECON_QUERY_TIMEOUT` | 300 s | Stops a query that runs too long. Athena queries are stopped on AWS, and Hive and Oracle are cancelled. |
| `RECON_QUERY_MAX_ROWS` | 200,000 per side | Stops fetching past this many rows and warns the user. |
| `RECON_QUERY_CONCURRENCY` | 4 | Number of queries that can run at the same time across all users |

For bigger tables, compare aggregates (counts and sums by key or partition) rather than every row.

**Audit:** every run is logged with who ran it, both connections, the row counts and the SQL text. Credentials are never logged.

### 11.2 Install the drivers

```bash
sudo /opt/recon/app/.venv/bin/pip install -r /opt/recon/app/requirements-connectors.txt
sudo systemctl restart recon
```

| System | Package | Extra OS packages |
|---|---|---|
| Hive via Hue | `requests` | none |
| Hive | `PyHive[hive]`, `thrift`, `thrift-sasl`, `pure-sasl` (+ `impyla` for HTTP/SSL/Knox) | Kerberos: `krb5-workstation` (RHEL) or `krb5-user` (Ubuntu), plus `cyrus-sasl-gssapi` |
| Oracle | `oracledb` (thin mode, so **no Instant Client needed**) | none |
| Athena | `boto3` | none |
| Redshift | `redshift_connector` | none |

If a driver is missing, users see a plain message telling the admin which package to install.

### 11.3 What to ask each platform team for

Raise these requests early, because they usually take the longest.

| System | Ask for | Firewall from the Recon server |
|---|---|---|
| **Hive** | A service principal with a keytab (e.g. `svc_recon@REALM`), with **SELECT-only** Ranger/Sentry policies on the needed databases. Also the HiveServer2 host/port, or the Knox URL. | HiveServer2 `10000` (binary) or `10001` (http), or Knox `8443` |
| **Hive via Hue** | Nothing new: each analyst uses their own Hue login, with the Ranger/Sentry permissions they already have | Hue port, e.g. `8888` |
| **Oracle** | A read-only user (`CREATE SESSION` + `SELECT` on the needed tables or views, nothing else), plus the host, port and service name, or a TNS descriptor. Each analyst can use their own read-only login instead. | `1521` (or your listener port) |
| **AWS Athena** | An **IAM role** for the server (EC2 instance role, or an assumable role) with: `athena:StartQueryExecution`, `GetQueryExecution`, `GetQueryResults`, `StopQueryExecution` on the workgroup; `glue:GetDatabase`, `GetTable`, `GetPartitions`; `s3:GetObject` + `s3:ListBucket` on the data; `s3:PutObject` + `GetObject` on the results bucket; and `kms:Decrypt` if the data is encrypted. | HTTPS `443` to `athena`, `glue`, `s3`, `sts`, `secretsmanager` endpoints, or VPC endpoints. Set `HTTPS_PROXY` in `.env` if needed. |
| **AWS Redshift** | A read-only database user (`USAGE` on the schemas, `SELECT` on the tables) with a password, **or** IAM sign-in (`redshift:GetClusterCredentials`, or `redshift-serverless:GetCredentials`) for a database user like `svc_recon_ro` | `5439` to the cluster endpoint |

### 11.4 Where passwords and keys live

**Passwords and keys are never stored in the Recon database or shown in the browser.** Each connection uses one of these options:

| Option in the form | How it works | Good for |
|---|---|---|
| **No password (Kerberos ticket / IAM role on the server)** | Hive uses the server's Kerberos ticket. Athena and Redshift-IAM use the server's IAM role (or `aws_profile` / `role_arn`). | Hive with Kerberos, Athena, Redshift-IAM. **Recommended.** |
| **Use each person's own Recon sign-in** | With `RECON_AUTH=hue`, the Hue / LDAP password the person signed in with is used (held in server memory only) | Hive via Hue, Hive-LDAP. **Recommended for Hue teams.** |
| **Each user enters their own credentials** | The user types a username and password (or an AWS key) in the panel. It's used for that one run and never saved or logged. | Oracle or Hive-LDAP where every analyst has their own read-only login |
| **Server environment variable** | Put `RECON_ORACLE_IMP_PASSWORD=...` (and optionally `..._USER=svc_recon_ro`) in `.env`, then enter `RECON_ORACLE_IMP_PASSWORD` in the form | Shared service account |
| **AWS Secrets Manager** | Enter the secret ID. The secret holds `{"username":"...","password":"..."}` or a plain password string. The server's IAM role needs `secretsmanager:GetSecretValue` on it. | Shared service account, with rotation |

### 11.5 Hive with Kerberos: keep a ticket on the server

```bash
# 1. place the keytab from your Hadoop/AD team
sudo cp svc_recon.keytab /opt/recon/recon.keytab && sudo chown recon:recon /opt/recon/recon.keytab && sudo chmod 400 /opt/recon/recon.keytab
# 2. make sure /etc/krb5.conf knows your realm (same file the edge nodes use)
# 3. test as the service user
sudo -u recon env KRB5CCNAME=FILE:/opt/recon/krb5cc_recon kinit -kt /opt/recon/recon.keytab svc_recon@YOUR.REALM.COM && sudo -u recon klist -c /opt/recon/krb5cc_recon
# 4. renew every 8 hours
sudo crontab -u recon -e
0 */8 * * * RECON_PRINCIPAL=svc_recon@YOUR.REALM.COM /opt/recon/app/deploy/kinit_refresh.sh >> /opt/recon/backups/kinit.log 2>&1
```

`deploy/recon.service` already sets `KRB5CCNAME=FILE:/opt/recon/krb5cc_recon`, so the app uses this ticket.

### 11.5b Hive through Hue: everyone signs in with their own Hue / LDAP username and password

This setup suits a team that reaches Hive through **Hue** (`https://nykpsr000012067.intranet.barcapint.com:8888/hue`) with an LDAP username and password.

**How it works**
- People sign in to **Recon** with the same username and password they use for Hue.
- Recon checks the password with Hue. On someone's first sign-in it creates their Recon account; no admin step is needed.
- Every Hive query they run goes through Hue **as them**, with their own Ranger/Sentry permissions, and nobody re-types the password.
- The password is kept only in the Recon server's memory, encrypted with a key created at start-up. It's never written to the database, disk or logs. Sign-out removes it, and a session ends after 10 hours.
- After a server restart, people simply sign in again.
- The local `admin` account still uses its Recon password, so you always have a way in if Hue is down.

**Steps**

1. **Install the drivers:** `pip install -r requirements-connectors.txt`. It includes `requests`.
2. **Check the server can reach Hue:**
   ```bash
   curl -I --cacert /etc/pki/tls/certs/ca-bundle.crt https://nykpsr000012067.intranet.barcapint.com:8888/hue/accounts/login/
   ```
   A 200 or 302 reply means it's fine.
   - **Certificate error?** Hue uses a company certificate; that's why the browser shows "Not secure". Get the company root CA file from your Linux or security team and use its path in step 3. Only if that's not possible, set `RECON_HUE_VERIFY_SSL=0`.
   - **Proxy set?** If `.env` has `HTTPS_PROXY`, add `NO_PROXY=localhost,127.0.0.1,.intranet.barcapint.com`.
3. **Add to `.env`:**
   ```ini
   RECON_AUTH=hue
   RECON_HUE_URL=https://nykpsr000012067.intranet.barcapint.com:8888
   RECON_HUE_LOGIN_SERVER=LDAP
   RECON_HUE_CA_BUNDLE=/etc/pki/tls/certs/ca-bundle.crt
   RECON_HUE_DATABASE=default
   RECON_HUE_AUTO_CREATE=1
   ```
   - `RECON_HUE_LOGIN_SERVER` is the dropdown on the Hue sign-in page.
   - `RECON_HUE_AUTO_CREATE=0` lets in only usernames an admin added first.
4. **Restart:** `sudo systemctl restart recon`. On start-up, Recon creates a connection called **"Hive (Hue)"** with Credentials **"Use each person's own Recon sign-in"**.
5. **Test:** sign in to Recon with your Hue username and password. On **Compare records**, pick **Hive (Hue)** as Source; no password box appears. Press **Test**, then run your SELECT. Write table names as `db.table`.

**Notes**
- Run **one** Recon server process, which is what `deploy/recon.service` and Docker already do. The signed-in passwords live in that process's memory. With several processes or servers behind a load balancer, people would be asked to sign in again on each one.
- Wrong passwords count toward the company LDAP lock-out, the same as in Hue. Recon also locks a name for 5 minutes after 5 failed attempts.
- You can add more Hue connections, for example Impala, in Admin → Connections: Type **Hive via Hue**, with Credentials *Use each person's own Recon sign-in*.
- Hue returns about 1,000 rows per call. For very large tables, filter or aggregate (Trends → *Build monthly SUM queries*).
- **Faster option:** in the Hue editor, run `SET hive.server2.authentication;`. If it returns `LDAP`, add a **Hive** connection (HiveServer2 host from the Hadoop team, port `10000`, auth `LDAP`) with Credentials *Use each person's own Recon sign-in*. It uses the same password, without going through Hue.

### 11.5c Incident numbers, one-click AWS console, Partitions tab

**Incident / change number (KPMG evidence).** Set `RECON_REQUIRE_INCIDENT=1` in `.env`. Everyone then has to enter an incident or change number before Run. The website stores it with the run:
- in the **Audit report**, where you can also search for it
- in Team history
- on the **Audit sheet** of every Excel report, together with who ran it, when, both systems and both SQL queries

**One-click AWS Athena console (no password typed).**
1. Ask the AWS team for an IAM role, e.g. `pcds2-recon-readonly`, that has the Athena, Glue and S3 read permissions from 11.3. Its trust policy must allow the Recon server's own role or user to assume it.
2. Admin → Connections → edit the Athena connection: put the role in **IAM role to assume**, and set **Show 'Open in AWS console' button** to `yes`.
3. People pick that connection and click **Open in AWS Athena console ↗**. The server assumes the role and gets a one-time console sign-in link from `signin.aws.amazon.com/federation`. The Athena query editor opens in a new tab, already signed in, and the query is copied so they can paste it with Ctrl+V. Each opening is recorded in the Audit report, with the incident number.
4. The server needs HTTPS access to `sts` and `signin.aws.amazon.com`. If your AWS accounts only allow console sign-in through company SSO, the AWS team must allow federated sign-in for this role. Ask them first.

**Oracle (SQL Developer).** A web page can't open SQL Developer with a system password filled in safely. For Oracle, Recon runs the query itself, using each person's own login or a system account from Secrets Manager or `.env`, and records the evidence.

**Partitions tab.**
- **Show partitions:** runs `SHOW PARTITIONS` and `SHOW CREATE TABLE` (read-only) as the signed-in person. It shows the partition count, months of history, missing months and the latest partition.
- **Browse folder:** uses Hue's File Browser with the person's own Hue sign-in (Hive via Hue connections). The folder is filled in from the table's `LOCATION`.
- **MSCK REPAIR TABLE:** only when `RECON_ALLOW_MSCK=1`, and only for admins. It always needs an incident or change number and a confirmation, and it's recorded in the Audit report. Agree with production support that this replaces the manual server login before you switch it on.

### 11.6 Add the connections (Admin → Connections → Add connection)

| Example name | Type | Fill in | Credentials |
|---|---|---|---|
| Hive PROD – impairments | Hive | host `hs2.your-domain`, port `10000`, database `imp`, auth `KERBEROS`, service name `hive` | No password (Kerberos) |
| Hive (Hue) | Hive via Hue | Created automatically when `RECON_HUE_URL` is set. Hue address `https://nykpsr000012067.intranet.barcapint.com:8888`, engine `hive` (see 11.5b) | Use each person's own Recon sign-in |
| Hive via Knox | Hive | host `knox.your-domain`, port `8443`, transport `http`, HTTP path `gateway/default/hive`, SSL `yes`, auth `LDAP` | Each user enters their own |
| Oracle IMP PROD | Oracle | host, port `1521`, service name `IMPPRD` (or a full DSN) | Each user / env variable / AWS secret |
| Athena – impairments lake | AWS Athena | region `eu-west-1`, Glue database, workgroup, results S3 path if the workgroup has none, optional role ARN | No password (IAM role) |
| Redshift EDW | AWS Redshift | sign-in `password`, endpoint host, port `5439`, database | env variable or AWS secret |
| Redshift EDW (IAM) | AWS Redshift | sign-in `iam`, region, cluster identifier (or serverless workgroup), database user | No password (IAM role) |

After saving, open **Compare records**, pick the connection, and press **Test**. It runs `SELECT 1` (`SELECT 1 FROM dual` on Oracle).

**Demo connections:** with `RECON_DEMO_CONNECTIONS=1`, two SQLite "Demo source / Demo target" connections are created on first start, so the flow can be tried without real systems. Keep it `0` in production, or delete them in Admin.

### 11.7 How the team uses it

**Compare records, Statistics, Data quality and Trends all run on the user's queries.** The Source and Target query panels sit above all four tabs.

1. Open the tab you want: **Compare records**, **Statistics**, **Data quality** or **Trends**.
2. **Source:** pick the connection (e.g. Hive PROD) and type the query. **Target:** pick the connection (e.g. Athena) and type the matching query. Use `AS` aliases so the column names line up.
3. Click **Run both queries & compare** (or press Ctrl+Enter in a query box). Both run in parallel, and **Cancel** stops them. The tab you're on runs automatically.
4. Under the run button, **Use these results for: Compare records · Statistics · Trends · Data quality** re-uses the same results for the other checks, without running the queries again.
5. **One side only:** on Statistics or Data quality you can leave one query empty and profile a single system (e.g. DQ on Hive before the load). Compare records needs both.

| Tab | What it checks on the query results |
|---|---|
| **Compare records** | Row-by-row match on a key column, TRUE/FALSE per column, matched / different / source only / target only |
| **Statistics** | Source and target row counts and their difference. For each column: row count, non-empty, empty, empty %, distinct, sum, mean, median, min, max, std dev, zero values, negative values, min/max length. Can be split **per group** (e.g. ECL per IFRS9 stage), with an **absolute or % tolerance** (e.g. totals within 0.01 or 0.1 %). |
| **Data quality** | Rule 1 nulls · Rule 2 duplicate keys and identical rows · Rule 3 value checks (number, whole number, date, min, max, allowed values, regex pattern, max length, no leading/trailing spaces) · Rule 4 row count (same on both sides within N rows; at least N rows each side) · Rule 5 completeness (every source key is in the target and vice versa) |
| **DDL compare** | **Fetch from systems:** pick a connection and table names per side. Hive uses `SHOW CREATE TABLE`, Oracle reads `ALL_TAB_COLUMNS` + `ALL_CONSTRAINTS`, Athena reads the table from Glue, and Redshift reads `information_schema`. Or paste DDL. Tick **Cross-platform** to compare type families (VARCHAR2 = STRING = VARCHAR, NUMBER(10) = INT) while still flagging precision changes. |
| **Code compare, JSON compare** | Unchanged: paste both sides |

Each run goes to **Team history** with its SQL (or fetched table list), so colleagues can open it and click **Load these queries**. Rule presets also remember the value checks, tolerance, group-by, key column, connections and SQL.

**Extra access needed for DDL fetch:** Oracle users must be able to see the table in `ALL_TAB_COLUMNS` (any SELECT grant on the table is enough). Athena needs `glue:GetTable`, which is already in the 11.3 list. Redshift needs `information_schema` access, which is the default. Hive needs `SHOW CREATE TABLE`, which works with a SELECT Ranger policy.

### 11.8 Trends: monthly SUM of CDEs

The **Trends** tab uses the same Source and Target query panels.

1. **Pick the date or month column and the CDEs** (critical data elements, e.g. EAD, ECL, provision). The app works out each CDE's monthly SUM on both sides. AVERAGE, COUNT, MIN and MAX are also available, and the period can be day, week, month, quarter or year.
2. **Each CDE gets a graph:** source is a solid line and target is a dashed line.
   - Each side is labelled **Increasing / Decreasing / Stable**, based on the fitted change across the range versus its average level (±5%).
   - **Unusual changes** are ringed in red: month-on-month moves larger than the threshold (default ±20%).
   - **Source ≠ target months** are shaded, including months missing on one side.
   - Hover over a graph, or use the arrow keys on it, to see each month's values.
3. **The period-by-period table** lists every value, difference, change % and flag. Excel adds a summary sheet and an Audit sheet.
4. **For large tables,** open **"Large tables? Build monthly SUM queries"**. It writes a `GROUP BY month` query in each connection's own SQL (Hive and Athena `date_format`, Oracle and Redshift `TO_CHAR`), so each system adds up its own data and only 12–24 rows per side come back.
5. **Historical changes:** the query decides the history window (e.g. the last 24 months). Every trends run is also kept in Team history and the Audit report, so earlier runs can be compared later.

### 11.9 Audit report

The **Audit report** tab lists every saved run of every tool. For each run it shows:

- who ran it, from which IP address, and when (UTC and local)
- when the queries were executed
- the source and target systems and connection types
- **the exact SQL executed on each side**
- row counts and query times
- the result and a plain description of the discrepancies

Filter by date range (Today / 7 / 30 / 90 days, or custom), person, tool, result and free text. **Download Excel** produces a reconciliation audit report with three sheets: *Audit log* (one row per run, with full SQL), *Discrepancies* and *Summary* (counts by tool, person and system pair).

Audit records are kept for `RECON_AUDIT_DAYS` (default 365). The Excel files themselves are kept for `RECON_RETENTION_DAYS` (default 7). Every downloaded or saved reconciliation report also contains an **Audit** sheet with:

- who generated it, and when
- both connections and both queries
- row counts and query times
- the settings used (key column, tolerances, rules, CDEs)

The audit details follow the recommended enhancement in the team discussion. The final reporting requirements were not agreed there, so confirm the retention period and the sheet contents with your audit or controls team.

### 11.10 Adding SAS or other systems later

Each system is one function in `connectors.py` plus an entry in `TYPES` (form fields, credential options, test query). Add `_run_sas` (e.g. via `saspy`) and register it in `DRIVERS`. The rest of the app picks it up automatically.
