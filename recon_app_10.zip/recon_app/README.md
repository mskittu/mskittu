# Source Target Recon

> **Windows laptop / VDI?** Follow [WINDOWS_SETUP.txt](WINDOWS_SETUP.txt). `deploy\check_hive.bat` checks the Hive (Hue) connection step by step.
>
> **Going live?** Follow [DEPLOY.md](DEPLOY.md). It has step-by-step instructions for Linux + nginx, Docker and Windows, plus the go-live checklist.

A multi-user web app for validating data between a source and a target system. Everyone signs in at one URL with their own account.

**How data gets in:** pick a **source connection** (Hive, Hive via Hue, or Oracle) and a **target connection** (AWS Athena or Redshift), type one read-only SELECT per side, and click Run. The server runs both queries in parallel with a time limit and a row limit. **File upload** (CSV / Excel) is still available for one-off checks.

**Tools (tabs)**

- **Compare records:** row-by-row match on a key column, TRUE/FALSE per column, with matched / different / source-only / target-only rows, and an overall PASS / FAIL.
- **Recon query builder** (top of Compare records): paste or fetch a CREATE TABLE and get one recon query per side: `COUNT(*)`, `SUM()` of every numeric column and a LENGTH sum (or ASCII) of every non-numeric column, in each system's own SQL. Pick the partition / COB date and an optional From / To range (blank = entire history): one click runs both sides month by month and produces a **Monthly recon** Excel sheet: one row per attribute, SRC | TGT | DIFF for every month side by side, with PASS/FAIL.
- **Statistics:** row counts plus count, empty, distinct, sum, mean, median, min, max, std dev and more, source vs target. Can be split per group, with absolute or % tolerances. Works on one side too.
- **Data quality:** five rules: nulls, duplicates, value checks (number, date, range, allowed values, pattern, length, spaces), row count, and key completeness. Works on one side too.
- **Trends:** monthly SUM of selected CDEs, source against target, with graphs for increasing, decreasing and unusual changes over time. It also produces a **recon sheet** (one row per CDE, with source, target and difference for every month) and a **consolidated** whole-history PASS/FAIL per CDE, on screen and as two extra Excel sheets (*Recon by period*, *Consolidated*). Typical use: migration sign-off, e.g. 3 months of MDS history from OSS against AWS.
- **Code compare:** paste two pieces of code side by side and see the differences.
- **DDL compare:** fetch table definitions from Hive, Oracle, Athena (Glue) or Redshift, or paste CREATE TABLE statements. Columns, types, nullability, defaults, partitions, storage format and TBLPROPERTIES are compared table by table, with an optional cross-platform type match.
- **JSON compare:** paste or load two JSON documents (or JSON Lines). Every difference is listed by path.
- **Partitions:** a Hive table's partitions and months of history (first, last, missing months), its HDFS folder through Hue's File Browser, and, for admins when switched on, MSCK REPAIR TABLE with an incident number.
- **Team history:** every run from the last 7 days, under the name of the person who ran it. Anyone signed in can open it and download its report.
- **Audit report:** every run's systems, executed queries, timestamps, result and discrepancies, kept for 365 days, with an Excel audit report.
- **Admin:** users, connections (Hive, Hive via Hue, Oracle, Athena, Redshift) and the activity log.

**Downloads:** a bar under every result lets you type your own report name. Today's date is added automatically, e.g. `customer_recon_2026-10-20.xlsx`. Every Excel report also carries an **Audit** sheet: who generated it and when, both systems and both queries.

**Each tab keeps its own work:** Compare records, Statistics, Data quality and Trends each have their own queries, connections and results. Switching tabs never changes another tab. To reuse one tab's results in another, click its button under *Use these results for*.

**Rule presets** save your connections, SQL, key columns, rules, tolerances and CDEs, so you can rerun the same check later.

Query results and uploaded files are compared in the user's browser. The server stores only accounts, connection settings (never passwords), run summaries with their SQL, the Excel reports (7 days) and the audit records (365 days).

---

## 1. Install

You need **Python 3.11** for the server (tested on 3.11.16 / 3.11.17). On a Windows laptop any Python 3.10 or newer works for the website and Hive through Hue.

```bash
cd recon_app
python3.11 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
pip install -r requirements-connectors.txt   # Hive, Oracle, Athena, Redshift drivers
```

### Excel library (one-time)

The page needs `xlsx.bundle.js` (the SheetJS build with cell styling, which produces the colored Excel files).

If your network can reach jsDelivr, the page loads it automatically. On a closed internal network, download it once and put it in `static/`:

```
https://cdn.jsdelivr.net/npm/xlsx-js-style@1.2.0/dist/xlsx.bundle.js   →   static/xlsx.bundle.js
```

## 2. First start

```bash
export RECON_ADMIN_PASSWORD='ChooseAStrongOne'   # optional; otherwise one is generated and printed
python app.py                                     # http://127.0.0.1:5000
```

The first start creates the admin account and prints its username and password. The admin is asked to set a new password at first sign-in.

## 3. Add users

1. Sign in as admin and open the **Admin** tab.
2. Create a user. A temporary password is shown.
3. Share the temporary password privately. Users must change it at first sign-in.

## 4. Run for everyone (production)

Follow **DEPLOY.md** (or the plain-text **SETUP_STEPS.txt**). It covers Linux with nginx and HTTPS, Docker, Windows Server, connecting Hive, Oracle and AWS, backups, and the go-live checklist.

## Settings (environment variables)

All settings go in `.env` next to `app.py`. `.env.example` has every one with comments.

| Variable | Default | Purpose |
|---|---|---|
| `RECON_DATA_DIR` | `./data` | Database, saved reports and demo files. Back this folder up. |
| `RECON_SECRET_KEY` | auto-generated in `data/secret.key` | Session signing key |
| `RECON_ADMIN_USER` / `RECON_ADMIN_PASSWORD` | `admin` / random | First admin account (only used when the database is empty) |
| `RECON_HTTPS` / `RECON_BEHIND_PROXY` | `0` / `0` | Set both to `1` behind an HTTPS reverse proxy |
| `RECON_RETENTION_DAYS` | `7` | Team history runs and their Excel reports |
| `RECON_AUDIT_DAYS` | `365` | Audit report records |
| `RECON_ACTIVITY_DAYS` | `90` | Activity log |
| `RECON_AUTH` | `local` | `hue` = everyone signs in with their own Hue / LDAP username and password, and Hive queries run through Hue as them (DEPLOY.md 11.5b) |
| `RECON_HUE_URL` / `RECON_HUE_LOGIN_SERVER` / `RECON_HUE_CA_BUNDLE` | - | Hue address, the Hue sign-in dropdown value (e.g. `LDAP`), and the company CA file |
| `RECON_HUE_AUTO_CREATE` | `1` | Create a Recon account on someone's first Hue sign-in |
| `RECON_REQUIRE_INCIDENT` | `0` | `1` = an incident / change number is required before every run; it goes into the Audit report and every Excel Audit sheet |
| `RECON_ALLOW_MSCK` | `0` | `1` = admins can run MSCK REPAIR TABLE from the Partitions tab |
| `RECON_QUERY_TIMEOUT` | `300` | Seconds before a query is stopped |
| `RECON_QUERY_MAX_ROWS` | `200000` | Rows fetched per side |
| `RECON_QUERY_CONCURRENCY` | `4` | Queries that can run at once across all users |
| `RECON_DEMO_CONNECTIONS` | `1` | Two SQLite demo connections for trying it out. Set `0` in production. |
| `RECON_MAX_UPLOAD_MB` | `100` | Largest Excel report that can be saved |
| `RECON_HOST` / `RECON_PORT` | `127.0.0.1` / `5000` | Only used by `python app.py` |

## Files

```
app.py                     Flask server: sign-in, users, connections, queries, history, audit, admin
connectors.py              Hive / Hue / Oracle / Athena / Redshift drivers
bridge/OracleBridge.*      runs Oracle queries with SQL Developer's own ojdbc driver when python-oracledb is not installed, read-only guard, DDL fetch
templates/login.html       sign-in page (logo, team credit, fits any screen size)
templates/index.html       all tool screens
static/app.js              history, presets, admin and password screens
static/query.js            query panels, DDL fetch, monthly SUM query builder
static/audit.js            audit report screen and Excel export
static/reconsql.js         recon query builder (CREATE TABLE -> recon SQL)
static/partitions.js       Partitions tab (SHOW PARTITIONS, HDFS folder, MSCK)
static/logo.png            sign-in logo (replace with any PNG)
static/xlsx.bundle.js      Excel library: add it yourself (see above)
requirements*.txt          Python packages (tested on Python 3.11)
.env.example               every setting, with comments
deploy/                    systemd service, nginx, Kerberos ticket refresh, backup, Windows launcher
Dockerfile, docker-compose.yml
DEPLOY.md, SETUP_STEPS.txt go-live guides
WINDOWS_SETUP.txt          Windows laptop / VDI: setup, Hive via Hue, running queries
checkhue.py                Hive (Hue) connection check (deploy\check_hive.bat on Windows)
requirements-vdi.txt       Windows packages (website + Hive via Hue); requirements-vdi-optional.txt adds Oracle / AWS drivers
data/                      created at first start: recon.db, reports/, secret.key
```

## Security notes

- **Passwords:** hashed with Werkzeug (scrypt or pbkdf2) and never stored in plain text.
- **Lockout:** an account is locked for 5 minutes after 5 failed sign-ins.
- **CSRF:** every change goes through a CSRF token check.
- **Read-only queries:** only one SELECT / WITH statement is accepted. Oracle sessions also run read-only. Use read-only database accounts as the real control.
- **Hue sign-in:** with `RECON_AUTH=hue`, the password is checked by Hue and kept only in server memory, encrypted, until sign-out. It is never saved to the database or disk.
- **Credentials:** connection passwords and keys are never stored in the app. They come from a Kerberos ticket, an IAM role, environment variables or AWS Secrets Manager, or users type their own for each run.
- **Report access:** everyone signed in can open and download every run in Team history. Only the person who ran it, or an admin, can delete it. Admin pages are admin-only.
- **Audit:** every run is recorded with who ran it, when, both systems and the SQL, and kept for 365 days.

To use company single sign-on instead of local passwords, put the app behind your SSO proxy and replace the `login()` route with a check on the header your proxy sets.

## Very large tables

Query results are compared in the browser, which comfortably handles up to a few hundred thousand rows per side (`RECON_QUERY_MAX_ROWS`, default 200,000).

For bigger tables:
- Compare filtered slices (one partition or month at a time).
- Compare aggregates. The Trends tab's **"Build monthly SUM queries"** makes each system add up its own data.
- For full row-level comparison of very large tables, a server-side compare with Spark is the next step.
