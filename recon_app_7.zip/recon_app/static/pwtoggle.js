/* Eye icon on every password box: click to show / hide what you typed. Works for boxes added later too. */
(function () {
  const css = `.pwwrap{position:relative;display:block;width:100%}
.pwwrap>input{padding-right:44px!important;width:100%}
.pweye{position:absolute;right:6px;top:50%;transform:translateY(-50%);width:32px;height:32px;padding:0!important;margin:0;
  display:flex;align-items:center;justify-content:center;border:0!important;background:transparent!important;color:var(--muted,#566381);
  border-radius:8px;cursor:pointer;box-shadow:none!important}
.pweye:hover{color:var(--accent,#0b7f77);background:var(--accent-soft,#e0f4f1)!important}
.pweye:focus-visible{outline:2px solid var(--accent,#0b7f77);outline-offset:1px}
.pweye svg{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}`;
  const EYE = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>';
  const EYE_OFF = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 3l18 18"/><path d="M10.6 5.1A10.4 10.4 0 0 1 12 5c6.4 0 10 7 10 7a17 17 0 0 1-3.2 4.1M6.5 6.6A17.3 17.3 0 0 0 2 12s3.6 7 10 7a9.8 9.8 0 0 0 5.4-1.6"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>';
  function add(input) {
    if (input.dataset.pweye) return;
    input.dataset.pweye = '1';
    const wrap = document.createElement('span'); wrap.className = 'pwwrap';
    input.parentNode.insertBefore(wrap, input); wrap.appendChild(input);
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'pweye'; b.innerHTML = EYE;
    b.setAttribute('aria-label', 'Show password'); b.title = 'Show password';
    b.addEventListener('click', () => {
      const show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      b.innerHTML = show ? EYE_OFF : EYE;
      const t = show ? 'Hide password' : 'Show password'; b.setAttribute('aria-label', t); b.title = t;
      input.focus({ preventScroll: true });
    });
    wrap.appendChild(b);
  }
  function scan(root) { (root.querySelectorAll ? root : document).querySelectorAll('input[type=password]').forEach(add); }
  function start() {
    const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
    scan(document);
    new MutationObserver(ms => ms.forEach(m => m.addedNodes.forEach(n => { if (n.nodeType !== 1) return; if (n.matches && n.matches('input[type=password]')) add(n); else scan(n); })))
      .observe(document.body, { childList: true, subtree: true });
    // a form that is submitted must send the value, whatever the box shows: nothing to do (type only changes the display)
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
