/* Partitions tab: SHOW PARTITIONS with months-of-history summary, HDFS folder browsing through Hue,
   and (admins, when switched on) MSCK REPAIR TABLE with an incident number. */
(function () {
  const $ = id => document.getElementById(id);
  const R = window.Recon, Q = window.ReconQuery;
  if (!R || !Q || !$('pane-hdfs')) return;
  const esc = R.esc;
  const store = { get(k) { try { return JSON.parse(localStorage.getItem('recon_hd_' + k)); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem('recon_hd_' + k, JSON.stringify(v)); } catch (e) { /* ignore */ } } };
  const hiveConns = () => Q.conns().filter(c => c.type === 'hive' || c.type === 'hue' || c.type === 'sqlite');
  const cur = () => hiveConns().find(c => String(c.id) === $('hdConn').value);

  function fill() {
    const list = hiveConns(), prev = $('hdConn').value || store.get('conn');
    $('hdConn').innerHTML = list.length ? list.map(c => `<option value="${c.id}">${esc(c.name)} (${esc(c.type_label)})</option>`).join('')
      : '<option value="">No Hive connections yet: ask your Recon admin to add one</option>';
    if (prev && list.some(c => String(c.id) === String(prev))) $('hdConn').value = prev;
    else { const h = list.find(c => c.type === 'hue') || list.find(c => c.type === 'hive'); if (h) $('hdConn').value = h.id; }
    creds();
    const t = store.get('table'); if (t && !$('hdTable').value) $('hdTable').value = t;
    $('hdMsckBox').hidden = !(Q.limits().allow_msck);
  }
  function creds() {
    const c = cur(), box = $('hdCred');
    box.innerHTML = !c ? '' : c.secret_mode === 'signin' ? '<p class="note">Runs as you, with your own Hue sign-in.</p>'
      : c.ask_fields.map(f => `<div class="field"><label class="label" for="hd-${f.key}">${esc(f.label)}</label><input type="${f.secret ? 'password' : 'text'}" id="hd-${f.key}" data-key="${f.key}" autocomplete="${f.secret ? 'new-password' : 'off'}" spellcheck="false"></div>`).join('');
    $('hdBrowseBox').hidden = !!c && c.type !== 'hue';
  }
  const credVals = () => { const o = {}; $('hdCred').querySelectorAll('input').forEach(i => { o[i.dataset.key] = i.value; }); return o; };
  Q.onConns(fill);
  $('hdConn').addEventListener('change', () => { store.set('conn', $('hdConn').value); creds(); });

  /* ---- partition values -> dates -> months of history ---- */
  function partDate(p) {
    const kv = {}; String(p).split('/').forEach(x => { const i = x.indexOf('='); if (i > 0) kv[x.slice(0, i).toLowerCase()] = decodeURIComponent(x.slice(i + 1)); });
    if (kv.year && kv.month) return { y: +kv.year, m: +kv.month, d: +(kv.day || 1), key: Object.keys(kv)[0] };
    for (const [k, v] of Object.entries(kv)) {
      let m = v.match(/^(\d{4})-(\d{2})(?:-(\d{2}))?/) || v.match(/^(\d{4})(\d{2})(\d{2})?$/);
      if (m && +m[2] >= 1 && +m[2] <= 12) return { y: +m[1], m: +m[2], d: +(m[3] || 1), key: k };
    }
    return null;
  }
  const ym = (y, m) => `${y}-${String(m).padStart(2, '0')}`;
  function render(out) {
    const rows = out.partitions.map(p => ({ p, d: partDate(p) }));
    const dated = rows.filter(r => r.d), months = [...new Set(dated.map(r => ym(r.d.y, r.d.m)))].sort();
    const missing = [];
    if (months.length > 1) {
      let [y, m] = months[0].split('-').map(Number); const [ly, lm] = months[months.length - 1].split('-').map(Number);
      while (y < ly || (y === ly && m <= lm)) { const k = ym(y, m); if (!months.includes(k)) missing.push(k); m++; if (m > 12) { m = 1; y++; } }
    }
    const latest = dated.length ? dated.reduce((a, b) => (b.d.y * 1e4 + b.d.m * 100 + b.d.d > a.d.y * 1e4 + a.d.m * 100 + a.d.d ? b : a)).p : (rows[rows.length - 1] || {}).p;
    $('hdSummary').innerHTML = `<div class="pill"><span>Partitions</span><b>${rows.length.toLocaleString()}</b></div>` +
      (months.length ? `<div class="pill ok"><span>Months of history (${esc(months[0])} to ${esc(months[months.length - 1])})</span><b>${months.length}</b></div>` +
        `<div class="pill ${missing.length ? 'bad' : 'ok'}"><span>Missing months</span><b>${missing.length}</b></div>` : '') +
      (latest ? `<div class="pill"><span>Latest partition</span><b class="mono" style="font-size:.95rem">${esc(latest)}</b></div>` : '');
    const per = {}; dated.forEach(r => { const k = ym(r.d.y, r.d.m); per[k] = (per[k] || 0) + 1; });
    $('hdPartLabel').textContent = `Partitions of ${out.table}` + (missing.length ? ` · missing months: ${missing.slice(0, 24).join(', ')}${missing.length > 24 ? '…' : ''}` : '');
    $('hdParts').innerHTML = '<table><tr><th>#</th><th>Partition</th><th>Month</th><th>Partitions in that month</th></tr>' +
      rows.slice(-2000).reverse().map((r, i) => `<tr><td>${rows.length - i}</td><td class="mono">${esc(r.p)}</td><td>${r.d ? ym(r.d.y, r.d.m) : '—'}</td><td>${r.d ? per[ym(r.d.y, r.d.m)] : ''}</td></tr>`).join('') +
      (rows.length ? '' : '<tr><td colspan="4" class="miss">This table has no partitions.</td></tr>') + '</table>';
    $('hdPartWrap').hidden = false;
    if (out.location) $('hdPath').value = out.location;
  }

  $('hdList').addEventListener('click', async () => {
    const c = cur(), t = $('hdTable').value.trim();
    if (!c) { R.toast('toastHd', 'Pick a Hive connection.', false); return; }
    if (!t) { R.toast('toastHd', 'Enter the table, e.g. imp.mds_monthly', false); return; }
    store.set('table', t); $('hdList').disabled = true; R.toast('toastHd', 'Reading partitions…', true);
    try {
      const out = await Q.api('/api/hive/partitions', { method: 'POST', json: { connection_id: c.id, table: t, credentials: credVals() } });
      render(out); R.toast('toastHd', `${out.partitions.length.toLocaleString()} partitions in ${out.table}.`, true);
    } catch (e) { R.toast('toastHd', e.message, false); }
    $('hdList').disabled = false;
  });

  /* ---- HDFS folder through Hue ---- */
  const size = n => n == null || n === '' ? '' : n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : n < 1073741824 ? (n / 1048576).toFixed(1) + ' MB' : (n / 1073741824).toFixed(2) + ' GB';
  const when = t => { if (t == null || t === '') return ''; const d = new Date(typeof t === 'number' || /^\d+$/.test(t) ? (+t < 1e11 ? +t * 1000 : +t) : t); return isNaN(d) ? String(t) : d.toLocaleString(); };
  async function browse(path) {
    const c = cur();
    if (!c) { R.toast('toastHdB', 'Pick a Hive (Hue) connection.', false); return; }
    if (!path) { R.toast('toastHdB', 'Enter a folder, or click Show partitions first to fill it from the table.', false); return; }
    $('hdBrowse').disabled = true; R.toast('toastHdB', 'Reading folder…', true);
    try {
      const out = await Q.api('/api/hive/browse', { method: 'POST', json: { connection_id: c.id, path, credentials: credVals() } });
      $('hdPath').value = out.path;
      const dirs = out.entries.filter(e => e.type === 'dir').length;
      $('hdFiles').innerHTML = '<table><tr><th>Name</th><th>Type</th><th>Size</th><th>Modified</th><th>Owner</th></tr>' +
        out.entries.map(e => `<tr><td class="${e.type === 'dir' ? 'dirlink' : ''} mono" ${e.type === 'dir' ? `data-path="${esc(e.path)}"` : ''}>${e.type === 'dir' ? '📁 ' : ''}${esc(e.name)}</td><td>${esc(e.type)}</td><td>${size(e.size)}</td><td>${esc(when(e.mtime))}</td><td>${esc([e.user, e.group].filter(Boolean).join(' / '))}</td></tr>`).join('') +
        (out.entries.length ? '' : '<tr><td colspan="5" class="miss">Empty folder.</td></tr>') + '</table>';
      $('hdFiles').hidden = false;
      R.toast('toastHdB', `${out.entries.length} items (${dirs} folders) in ${out.path}.`, true);
    } catch (e) { R.toast('toastHdB', e.message, false); }
    $('hdBrowse').disabled = false;
  }
  $('hdBrowse').addEventListener('click', () => browse($('hdPath').value.trim()));
  $('hdUp').addEventListener('click', () => { const p = $('hdPath').value.trim().replace(/^[a-z0-9]+:\/\/[^/]*/i, '').replace(/\/+$/, ''); browse(p.slice(0, p.lastIndexOf('/')) || '/'); });
  $('hdFiles').addEventListener('click', e => { const td = e.target.closest('[data-path]'); if (td) browse(td.dataset.path); });

  /* ---- MSCK REPAIR (admin, switched on by RECON_ALLOW_MSCK=1) ---- */
  $('hdMsck').addEventListener('click', async () => {
    const c = cur(), t = $('hdTable').value.trim(), inc = $('hdIncident').value.trim();
    if (!c || !t) { R.toast('toastHdM', 'Pick the connection and enter the table first.', false); return; }
    if (!inc) { R.toast('toastHdM', 'Enter the incident / change number.', false); $('hdIncident').focus(); return; }
    if (!confirm(`Run MSCK REPAIR TABLE ${t} on ${c.name}?\n\nThis changes the Hive metastore and is recorded under ${inc}.`)) return;
    $('hdMsck').disabled = true; R.toast('toastHdM', 'Running MSCK REPAIR…', true);
    try {
      const out = await Q.api('/api/hive/msck', { method: 'POST', json: { connection_id: c.id, table: t, incident: inc, credentials: credVals() } });
      R.toast('toastHdM', `${out.sql} finished. Recorded in the Audit report. Click Show partitions to see the result.`, true);
    } catch (e) { R.toast('toastHdM', e.message, false); }
    $('hdMsck').disabled = false;
  });
})();
