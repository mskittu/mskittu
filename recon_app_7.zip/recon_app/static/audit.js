/* Audit report: validation runs with discrepancies, systems, executed queries and timestamps. */
(function () {
  const $ = id => document.getElementById(id);
  const R = window.Recon, CSRF = window.RECON_CSRF, BASE = window.RECON_BASE || '';
  const esc = R.esc;
  const KIND = { compare: 'Compare records', stats: 'Statistics', dq: 'Data quality', trend: 'Trends', code: 'Code compare', ddl: 'DDL compare', json: 'JSON compare', console: 'AWS console opened', msck: 'MSCK REPAIR' };
  let DATA = null, LOADING = false;

  const pad = n => String(n).padStart(2, '0');
  const ymd = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const utcStamp = d => d.toISOString().replace('T', ' ').slice(0, 19);
  const local = s => { if (!s) return '—'; const d = new Date(String(s).replace(' ', 'T') + (String(s).endsWith('Z') ? '' : 'Z')); return isNaN(d) ? s : d.toLocaleString(); };

  function setRange(days) {
    const to = new Date(), from = new Date(); from.setDate(to.getDate() - days);
    $('auFrom').value = ymd(from); $('auTo').value = ymd(to);
    document.querySelectorAll('#auPresets button').forEach(b => b.setAttribute('aria-pressed', String(+b.dataset.days === days)));
  }
  setRange(30);
  document.querySelectorAll('#auPresets button').forEach(b => b.addEventListener('click', () => { setRange(+b.dataset.days); load(); }));
  ['auFrom', 'auTo'].forEach(id => $(id).addEventListener('change', () => { document.querySelectorAll('#auPresets button').forEach(b => b.setAttribute('aria-pressed', 'false')); load(); }));
  ['auUser', 'auKind', 'auStatus'].forEach(id => $(id).addEventListener('change', load));
  let qt = null; $('auQ').addEventListener('input', () => { clearTimeout(qt); qt = setTimeout(load, 300); });

  function discrepancy(r) {
    const s = r.summary || {};
    switch (r.kind) {
      case 'compare': {
        const cols = s.column_mismatches && Object.keys(s.column_mismatches).length ? ' · columns: ' + Object.entries(s.column_mismatches).map(([k, v]) => `${k} ${v}`).join(', ') : '';
        return s.rows != null ? `${s.different} of ${s.rows} rows differ · ${s.source_only} source only · ${s.target_only} target only${cols}` : (s.text || '');
      }
      case 'stats': return s.figures != null ? `${s.not_matching} of ${s.figures} figures not matching` : (s.text || '');
      case 'dq': return s.checks ? (s.checks.filter(c => c.status === 'FAIL').map(c => `${c.check} ${c.side}: ${c.columns} (${c.failed_rows})`).join(' · ') || 'All checks passed') : (s.text || '');
      case 'trend': return s.periods != null ? `${s.unusual} unusual changes · ${s.mismatches} mismatched periods over ${s.periods} periods` : (s.text || '');
      default: return s.text || '';
    }
  }
  function system(r, side) {
    const conn = r[side + '_connection'], type = r[side + '_type'], name = r[side + '_name'];
    return conn ? `${conn} (${type})` : (name || '—');
  }

  async function load() {
    if (LOADING) return; LOADING = true;
    const from = new Date($('auFrom').value + 'T00:00:00'), to = new Date($('auTo').value + 'T00:00:00');
    if (isNaN(from) || isNaN(to)) { LOADING = false; R.toast('toastAudit', 'Pick a From and To date.', false); return; }
    to.setDate(to.getDate() + 1);
    const q = new URLSearchParams({ from: utcStamp(from), to: utcStamp(to) });
    [['user', 'auUser'], ['kind', 'auKind'], ['status', 'auStatus'], ['q', 'auQ']].forEach(([k, id]) => { if ($(id).value.trim()) q.set(k, $(id).value.trim()); });
    $('auTable').style.opacity = DATA ? .55 : 1;
    try {
      const res = await fetch(BASE + '/api/audit?' + q, { credentials: 'same-origin', headers: { 'X-CSRF-Token': CSRF } });
      if (res.status === 401) { location.href = BASE + '/login'; return; }
      const out = await res.json(); if (!res.ok) throw new Error(out.error || 'Could not load the audit report.');
      DATA = { ...out, from: $('auFrom').value, to: $('auTo').value };
      const sel = $('auUser'), cur = sel.value;
      sel.innerHTML = '<option value="">Everyone</option>' + out.users.map(u => `<option value="${esc(u.username)}">${esc(u.full_name)}</option>`).join('');
      sel.value = cur;
      render();
    } catch (err) { R.toast('toastAudit', err.message, false); }
    $('auTable').style.opacity = 1; LOADING = false;
  }

  function render() {
    const rows = DATA.rows;
    $('auKeep').textContent = `Audit records are kept for ${DATA.audit_days} days. Excel reports can be downloaded for ${DATA.report_days} days, then only the audit record remains. Times are shown in your time zone (${Intl.DateTimeFormat().resolvedOptions().timeZone}).`;
    const pass = rows.filter(r => r.status === 'PASS').length, fail = rows.filter(r => r.status === 'FAIL').length;
    const people = new Set(rows.map(r => r.username)).size;
    const systems = new Set(rows.flatMap(r => [r.src_connection, r.tgt_connection]).filter(Boolean)).size;
    $('auSummary').innerHTML = `<div class="pill"><span>Runs</span><b>${rows.length.toLocaleString()}</b></div><div class="pill ok"><span>Passed</span><b>${pass.toLocaleString()}</b></div>` +
      `<div class="pill ${fail ? 'bad' : 'ok'}"><span>Discrepancies found</span><b>${fail.toLocaleString()}</b></div><div class="pill"><span>People</span><b>${people}</b></div><div class="pill"><span>Systems queried</span><b>${systems}</b></div>`;
    chart(rows);
    $('auTable').innerHTML = rows.length ? '<table><tr><th>When</th><th>Person</th><th>Tool</th><th class="s">Source</th><th class="t">Target</th><th>Rows (S / T)</th><th>Query time</th><th>Incident</th><th>Discrepancies</th><th>Result</th><th>Report</th><th></th></tr>' +
      rows.slice(0, 1500).map(r => `<tr class="${r.status === 'FAIL' ? 'rowbad' : ''}"><td>${esc(local(r.created_at))}</td><td>${esc(r.full_name || r.username)}</td><td>${esc(KIND[r.kind] || r.kind)}</td>` +
        `<td class="tdtext">${esc(system(r, 'src'))}${r.src_sql ? `<div class="sqlpeek">${esc(String(r.src_sql).replace(/\s+/g, ' ').slice(0, 90))}</div>` : ''}</td>` +
        `<td class="tdtext">${esc(system(r, 'tgt'))}${r.tgt_sql ? `<div class="sqlpeek">${esc(String(r.tgt_sql).replace(/\s+/g, ' ').slice(0, 90))}</div>` : ''}</td>` +
        `<td>${r.src_rows != null ? r.src_rows.toLocaleString() : '—'} / ${r.tgt_rows != null ? r.tgt_rows.toLocaleString() : '—'}</td>` +
        `<td>${r.src_seconds != null || r.tgt_seconds != null ? `${r.src_seconds ?? '—'} s / ${r.tgt_seconds ?? '—'} s` : '—'}</td>` +
        `<td class="mono">${esc(r.incident || '—')}</td><td class="tdtext">${esc(discrepancy(r))}</td><td class="${r.status === 'PASS' ? 'T' : r.status === 'FAIL' ? 'F' : 'miss'}">${r.status === 'FAIL' ? 'DISCREPANCY' : esc(r.status || '')}</td>` +
        `<td>${r.report_available ? `<a class="linkbtn" href="${BASE}/api/runs/${r.run_id}/report">Download</a>` : '<span class="note">Removed</span>'}</td>` +
        `<td><button type="button" class="linkbtn" data-au="${r.id}">Details</button></td></tr>`).join('') + '</table>'
      : `<p class="note" style="padding:14px;margin:0">No runs between ${esc(DATA.from)} and ${esc(DATA.to)} with these filters.</p>`;
    $('btnDlAudit').disabled = !rows.length;
    $('auDetail').hidden = true;
  }

  function chart(rows) {
    const card = $('auChartCard');
    const from = new Date(DATA.from + 'T00:00:00'), to = new Date(DATA.to + 'T00:00:00');
    const days = []; for (let d = new Date(from); d <= to && days.length < 120; d.setDate(d.getDate() + 1)) days.push(ymd(d));
    if (!rows.length || days.length < 2) { card.hidden = true; return; }
    const by = Object.fromEntries(days.map(d => [d, { p: 0, f: 0 }]));
    rows.forEach(r => { const k = ymd(new Date(String(r.created_at).replace(' ', 'T') + 'Z')); if (by[k]) by[k][r.status === 'FAIL' ? 'f' : 'p']++; });
    const W = 900, H = 190, L = 34, Rm = 10, T = 10, B = 28, iw = W - L - Rm, ih = H - T - B;
    const max = Math.max(1, ...days.map(d => by[d].p + by[d].f)), ticks = R.niceTicks(0, max, 3).filter(t => Number.isInteger(t));
    const top = ticks[ticks.length - 1] || max, y = v => T + ih - v / top * ih, bw = iw / days.length, w = Math.max(2, bw - 3);
    let g = ticks.map(t => `<line class="tg" x1="${L}" x2="${L + iw}" y1="${y(t)}" y2="${y(t)}"/><text class="tl" x="${L - 6}" y="${y(t) + 4}" text-anchor="end">${t}</text>`).join('');
    const every = Math.max(1, Math.ceil(days.length / 10));
    days.forEach((d, i) => {
      const x = L + i * bw + (bw - w) / 2, v = by[d], hp = v.p / top * ih, hf = v.f / top * ih;
      g += `<g class="bar-g" data-i="${i}">`;
      if (v.p) g += `<rect class="bar-p" x="${x}" y="${y(v.p)}" width="${w}" height="${Math.max(0, hp)}" rx="2"/>`;
      if (v.f) g += `<rect class="bar-f" x="${x}" y="${y(v.p + v.f)}" width="${w}" height="${Math.max(0, hf - (v.p ? 2 : 0))}" rx="2"/>`;
      g += `<rect class="bar-hit" x="${L + i * bw}" y="${T}" width="${bw}" height="${ih}"/></g>`;
      if (i % every === 0) g += `<text class="tl" x="${L + i * bw + bw / 2}" y="${T + ih + 18}" text-anchor="middle">${d.slice(5)}</text>`;
    });
    $('auChart').innerHTML = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Runs per day, passed and with discrepancies">${g}</svg><div class="ttip" hidden></div>`;
    const tip = $('auChart').querySelector('.ttip'), svg = $('auChart').querySelector('svg');
    svg.querySelectorAll('.bar-g').forEach(el => {
      el.addEventListener('pointerenter', () => {
        const i = +el.dataset.i, d = days[i], v = by[d];
        tip.replaceChildren();
        const h = document.createElement('div'); h.className = 'tth'; h.textContent = d; tip.appendChild(h);
        [['kpass', 'Passed', v.p], ['kfail', 'Discrepancies found', v.f]].forEach(([k, l, n]) => {
          const row = document.createElement('div'); row.className = 'ttr'; const ic = document.createElement('i'); ic.className = 'lk ' + k;
          const b = document.createElement('b'); b.textContent = n; const sp = document.createElement('span'); sp.textContent = l; row.append(ic, b, sp); tip.appendChild(row);
        });
        tip.hidden = false; const box = svg.getBoundingClientRect(), sc = box.width / W; let left = (L + (i + 1) * bw) * sc + 8;
        if (left + tip.offsetWidth > box.width) left = (L + i * bw) * sc - tip.offsetWidth - 8; tip.style.left = Math.max(0, left) + 'px'; tip.style.top = '4px';
      });
      el.addEventListener('pointerleave', () => { tip.hidden = true; });
    });
    card.hidden = false;
  }

  $('auTable').addEventListener('click', e => {
    const b = e.target.closest('[data-au]'); if (!b) return;
    const r = DATA.rows.find(x => String(x.id) === b.dataset.au), d = $('auDetail');
    const kv = [['Run', `#${r.run_id} · ${KIND[r.kind] || r.kind} · ${r.title || ''}`], ['Run by', `${r.full_name} (${r.username}) from ${r.ip || '—'}`], ['Incident / change number', r.incident || '—'],
      ['Saved at', `${local(r.created_at)} · UTC ${r.created_at}`], ['Queries executed at', r.ran_at ? `${local(r.ran_at)} · UTC ${String(r.ran_at).replace('T', ' ').slice(0, 19)}` : '—'],
      ['Result', `${r.status === 'FAIL' ? 'Discrepancies found' : r.status || '—'} · ${r.result || ''}`], ['Discrepancies', discrepancy(r)],
      ['Source', `${system(r, 'src')} · ${r.src_rows ?? '—'} rows · ${r.src_seconds ?? '—'} s`], ['Target', `${system(r, 'tgt')} · ${r.tgt_rows ?? '—'} rows · ${r.tgt_seconds ?? '—'} s`],
      ['Report file', r.report_name ? `${r.report_name}${r.report_available ? '' : ' (removed after ' + DATA.report_days + ' days)'}` : '—']];
    d.innerHTML = `<h3>Audit record #${r.id}</h3><dl class="kv">${kv.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join('')}</dl>` +
      (r.src_sql ? `<div class="field"><span class="label" style="color:var(--src)">Source query / input</span><pre>${esc(r.src_sql)}</pre></div>` : '') +
      (r.tgt_sql ? `<div class="field"><span class="label" style="color:var(--tgt)">Target query / input</span><pre>${esc(r.tgt_sql)}</pre></div>` : '') +
      `<div class="actions">${r.report_available ? `<a class="btn primary" style="text-decoration:none;background:var(--accent);color:var(--accent-ink);border-color:var(--accent)" href="${BASE}/api/runs/${r.run_id}/report">Download reconciliation report</a>` : ''}<button type="button" id="auClose">Close</button></div>`;
    d.hidden = false; $('auClose').addEventListener('click', () => { d.hidden = true; }); d.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  });

  function build() {
    if (!DATA || !window.XLSX) return null;
    const clip = v => { v = v == null ? '' : String(v); return v.length > 32000 ? v.slice(0, 32000) + '…' : v; };
    const wb = XLSX.utils.book_new(), rows = DATA.rows;
    const head = ['audit_id', 'run_id', 'saved_at_utc', 'saved_at_local', 'queries_executed_at_utc', 'person', 'username', 'ip', 'incident', 'tool', 'title', 'status',
      'discrepancies', 'result', 'source_system', 'source_type', 'source_query', 'source_rows', 'source_query_seconds',
      'target_system', 'target_type', 'target_query', 'target_rows', 'target_query_seconds', 'report_file', 'report_available'];
    XLSX.utils.book_append_sheet(wb, R.sheet([head, ...rows.map(r => [r.id, r.run_id, r.created_at, local(r.created_at), r.ran_at ? String(r.ran_at).replace('T', ' ').slice(0, 19) : '', r.full_name, r.username, r.ip || '', r.incident || '',
      KIND[r.kind] || r.kind, r.title || '', r.status || '', discrepancy(r), r.result || '', r.src_connection || r.src_name || '', r.src_type || '', clip(r.src_sql), r.src_rows ?? '', r.src_seconds ?? '',
      r.tgt_connection || r.tgt_name || '', r.tgt_type || '', clip(r.tgt_sql), r.tgt_rows ?? '', r.tgt_seconds ?? '', r.report_name || '', r.report_available ? 'yes' : 'removed'])],
      head.map(h => ({ wch: /query$/.test(h) ? 60 : /discrepancies|result|title/.test(h) ? 44 : 18 }))), 'Audit log');
    const fails = rows.filter(r => r.status === 'FAIL');
    XLSX.utils.book_append_sheet(wb, R.sheet([['saved_at_local', 'person', 'tool', 'source_system', 'target_system', 'discrepancies', 'status'],
      ...fails.map(r => [local(r.created_at), r.full_name, KIND[r.kind] || r.kind, system(r, 'src'), system(r, 'tgt'), discrepancy(r), 'FAIL'])],
      [{ wch: 22 }, { wch: 18 }, { wch: 16 }, { wch: 30 }, { wch: 30 }, { wch: 80 }, { wch: 9 }]), 'Discrepancies');
    const count = f => { const m = {}; rows.forEach(r => { const k = f(r); m[k] = m[k] || { n: 0, f: 0 }; m[k].n++; if (r.status === 'FAIL') m[k].f++; }); return Object.entries(m); };
    const me = window.RECON_ME || {}, sum = [['Item', 'Value'], ['Report', 'Reconciliation audit report'], ['Period', `${DATA.from} to ${DATA.to}`],
      ['Filters', [['Person', $('auUser').selectedOptions[0]?.text], ['Tool', $('auKind').selectedOptions[0]?.text], ['Result', $('auStatus').selectedOptions[0]?.text], ['Search', $('auQ').value]].map(([k, v]) => `${k}: ${v || 'any'}`).join(' · ')],
      ['Generated at', `${new Date().toLocaleString()} (UTC ${utcStamp(new Date())})`], ['Generated by', me.full_name ? `${me.full_name} (${me.username})` : ''],
      ['Runs', rows.length], ['Passed', rows.filter(r => r.status === 'PASS').length], ['Discrepancies found', fails.length], [], ['By tool', 'runs / with discrepancies']];
    count(r => KIND[r.kind] || r.kind).forEach(([k, v]) => sum.push([k, `${v.n} / ${v.f}`]));
    sum.push([], ['By person', 'runs / with discrepancies']); count(r => r.full_name || r.username).forEach(([k, v]) => sum.push([k, `${v.n} / ${v.f}`]));
    sum.push([], ['By system pair', 'runs / with discrepancies']); count(r => `${system(r, 'src')} → ${system(r, 'tgt')}`).forEach(([k, v]) => sum.push([k, `${v.n} / ${v.f}`]));
    XLSX.utils.book_append_sheet(wb, R.sheet(sum, [{ wch: 44 }, { wch: 70 }]), 'Summary');
    return wb;
  }

  window.ReconAudit = { load, build };
  document.addEventListener('recon:tab', e => { if (e.detail === 'audit') load(); });
})();
