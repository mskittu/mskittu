@echo off
setlocal
REM Checks the Hive (Hue) connection step by step and tells you what to fix.
cd /d "%~dp0.."
if not exist ".venv\Scripts\python.exe" (
  echo  Run deploy\run_local_windows.bat once first - it installs Python packages.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" checkhue.py
