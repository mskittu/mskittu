@echo off
setlocal
REM ======================================================================
REM  Source Target Recon - start on a Windows laptop / VDI
REM  Double-click this file. See WINDOWS_SETUP.txt for the full steps.
REM ======================================================================
REM  If pip must use your company package mirror, put the options here, e.g.
REM  set "PIP_OPTS=--index-url https://artifactory.example.com/api/pypi/pypi/simple --trusted-host artifactory.example.com"
set "PIP_OPTS="
REM  If Python is still "not found", put the full path to python.exe here, e.g.
REM  set "PYTHON_EXE=C:\Users\YOURNAME\AppData\Local\Programs\Python\Python315\python.exe"
set "PYTHON_EXE="

cd /d "%~dp0.."

REM ---- find Python: your PYTHON_EXE, then 3.11, then any 3.10 or newer ----
set "PY="
REM a path saved by an earlier run (deploy\python_path.txt)
if not defined PYTHON_EXE if exist "%~dp0python_path.txt" set /p PYTHON_EXE=<"%~dp0python_path.txt"
if defined PYTHON_EXE set "PYTHON_EXE=%PYTHON_EXE:"=%"
if defined PYTHON_EXE call :trypy "%PYTHON_EXE%"
if not defined PY py -3.11 --version >nul 2>nul && set "PY=py -3.11"
if not defined PY py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul && set "PY=py -3"
if not defined PY python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul && set "PY=python"
if not defined PY python3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul && set "PY=python3"
REM ---- not on PATH: look in the usual install folders ----
if not defined PY for /d %%d in ("%LOCALAPPDATA%\Programs\Python\Python3*" "%ProgramFiles%\Python3*" "%ProgramFiles(x86)%\Python3*" "C:\Python3*" "%USERPROFILE%\AppData\Local\Python\*" "%USERPROFILE%\anaconda3" "%USERPROFILE%\miniconda3" "%LOCALAPPDATA%\anaconda3" "%LOCALAPPDATA%\miniconda3" "%ProgramData%\anaconda3" "%ProgramData%\miniconda3" "C:\Tools\Python3*" "D:\Python3*") do if exist "%%~d\python.exe" call :trypy "%%~d\python.exe"
if not defined PY (
  echo.
  echo  Python was not found automatically.
  echo  In another cmd window where  python3 -V  works, run:
  echo      python3 -c "import sys; print(sys.executable)"
  echo  and copy the path it prints, e.g. C:\Users\YOURNAME\...\python.exe
  echo.
  set /p "PYTHON_EXE=Paste the full path to python.exe here and press Enter: "
)
if defined PYTHON_EXE set "PYTHON_EXE=%PYTHON_EXE:"=%"
if not defined PY if defined PYTHON_EXE call :trypy "%PYTHON_EXE%"
if not defined PY (
  echo.
  echo  [FAIL] That path did not work as Python 3.10 or newer.
  echo         Check the path - it must end with python.exe - and double-click this file again.
  pause
  exit /b 1
)
REM remember a pasted / configured path for next time
if defined PYTHON_EXE >"%~dp0python_path.txt" echo %PYTHON_EXE%
for /f "delims=" %%v in ('%PY% --version 2^>^&1') do echo  Using %%v

if not exist ".venv\Scripts\python.exe" (
  echo  Creating the Python environment .venv ...
  %PY% -m venv .venv
  if errorlevel 1 (
    echo  [FAIL] Could not create .venv. See WINDOWS_SETUP.txt, step 2.
    pause
    exit /b 1
  )
)

echo  Checking Python packages ...
".venv\Scripts\python.exe" -m pip install -q --disable-pip-version-check --timeout 15 --retries 0 -r requirements-vdi.txt %PIP_OPTS% >nul 2>nul
if errorlevel 1 (
  if exist "vendor\flask" (
    echo  [INFO] Downloads are blocked here - using the packages included in the zip ^(vendor folder^). That is fine.
  ) else (
    echo.
    echo  [FAIL] pip could not download the packages and the vendor folder is missing.
    echo         Unzip the full recon_app.zip again, or set PIP_OPTS at the top of this file - see WINDOWS_SETUP.txt step 3.
    pause
    exit /b 1
  )
) else (
  echo  Packages are installed.
  REM optional Oracle / AWS drivers: never block Hive
  ".venv\Scripts\python.exe" -m pip install -q --disable-pip-version-check --timeout 15 --retries 0 -r requirements-vdi-optional.txt %PIP_OPTS% >nul 2>nul
  if errorlevel 1 echo  [INFO] Oracle / AWS drivers are not installed. Hive through Hue works without them.
)

if not exist ".env" (
  copy ".env.vdi.example" ".env" >nul
  echo  Created .env from .env.vdi.example - check it in Notepad, see WINDOWS_SETUP.txt step 5.
)

echo.
echo  Starting Source Target Recon on http://127.0.0.1:5000
echo  Keep this window open while you use the website. Press Ctrl+C to stop.
echo.
start "" cmd /c "timeout /t 4 >nul & start http://127.0.0.1:5000"
".venv\Scripts\python.exe" app.py
echo.
echo  The website stopped. If you see an error above, see WINDOWS_SETUP.txt "Common problems".
pause
exit /b 0

:trypy
if defined PY goto :eof
if "%~1"=="" goto :eof
if not exist "%~1" goto :eof
"%~1" -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
if errorlevel 1 goto :eof
set PY="%~1"
goto :eof
