@echo off
setlocal
REM ======================================================================
REM  Source Target Recon - start on a Windows laptop / VDI
REM  Double-click this file. See WINDOWS_SETUP.txt for the full steps.
REM ======================================================================
REM  If pip must use your company package mirror, put the options here, e.g.
REM  set "PIP_OPTS=--index-url https://artifactory.example.com/api/pypi/pypi/simple --trusted-host artifactory.example.com"
set "PIP_OPTS="

cd /d "%~dp0.."

set "PY="
py -3.11 --version >nul 2>nul && set "PY=py -3.11"
if not defined PY (
  python --version 2>nul | findstr /c:"Python 3.11" >nul && set "PY=python"
)
if not defined PY (
  echo.
  echo  [FAIL] Python 3.11 was not found.
  echo         Install Python 3.11 from your company software portal, or from python.org,
  echo         tick "Add python.exe to PATH", then double-click this file again.
  echo.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo  Creating the Python environment .venv ...
  %PY% -m venv .venv
  if errorlevel 1 (
    echo  [FAIL] Could not create .venv. See WINDOWS_SETUP.txt, step 2.
    pause
    exit /b 1
  )
)

echo  Checking Python packages ...
".venv\Scripts\python.exe" -m pip install -q --disable-pip-version-check -r requirements-vdi.txt %PIP_OPTS%
if errorlevel 1 (
  if exist ".venv\.installed" (
    echo  [WARN] pip could not check for updates - starting with the packages already installed.
  ) else (
    echo.
    echo  [FAIL] pip could not download the packages.
    echo         Your VDI probably needs the company package mirror: edit PIP_OPTS at the top of this file.
    echo         See WINDOWS_SETUP.txt, step 3.
    pause
    exit /b 1
  )
) else (
  echo ok> ".venv\.installed"
)

if not exist ".env" (
  copy ".env.vdi.example" ".env" >nul
  echo  Created .env from .env.vdi.example - edit it in Notepad for Hue, see WINDOWS_SETUP.txt step 5.
)

echo.
echo  Starting Source Target Recon on http://127.0.0.1:5000
echo  Keep this window open while you use the website. Press Ctrl+C to stop.
echo.
start "" cmd /c "timeout /t 4 >nul & start http://127.0.0.1:5000"
".venv\Scripts\python.exe" app.py
echo.
echo  The website stopped. If you see an error above, see WINDOWS_SETUP.txt "Common problems".
pause
