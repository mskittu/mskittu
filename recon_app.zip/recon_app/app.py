"""
Source Target Recon - multi-user web app.

Each user signs in with their own account and gets their own run history,
saved Excel reports and saved rule presets. Admins manage users and can see
everyone's activity.

Files are compared in the user's browser; only the results (summary + Excel
report) are stored on the server.

Run (development):   python app.py
Run (production):    waitress-serve --host 0.0.0.0 --port 8080 app:app
"""
import json
import os
import secrets
import sqlite3
import time
import uuid
import threading
from datetime import datetime, timedelta, timezone
from functools import wraps

from flask import (Flask, abort, g, jsonify, redirect, render_template, request,
                   send_file, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

BASE = os.path.dirname(os.path.abspath(__file__))


def _load_env_file():
    """Read KEY=VALUE lines from .env next to app.py (real environment variables win)."""
    path = os.path.join(BASE, ".env")
    if not os.path.exists(path):
        return
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, val = line.split("=", 1)
            os.environ.setdefault(key.strip(), val.strip().strip('"').strip("'"))


_load_env_file()
DATA_DIR = os.environ.get("RECON_DATA_DIR", os.path.join(BASE, "data"))
DB_PATH = os.path.join(DATA_DIR, "recon.db")
REPORT_DIR = os.path.join(DATA_DIR, "reports")
os.makedirs(REPORT_DIR, exist_ok=True)


def _secret_key():
    env = os.environ.get("RECON_SECRET_KEY")
    if env:
        return env
    path = os.path.join(DATA_DIR, "secret.key")
    if not os.path.exists(path):
        with open(path, "w") as f:
            f.write(secrets.token_hex(32))
        os.chmod(path, 0o600)
    with open(path) as f:
        return f.read().strip()


app = Flask(__name__)
app.config.update(
    SECRET_KEY=_secret_key(),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("RECON_HTTPS", "0") == "1",
    PERMANENT_SESSION_LIFETIME=60 * 60 * 10,  # 10 hours
    MAX_CONTENT_LENGTH=int(os.environ.get("RECON_MAX_UPLOAD_MB", "100")) * 1024 * 1024,
)

if os.environ.get("RECON_BEHIND_PROXY", "0") == "1":
    # Trust X-Forwarded-For/Proto/Host/Prefix from ONE reverse proxy (nginx, IIS, F5).
    from werkzeug.middleware.proxy_fix import ProxyFix
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)

RETENTION_DAYS = max(1, int(os.environ.get("RECON_RETENTION_DAYS", "7")))
ACTIVITY_DAYS = max(7, int(os.environ.get("RECON_ACTIVITY_DAYS", "90")))
TS_FMT = "%Y-%m-%d %H:%M:%S"

KINDS = {"compare", "stats", "dq", "code", "ddl", "json"}
MIN_PASSWORD = 8


# ---------------------------------------------------------------- database
SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL COLLATE NOCASE,
  full_name TEXT NOT NULL DEFAULT '',
  password_hash TEXT NOT NULL,
  is_admin INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  must_change INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  last_login TEXT
);
CREATE TABLE IF NOT EXISTS runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  kind TEXT NOT NULL,
  title TEXT NOT NULL,
  src_name TEXT,
  tgt_name TEXT,
  summary_json TEXT NOT NULL DEFAULT '{}',
  report_file TEXT,
  report_name TEXT,
  report_size INTEGER,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_runs_user ON runs(user_id, created_at);
CREATE TABLE IF NOT EXISTS presets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  name TEXT NOT NULL,
  data_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE(user_id, name)
);
CREATE TABLE IF NOT EXISTS activity (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  username TEXT,
  action TEXT NOT NULL,
  detail TEXT,
  ip TEXT,
  at TEXT NOT NULL
);
"""


def now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.executescript(SCHEMA)
    has_user = conn.execute("SELECT 1 FROM users LIMIT 1").fetchone()
    if not has_user:
        username = os.environ.get("RECON_ADMIN_USER", "admin")
        password = os.environ.get("RECON_ADMIN_PASSWORD") or secrets.token_urlsafe(9)
        conn.execute(
            "INSERT INTO users(username, full_name, password_hash, is_admin, must_change, created_at)"
            " VALUES (?,?,?,?,?,?)",
            (username, "Administrator", generate_password_hash(password), 1, 1, now()))
        conn.commit()
        print("=" * 60)
        print(f" First admin account created:  {username} / {password}")
        print(" You will be asked to change this password at first sign-in.")
        print("=" * 60)
    conn.close()


def log(action, detail="", user=None):
    u = user or getattr(g, "user", None)
    db().execute(
        "INSERT INTO activity(user_id, username, action, detail, ip, at) VALUES (?,?,?,?,?,?)",
        (u["id"] if u else None, u["username"] if u else None, action, detail[:500],
         request.remote_addr, now()))
    db().commit()


# ---------------------------------------------------------------- automatic clean-up
_purge_lock = threading.Lock()
_last_purge = [0.0]


def purge_old_runs():
    """Delete runs (and their Excel files) older than RETENTION_DAYS, and old activity rows."""
    with _purge_lock:
        _last_purge[0] = time.time()
        cutoff = (datetime.now(timezone.utc) - timedelta(days=RETENTION_DAYS)).strftime(TS_FMT)
        act_cutoff = (datetime.now(timezone.utc) - timedelta(days=ACTIVITY_DAYS)).strftime(TS_FMT)
        conn = sqlite3.connect(DB_PATH)
        try:
            old = conn.execute("SELECT id, report_file FROM runs WHERE created_at < ?", (cutoff,)).fetchall()
            for _rid, report in old:
                if report:
                    try:
                        os.remove(os.path.join(REPORT_DIR, report))
                    except FileNotFoundError:
                        pass
            conn.execute("DELETE FROM runs WHERE created_at < ?", (cutoff,))
            conn.execute("DELETE FROM activity WHERE at < ?", (act_cutoff,))
            if old:
                conn.execute("INSERT INTO activity(user_id, username, action, detail, ip, at) VALUES (NULL,'system','auto_cleanup',?,NULL,?)",
                             (f"Removed {len(old)} run(s) older than {RETENTION_DAYS} days", now()))
            conn.commit()
            return len(old)
        finally:
            conn.close()


def _purge_loop():
    while True:
        time.sleep(3600)
        try:
            purge_old_runs()
        except Exception as exc:  # keep the thread alive
            print("auto clean-up failed:", exc)


# ---------------------------------------------------------------- auth helpers
_failures = {}  # key -> [count, first_failure_time]
LOCK_AFTER, LOCK_SECONDS = 5, 300


def _locked(key):
    rec = _failures.get(key)
    if not rec:
        return False
    if time.time() - rec[1] > LOCK_SECONDS:
        _failures.pop(key, None)
        return False
    return rec[0] >= LOCK_AFTER


def _fail(key):
    rec = _failures.setdefault(key, [0, time.time()])
    rec[0] += 1


@app.before_request
def load_user():
    if time.time() - _last_purge[0] > 3600:
        try:
            purge_old_runs()
        except Exception as exc:
            print("auto clean-up failed:", exc)
    g.user = None
    uid = session.get("uid")
    if uid:
        row = db().execute("SELECT * FROM users WHERE id=? AND active=1", (uid,)).fetchone()
        if row:
            g.user = row
        else:
            session.clear()
    if "csrf" not in session:
        session["csrf"] = secrets.token_urlsafe(24)
    # CSRF check for every state-changing request
    if request.method in ("POST", "PUT", "PATCH", "DELETE"):
        token = request.headers.get("X-CSRF-Token") or request.form.get("csrf")
        if not token or not secrets.compare_digest(token, session["csrf"]):
            abort(400, "Your session expired. Reload the page and try again.")


def login_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        if not g.user:
            if request.path.startswith("/api/"):
                return jsonify(error="Please sign in again."), 401
            return redirect(url_for("login"))
        if g.user["must_change"] and request.endpoint not in ("change_password", "me", "index", "logout"):
            return jsonify(error="Change your password first."), 403
        return fn(*a, **kw)
    return wrapper


def admin_required(fn):
    @wraps(fn)
    @login_required
    def wrapper(*a, **kw):
        if not g.user["is_admin"]:
            return jsonify(error="Only admins can do this."), 403
        return fn(*a, **kw)
    return wrapper


def user_dict(row):
    return dict(id=row["id"], username=row["username"], full_name=row["full_name"],
                is_admin=bool(row["is_admin"]), active=bool(row["active"]),
                must_change=bool(row["must_change"]), created_at=row["created_at"],
                last_login=row["last_login"])


# ---------------------------------------------------------------- pages
@app.get("/healthz")
def healthz():
    """For load balancers and monitoring: checks the database answers."""
    try:
        db().execute("SELECT 1").fetchone()
        return jsonify(status="ok"), 200
    except Exception as exc:  # pragma: no cover
        return jsonify(status="error", detail=str(exc)), 503


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        key = (username.lower(), request.remote_addr)
        if _locked(key):
            error = "Too many failed attempts. Wait 5 minutes and try again."
        else:
            row = db().execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
            if row and row["active"] and check_password_hash(row["password_hash"], password):
                _failures.pop(key, None)
                session.clear()
                session.permanent = True
                session["uid"] = row["id"]
                session["csrf"] = secrets.token_urlsafe(24)
                db().execute("UPDATE users SET last_login=? WHERE id=?", (now(), row["id"]))
                db().commit()
                log("login", user=row)
                return redirect(url_for("index"))
            _fail(key)
            error = ("This account is disabled. Ask an admin to enable it."
                     if row and not row["active"] else "Username or password is wrong.")
    return render_template("login.html", error=error, csrf=session["csrf"])


@app.post("/logout")
def logout():
    if g.user:
        log("logout")
    session.clear()
    return redirect(url_for("login"))


@app.get("/")
@login_required
def index():
    return render_template("index.html", csrf=session["csrf"], me=user_dict(g.user))


# ---------------------------------------------------------------- account
@app.get("/api/me")
@login_required
def me():
    return jsonify(user_dict(g.user))


@app.post("/api/me/password")
@login_required
def change_password():
    body = request.get_json(force=True, silent=True) or {}
    cur, new = body.get("current", ""), body.get("new", "")
    if not check_password_hash(g.user["password_hash"], cur):
        return jsonify(error="Your current password is wrong."), 400
    if len(new) < MIN_PASSWORD:
        return jsonify(error=f"Use at least {MIN_PASSWORD} characters."), 400
    db().execute("UPDATE users SET password_hash=?, must_change=0 WHERE id=?",
                 (generate_password_hash(new), g.user["id"]))
    db().commit()
    log("password_changed")
    return jsonify(ok=True)


# ---------------------------------------------------------------- runs + reports
RUN_SELECT = ("SELECT r.*, u.username, u.full_name FROM runs r JOIN users u ON u.id=r.user_id")


def run_dict(row):
    created = datetime.strptime(row["created_at"], TS_FMT)
    return dict(id=row["id"], kind=row["kind"], title=row["title"], src_name=row["src_name"],
                tgt_name=row["tgt_name"], summary=json.loads(row["summary_json"] or "{}"),
                has_report=bool(row["report_file"]), report_name=row["report_name"],
                report_size=row["report_size"], created_at=row["created_at"],
                expires_at=(created + timedelta(days=RETENTION_DAYS)).strftime(TS_FMT),
                user_id=row["user_id"], username=row["username"],
                full_name=row["full_name"] or row["username"],
                can_delete=bool(row["user_id"] == g.user["id"] or g.user["is_admin"]))


@app.get("/api/runs")
@login_required
def list_runs():
    """Team history: every signed-in user sees everyone's runs from the last RETENTION_DAYS days."""
    limit = min(int(request.args.get("limit", 300)), 1000)
    kind = request.args.get("kind")
    q, args = RUN_SELECT + " WHERE 1=1", []
    if request.args.get("who") == "mine":
        q += " AND r.user_id=?"
        args.append(g.user["id"])
    if kind in KINDS:
        q += " AND r.kind=?"
        args.append(kind)
    search = request.args.get("q", "").strip()[:100]
    if search:
        like = "%" + search.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        q += (" AND (r.title LIKE ? ESCAPE '\\' OR r.src_name LIKE ? ESCAPE '\\' OR r.tgt_name LIKE ? ESCAPE '\\'"
              " OR u.username LIKE ? ESCAPE '\\' OR u.full_name LIKE ? ESCAPE '\\')")
        args += [like] * 5
    q += " ORDER BY r.created_at DESC, r.id DESC LIMIT ?"
    args.append(limit)
    rows = db().execute(q, args).fetchall()
    return jsonify(runs=[run_dict(r) for r in rows], retention_days=RETENTION_DAYS)


@app.post("/api/runs")
@login_required
def create_run():
    meta = json.loads(request.form.get("meta", "{}"))
    kind = meta.get("kind")
    if kind not in KINDS:
        return jsonify(error="Unknown run type."), 400
    summary = json.dumps(meta.get("summary", {}))
    if len(summary) > 2_000_000:
        return jsonify(error="Run summary is too large to save."), 400
    report_file = report_name = report_size = None
    f = request.files.get("report")
    if f:
        if not f.filename.lower().endswith(".xlsx"):
            return jsonify(error="Reports must be .xlsx files."), 400
        user_dir = os.path.join(REPORT_DIR, str(g.user["id"]))
        os.makedirs(user_dir, exist_ok=True)
        report_file = f"{g.user['id']}/{uuid.uuid4().hex}.xlsx"
        path = os.path.join(REPORT_DIR, report_file)
        f.save(path)
        report_name = os.path.basename(f.filename)[:200]
        report_size = os.path.getsize(path)
    cur = db().execute(
        "INSERT INTO runs(user_id, kind, title, src_name, tgt_name, summary_json, report_file,"
        " report_name, report_size, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
        (g.user["id"], kind, str(meta.get("title", kind))[:200], str(meta.get("src_name", ""))[:300],
         str(meta.get("tgt_name", ""))[:300], summary, report_file, report_name, report_size, now()))
    db().commit()
    log("run_" + kind, meta.get("title", ""))
    row = db().execute(RUN_SELECT + " WHERE r.id=?", (cur.lastrowid,)).fetchone()
    return jsonify(run_dict(row)), 201


def _team_run(run_id):
    """Any signed-in team member can open and download any run in team history."""
    row = db().execute(RUN_SELECT + " WHERE r.id=?", (run_id,)).fetchone()
    if not row:
        abort(404, "This run no longer exists. Runs are removed after %d days." % RETENTION_DAYS)
    return row


@app.get("/api/runs/<int:run_id>")
@login_required
def get_run(run_id):
    row = _team_run(run_id)
    return jsonify(run_dict(row))


@app.get("/api/runs/<int:run_id>/report")
@login_required
def get_report(run_id):
    row = _team_run(run_id)
    if not row["report_file"]:
        abort(404)
    path = os.path.realpath(os.path.join(REPORT_DIR, row["report_file"]))
    if not path.startswith(os.path.realpath(REPORT_DIR)) or not os.path.exists(path):
        abort(404)
    if row["user_id"] != g.user["id"]:
        log("report_downloaded", f"{row['report_name']} (run by {row['username']})")
    return send_file(path, as_attachment=True, download_name=row["report_name"] or "report.xlsx")


@app.delete("/api/runs/<int:run_id>")
@login_required
def delete_run(run_id):
    row = _team_run(run_id)
    if row["user_id"] != g.user["id"] and not g.user["is_admin"]:
        return jsonify(error="Only the person who ran it, or an admin, can delete this run."), 403
    if row["report_file"]:
        try:
            os.remove(os.path.join(REPORT_DIR, row["report_file"]))
        except FileNotFoundError:
            pass
    db().execute("DELETE FROM runs WHERE id=?", (run_id,))
    db().commit()
    log("run_deleted", str(run_id))
    return jsonify(ok=True)


# ---------------------------------------------------------------- presets
@app.get("/api/presets")
@login_required
def list_presets():
    rows = db().execute("SELECT * FROM presets WHERE user_id=? ORDER BY name", (g.user["id"],)).fetchall()
    return jsonify([dict(id=r["id"], name=r["name"], data=json.loads(r["data_json"]),
                         created_at=r["created_at"]) for r in rows])


@app.post("/api/presets")
@login_required
def save_preset():
    body = request.get_json(force=True, silent=True) or {}
    name = str(body.get("name", "")).strip()[:80]
    if not name:
        return jsonify(error="Give the preset a name."), 400
    data = json.dumps(body.get("data", {}))
    if len(data) > 100_000:
        return jsonify(error="Preset is too large."), 400
    db().execute(
        "INSERT INTO presets(user_id, name, data_json, created_at) VALUES (?,?,?,?)"
        " ON CONFLICT(user_id, name) DO UPDATE SET data_json=excluded.data_json, created_at=excluded.created_at",
        (g.user["id"], name, data, now()))
    db().commit()
    return jsonify(ok=True)


@app.delete("/api/presets/<int:pid>")
@login_required
def delete_preset(pid):
    db().execute("DELETE FROM presets WHERE id=? AND user_id=?", (pid, g.user["id"]))
    db().commit()
    return jsonify(ok=True)


# ---------------------------------------------------------------- admin
@app.get("/api/admin/users")
@admin_required
def admin_users():
    rows = db().execute(
        "SELECT u.*, (SELECT COUNT(*) FROM runs r WHERE r.user_id=u.id) AS run_count"
        " FROM users u ORDER BY u.username").fetchall()
    out = []
    for r in rows:
        d = user_dict(r)
        d["run_count"] = r["run_count"]
        out.append(d)
    return jsonify(out)


@app.post("/api/admin/users")
@admin_required
def admin_create_user():
    body = request.get_json(force=True, silent=True) or {}
    username = str(body.get("username", "")).strip()
    if not username or len(username) > 60 or not all(c.isalnum() or c in "._-@" for c in username):
        return jsonify(error="Usernames use letters, numbers and . _ - @ only."), 400
    password = body.get("password") or secrets.token_urlsafe(9)
    if len(password) < MIN_PASSWORD:
        return jsonify(error=f"Use at least {MIN_PASSWORD} characters."), 400
    try:
        db().execute(
            "INSERT INTO users(username, full_name, password_hash, is_admin, must_change, created_at)"
            " VALUES (?,?,?,?,1,?)",
            (username, str(body.get("full_name", ""))[:100], generate_password_hash(password),
             1 if body.get("is_admin") else 0, now()))
        db().commit()
    except sqlite3.IntegrityError:
        return jsonify(error="That username is already taken."), 400
    log("user_created", username)
    return jsonify(ok=True, username=username, temp_password=password), 201


@app.patch("/api/admin/users/<int:uid>")
@admin_required
def admin_update_user(uid):
    body = request.get_json(force=True, silent=True) or {}
    row = db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not row:
        abort(404)
    out = {"ok": True}
    if uid == g.user["id"] and (body.get("active") is False or body.get("is_admin") is False):
        return jsonify(error="You can't disable or demote your own account."), 400
    if "active" in body:
        db().execute("UPDATE users SET active=? WHERE id=?", (1 if body["active"] else 0, uid))
        log("user_" + ("enabled" if body["active"] else "disabled"), row["username"])
    if "is_admin" in body:
        db().execute("UPDATE users SET is_admin=? WHERE id=?", (1 if body["is_admin"] else 0, uid))
        log("user_admin_" + ("on" if body["is_admin"] else "off"), row["username"])
    if "full_name" in body:
        db().execute("UPDATE users SET full_name=? WHERE id=?", (str(body["full_name"])[:100], uid))
    if body.get("reset_password"):
        temp = secrets.token_urlsafe(9)
        db().execute("UPDATE users SET password_hash=?, must_change=1 WHERE id=?",
                     (generate_password_hash(temp), uid))
        log("password_reset", row["username"])
        out["temp_password"] = temp
    db().commit()
    return jsonify(out)


@app.get("/api/admin/activity")
@admin_required
def admin_activity():
    rows = db().execute("SELECT * FROM activity ORDER BY id DESC LIMIT 300").fetchall()
    return jsonify([dict(r) for r in rows])


@app.errorhandler(400)
@app.errorhandler(404)
@app.errorhandler(413)
def api_error(e):
    msg = getattr(e, "description", "Request failed.")
    if e.code == 413:
        msg = "The report is too large to save."
    if request.path.startswith("/api/"):
        return jsonify(error=msg), e.code
    return msg, e.code


init_db()
purge_old_runs()
if os.environ.get("RECON_PURGE_THREAD", "1") == "1":
    threading.Thread(target=_purge_loop, name="recon-cleanup", daemon=True).start()


def _cli_reset_password(username):
    """python app.py reset-password <username>  -> prints a new temporary password."""
    temp = secrets.token_urlsafe(9)
    conn = sqlite3.connect(DB_PATH)
    cur = conn.execute("UPDATE users SET password_hash=?, must_change=1, active=1 WHERE username=?",
                       (generate_password_hash(temp), username))
    conn.commit()
    conn.close()
    if cur.rowcount:
        print(f"Temporary password for {username}: {temp}  (they must change it at sign-in)")
    else:
        print(f"No user called {username}.")


if __name__ == "__main__":
    import sys
    if len(sys.argv) == 2 and sys.argv[1] == "purge":
        print(f"Removed {purge_old_runs()} run(s) older than {RETENTION_DAYS} days.")
        raise SystemExit(0)
    if len(sys.argv) == 3 and sys.argv[1] == "reset-password":
        _cli_reset_password(sys.argv[2])
        raise SystemExit(0)
    app.run(host=os.environ.get("RECON_HOST", "127.0.0.1"),
            port=int(os.environ.get("RECON_PORT", "5000")), debug=False)
