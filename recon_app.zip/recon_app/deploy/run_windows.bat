@echo off
REM Source Target Recon on Windows Server.
REM First time:  py -m venv .venv  &&  .venv\Scripts\pip install -r requirements.txt
REM Settings are read from .env next to app.py (copy .env.example to .env).
REM To run as a Windows service, install NSSM and run:
REM   nssm install Recon "%~dp0..\.venv\Scripts\waitress-serve.exe" --host 0.0.0.0 --port 8080 --threads 8 app:app
REM   nssm set Recon AppDirectory "%~dp0.."
REM   nssm start Recon
cd /d "%~dp0.."
".venv\Scripts\waitress-serve.exe" --host 0.0.0.0 --port 8080 --threads 8 app:app
