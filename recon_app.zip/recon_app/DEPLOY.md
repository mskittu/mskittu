# Source Target Recon: go-live guide

This guide takes the app from the zip file to a live HTTPS website that the whole data engineering team signs in to.

Pick **one** hosting option in step 4. Option A (a Linux server with nginx) is recommended.

---

## 1. How it works

```
 Browser (each user)                 Server (your project)                       Storage
 ───────────────────                 ─────────────────────                       ───────
 Uploads files, compares,   HTTPS    nginx / IIS  ──►  Waitress  ──►  Flask app   SQLite: data/recon.db
 builds Excel reports  ◄──────────►  (TLS, port 443)   (port 8080)    (app.py)    Reports: data/reports/
```

- **Comparisons run in each user's browser.** The source and target files are never uploaded to the server.
- **The server stores:**
  - user accounts (passwords are hashed)
  - run history (summaries only)
  - each run's Excel report
  - rule presets
  - an activity log
- **Team history** shows every run from the last 7 days with the name of the person who ran it. Anyone signed in can open a run and download its report. Runs older than `RECON_RETENTION_DAYS` (default 7) are deleted automatically, Excel file included: the app checks every hour and at start-up.
- **One Python process** (Waitress) serves the app. A reverse proxy in front of it handles HTTPS.

## 2. What you need

| Item | Recommended |
|---|---|
| Server | Linux VM (RHEL 8/9 or Ubuntu 22.04+), or Windows Server 2019+ |
| Size | 2 vCPU, 4 GB RAM, 20 GB disk for the data folder (grows with saved reports) |
| Python | 3.9 or newer, with `venv` and `pip` (or Docker instead) |
| Network | A DNS name, e.g. `recon.<your-domain>`, and port 443 open from the corporate network |
| Certificate | TLS certificate and key for that DNS name from your internal CA |
| Approvals | Info-security review and data-classification sign-off. Saved reports can contain row-level values (see section 9). |
| Packages | Access to PyPI, or your internal Artifactory/Nexus mirror |

## 3. Add the Excel library (one-time, required)

The page needs `static/xlsx.bundle.js` (SheetJS with cell styling) to build the colored Excel files. Bank networks often block public CDNs, so ship this file with the app.

**Option A: from a machine with internet access.** Download this URL and save it as `recon_app/static/xlsx.bundle.js`:

```
https://cdn.jsdelivr.net/npm/xlsx-js-style@1.2.0/dist/xlsx.bundle.js
```

**Option B: through your internal npm mirror (Artifactory/Nexus).**

```bash
npm pack xlsx-js-style@1.2.0            # uses your configured registry
tar -xzf xlsx-js-style-1.2.0.tgz package/dist/xlsx.bundle.js
cp package/dist/xlsx.bundle.js recon_app/static/xlsx.bundle.js
```

If the file is missing and the CDN is blocked, the app still works, but it shows a red banner and the Excel downloads are switched off.

> **Fonts:** the page uses Google Fonts (Sora, Manrope, JetBrains Mono). If those are blocked, it falls back to the system fonts automatically, so no action is needed.

---

## 4A. Linux server with nginx (recommended)

### 4A.1 Create the folders and service user

```bash
sudo useradd --system --home /opt/recon --shell /sbin/nologin recon
sudo mkdir -p /opt/recon/app /opt/recon/data /opt/recon/backups
```

### 4A.2 Copy the app

```bash
unzip recon_app.zip
sudo cp -r recon_app/. /opt/recon/app/          # the "/." also copies .env.example
cd /opt/recon/app
```

### 4A.3 Install Python packages

```bash
sudo python3 -m venv .venv
sudo .venv/bin/pip install -r requirements.txt
# behind a mirror:  sudo .venv/bin/pip install -r requirements.txt --index-url https://artifactory.<your-domain>/api/pypi/pypi/simple
```

### 4A.4 Configure

```bash
sudo cp .env.example .env
python3 -c "import secrets; print(secrets.token_hex(32))"   # paste the output as RECON_SECRET_KEY
sudo vi .env
```

Set at least the following in `.env`:

```
RECON_SECRET_KEY=<the long random string>
RECON_ADMIN_USER=admin
RECON_ADMIN_PASSWORD=<a strong temporary password>
RECON_DATA_DIR=/opt/recon/data
RECON_HTTPS=1
RECON_BEHIND_PROXY=1
RECON_RETENTION_DAYS=7
```

Then lock down the permissions:

```bash
sudo chown -R recon:recon /opt/recon
sudo chmod 600 /opt/recon/app/.env
```

### 4A.5 Trial run

```bash
sudo -u recon /opt/recon/app/.venv/bin/waitress-serve --host 127.0.0.1 --port 8080 app:app
# in a second terminal:
curl http://127.0.0.1:8080/healthz        # → {"status":"ok"}
```

The first start prints `First admin account created: admin / ...`. Press Ctrl+C to stop the trial.

### 4A.6 Run as a service

```bash
sudo cp /opt/recon/app/deploy/recon.service /etc/systemd/system/recon.service
sudo systemctl daemon-reload
sudo systemctl enable --now recon
sudo systemctl status recon
journalctl -u recon -f                     # live logs
```

### 4A.7 HTTPS with nginx

```bash
sudo dnf install nginx        # Ubuntu: sudo apt install nginx
sudo cp /opt/recon/app/deploy/nginx.conf /etc/nginx/conf.d/recon.conf
sudo vi /etc/nginx/conf.d/recon.conf      # set server_name and the certificate paths
sudo nginx -t && sudo systemctl enable --now nginx && sudo systemctl reload nginx
```

On RHEL with SELinux and firewalld, also run:

```bash
sudo setsebool -P httpd_can_network_connect 1
sudo firewall-cmd --permanent --add-service=https && sudo firewall-cmd --reload
```

**To host under a sub-path** (e.g. `https://tools.<your-domain>/recon/`): use the commented `location /recon/` block in `nginx.conf`. The app picks up the prefix automatically.

### 4A.8 Nightly backup

```bash
sudo dnf install sqlite        # Ubuntu: sudo apt install sqlite3
sudo crontab -u recon -e
# add:
30 2 * * * /opt/recon/app/deploy/backup.sh >> /opt/recon/backups/backup.log 2>&1
```

---

## 4B. Docker / OpenShift / Kubernetes

1. Add `static/xlsx.bundle.js` (step 3), then build and run:

   ```bash
   cd recon_app
   cp .env.example .env && vi .env           # set RECON_SECRET_KEY and RECON_ADMIN_PASSWORD; RECON_DATA_DIR is set to /data
   docker compose up -d --build
   curl http://localhost:8080/healthz
   ```

2. Keep the `/data` volume on persistent storage. In Kubernetes, use a PersistentVolumeClaim and **exactly 1 replica**, because SQLite is a single-writer database.
3. Put your ingress or route in front with TLS, and set `RECON_BEHIND_PROXY=1` and `RECON_HTTPS=1`.
4. Point liveness and readiness probes at `GET /healthz`.

---

## 4C. Windows Server

1. Install Python 3.12 (tick "Add to PATH").
2. Unzip to `D:\Recon\app`, then add `static\xlsx.bundle.js` (step 3).
3. Install the packages:

   ```bat
   cd /d D:\Recon\app
   py -m venv .venv
   .venv\Scripts\pip install -r requirements.txt
   copy .env.example .env
   notepad .env
   ```

   Set `RECON_DATA_DIR=D:\Recon\data`.
4. Do a trial run with `deploy\run_windows.bat`, then open `http://localhost:8080`.
5. Run it as a service with [NSSM](https://nssm.cc). The commands are at the top of `run_windows.bat`.
6. **HTTPS:** in IIS, install URL Rewrite and Application Request Routing (ARR). Add an HTTPS binding with your certificate, then add a reverse-proxy rule to `http://127.0.0.1:8080`. Set `RECON_BEHIND_PROXY=1` and `RECON_HTTPS=1`.
7. **Backup:** use Task Scheduler to copy `D:\Recon\data` nightly while the service is stopped, or use `sqlite3 recon.db ".backup ..."`.

---

## 5. First sign-in and onboarding the team

1. Open `https://recon.<your-domain>` and sign in as `admin` with the password from `.env`.
2. Choose a new password when asked. After that, clear `RECON_ADMIN_PASSWORD` from `.env`, since it's no longer used.
3. Go to the **Admin** tab, then **Add a user** for each team member. Tick **Admin** for anyone else who should manage users (for example Harleen and Kushal).
4. Share each temporary password privately (Teams chat, not email). Everyone sets their own password at first sign-in.
5. Send the team the URL and a one-line intro, for example: *"Recon is live at https://recon.<your-domain>. Sign in with the username I sent you."*

## 6. Go-live checklist

- [ ] `static/xlsx.bundle.js` is present (no red banner on the page)
- [ ] `.env` has a unique `RECON_SECRET_KEY`, and the file is readable only by the service account
- [ ] `https://` works with a valid internal certificate, and `http://` redirects to it
- [ ] `/healthz` returns `{"status":"ok"}`, and monitoring is set up for it
- [ ] The admin password has been changed, and at least two admins exist
- [ ] One test run of each tool works, and an Excel download opens with colors (try a custom file name)
- [ ] Each tool's run appears in **Team history** under your name, and a colleague can open it and download the report
- [ ] `RECON_RETENTION_DAYS` is set to the period info-security approved (default 7)
- [ ] Nightly backup is scheduled, and one restore has been tested (section 7)
- [ ] Info-security and data-classification approval is recorded

## 7. Running it day to day

| Task | How |
|---|---|
| See logs | `journalctl -u recon -f` (Linux), the NSSM log (Windows), `docker compose logs -f` |
| Restart | `sudo systemctl restart recon` |
| Reset someone's password | Admin tab → **Reset password** → share the temporary password |
| Remove a leaver | Admin tab → **Disable**. Their history is kept. |
| Back up | `deploy/backup.sh` (database and reports) |
| Restore | Stop the service, copy `recon_<date>.db` to `data/recon.db`, unpack `reports_<date>.tar.gz` into `data/`, start the service |
| Update to a new version | Back up first. Then replace the app files but **keep `.env` and `data/`**, run `pip install -r requirements.txt`, and restart. The database schema is created and upgraded automatically. |
| Remove old runs right now | `python app.py purge` (also runs automatically every hour) |
| Change how long runs are kept | Set `RECON_RETENTION_DAYS` in `.env` and restart |
| Sign everyone out | Change `RECON_SECRET_KEY` and restart |

## 8. Troubleshooting

| What you see | Fix |
|---|---|
| Red banner: "Excel downloads are switched off" | Add `static/xlsx.bundle.js` (step 3) |
| "Your session expired. Reload the page" | Reload. If it happens constantly, check `RECON_HTTPS=1` is only set when the site really is on HTTPS. |
| Sign-in works, then you're immediately signed out | Same cause: the secure cookie is set over plain HTTP. Use HTTPS or set `RECON_HTTPS=0` for a trial. |
| 502 Bad Gateway from nginx | The service isn't running (`systemctl status recon`), or SELinux is blocking it (`setsebool -P httpd_can_network_connect 1`). |
| "The report is too large to save" | Raise `RECON_MAX_UPLOAD_MB` and nginx `client_max_body_size` together |
| Activity log shows the proxy's IP for everyone | Set `RECON_BEHIND_PROXY=1`, and make sure nginx sends `X-Forwarded-For` |
| "Too many failed attempts" | Wait 5 minutes, or have an admin reset the password |
| Browser slows down on very large files | The in-browser compare is comfortable up to a few hundred thousand rows. Split bigger files, or see section 10. |
| Lost the admin password | On the server: `sudo -u recon /opt/recon/app/.venv/bin/python /opt/recon/app/app.py reset-password admin` prints a new temporary password (Windows: `.venv\Scripts\python app.py reset-password admin`). |

## 9. Security and data notes

- **Files stay on the user's computer.** Comparisons happen in the browser, and only summaries and the Excel reports go to the server.
- **Saved Excel reports can include row-level values** (names, IDs, amounts), and **everyone signed in can download every report in Team history**. Only create accounts for people allowed to see this data, and confirm this with info-security.
- **Retention:** runs and reports are deleted after `RECON_RETENTION_DAYS` (default 7). Backups follow the same period by default (`RECON_BACKUP_KEEP_DAYS`).
- **Deleting runs:** only the person who ran it, or an admin, can delete it early. Downloads of someone else's report are recorded in the activity log.
- **Sign-in protection:**
  - Passwords are hashed with Werkzeug's scrypt/pbkdf2.
  - An account locks for 5 minutes after 5 failed sign-ins.
  - Every change requires a CSRF token, and cookies are HttpOnly, SameSite=Lax, and Secure under HTTPS.
  - Users can only open their own runs and reports.
- **Single sign-on:** if your organisation requires SSO, put the app behind your SSO gateway and change the `login()` route in `app.py` to trust the user header your gateway sets.
- **Updates:** keep Python, Flask and Waitress patched (`pip install -U -r requirements.txt` during maintenance).

## 10. Customising and scaling

| Change | Where |
|---|---|
| Logo on the sign-in card | Replace `static/logo.png` (PNG, about 400 px wide, transparent background) |
| "Implemented by" team credit | `templates/login.html`, the `credit` block |
| Colors | The `:root` tokens at the top of the theme layer in `templates/index.html` and `templates/login.html` |
| Tool descriptions | The `pane-head` blocks in `templates/index.html` |

**Scale:** SQLite is fine for a team of tens of users. For hundreds of users, or more than one server, move to PostgreSQL. For very large data sets, add a server-side compare with pandas, or Spark over Hive tables.
