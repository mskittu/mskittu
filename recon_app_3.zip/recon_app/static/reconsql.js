/* Recon query builder: CREATE TABLE in, one reconciliation query per side out.
   Numeric columns -> SUM(col). Text and other scalar columns -> SUM(ASCII(col)) or SUM(LENGTH(col)).
   Each side is written in its own connection's SQL (Hive / Impala / Oracle / Athena / Redshift / SQLite demo). */
(function () {
  const $ = id => document.getElementById(id);
  const R = window.Recon, Q = window.ReconQuery;
  if (!R || !Q || !$('rqHelp')) return;
  const esc = R.esc;
  let TABLE = null, auto = { src: '', tgt: '' }, LAST = null;

  const SKIP = /^(ARRAY|MAP|STRUCT|UNIONTYPE|BINARY)\b/;
  function kindOf(type) {
    const f = R.typeFamily(type || '');
    if (SKIP.test(f)) return 'skip';
    if (f === 'INTEGER' || f === 'FLOAT' || /^DECIMAL/.test(f)) return 'num';
    if (f === 'TEXT') return 'txt';
    if (f === 'DATE') return 'date';
    if (f === 'TIMESTAMP' || f === 'TIMESTAMPTZ') return 'ts';
    return 'other';  // BOOLEAN and anything unrecognised: measured as text
  }
  const LABEL = { num: 'SUM', txt: 'TEXT', date: 'DATE', ts: 'TIMESTAMP', other: 'TEXT', skip: 'SKIPPED' };

  function dialectOf(c) {
    if (!c) return 'hive';
    if (c.type === 'hue') return c.dialect === 'impala' ? 'impala' : 'hive';
    return c.type;  // hive, oracle, athena, redshift, sqlite
  }
  const SIMPLE = /^[A-Za-z_][A-Za-z0-9_]*$/;
  function ident(name, d) {
    if (SIMPLE.test(name)) return name;
    return (d === 'hive' || d === 'impala') ? '`' + name.replace(/`/g, '``') + '`' : '"' + name.replace(/"/g, '""') + '"';
  }
  function asText(x, kind, d) {
    if (kind === 'txt') return x;
    if (d === 'oracle') return kind === 'date' ? `TO_CHAR(${x}, 'YYYY-MM-DD')` : kind === 'ts' ? `TO_CHAR(${x}, 'YYYY-MM-DD HH24:MI:SS')` : `TO_CHAR(${x})`;
    if (d === 'hive' || d === 'impala') return `CAST(${x} AS STRING)`;
    if (d === 'sqlite') return `CAST(${x} AS TEXT)`;
    return `CAST(${x} AS VARCHAR)`;  // athena, redshift
  }
  function textMeasure(side, d) {
    const v = $(side === 'src' ? 'rqSrcText' : 'rqTgtText').value;
    if (d === 'redshift') return 'length';  // Redshift ASCII() is leader-node only: it can't read table rows
    if (v === 'auto') return d === 'athena' ? 'length' : 'ascii';
    return v;
  }
  function textExpr(x, m, d) {
    if (m === 'length') return `LENGTH(${x})`;
    if (d === 'athena') return `CASE WHEN length(${x}) > 0 THEN codepoint(CAST(substr(${x}, 1, 1) AS varchar(1))) END`;
    if (d === 'sqlite') return `unicode(${x})`;
    return `ASCII(${x})`;
  }
  function aliasFor(prefix, name, used) {
    let a = (prefix + '_' + name).toLowerCase().replace(/[^a-z0-9_]/g, '_').slice(0, 30), n = 2;
    while (used.has(a)) { const sfx = '_' + n++; a = a.slice(0, 30 - sfx.length) + sfx; }
    used.add(a); return a;
  }

  function buildSql(side) {
    const c = Q.conn(side), d = dialectOf(c), m = textMeasure(side, d);
    const table = $(side === 'src' ? 'rqSrcTable' : 'rqTgtTable').value.trim();
    const where = $(side === 'src' ? 'rqSrcWhere' : 'rqTgtWhere').value.trim().replace(/^where\s+/i, '');
    const grp = $('rqGroup').value, trim = $('rqTrim').checked;
    if (!table) throw new Error(`Enter the ${side === 'src' ? 'source' : 'target'} table.`);
    if (!/^[A-Za-z_][A-Za-z0-9_$#.`"]*$/.test(table)) throw new Error(`"${table}" is not a valid table name.`);
    if (where.includes(';')) throw new Error('Remove the ";" from the filter.');
    const used = new Set(['row_count']), lines = [];
    const g = grp ? ident(grp, d) : '';
    if (grp) { const a = grp.toLowerCase().replace(/[^a-z0-9_]/g, '_').slice(0, 30); used.add(a); lines.push(`${g} AS ${a}`); }
    lines.push('COUNT(*) AS row_count');
    picked().forEach(col => {
      const x = ident(col.name, d);
      if (col.kind === 'num') { lines.push(`COALESCE(SUM(${x}), 0) AS ${aliasFor('sum', col.name, used)}`); return; }
      let t = asText(x, col.kind, d); if (trim) t = `TRIM(${t})`;
      lines.push(`COALESCE(SUM(${textExpr(t, m, d)}), 0) AS ${aliasFor(m === 'length' ? 'len' : 'asc', col.name, used)}`);
    });
    let sql = `SELECT ${lines.join(',\n       ')}\nFROM ${table}`;
    if (where) sql += `\nWHERE ${where}`;
    if (grp) sql += `\nGROUP BY ${g}\nORDER BY ${g}`;
    return { sql, measure: m, dialect: d, conn: c };
  }

  function picked() {
    if (!TABLE) return [];
    const on = new Set([...$('rqCols').querySelectorAll('input:checked')].map(i => i.value));
    return TABLE.cols.filter(c => on.has(c.name) && c.kind !== 'skip' && c.name !== $('rqGroup').value);
  }

  function readDdl() {
    const text = $('rqDdl').value;
    TABLE = null;
    if (!text.trim()) { $('rqCols').innerHTML = '<span class="note">Paste or fetch a CREATE TABLE to list its columns.</span>'; $('rqColsLabel').textContent = 'Columns'; return; }
    const parsed = R.parseDDL(text), t = parsed.tables.find(x => x.cols.length);
    if (!t) { $('rqCols').innerHTML = `<span class="note">${esc(parsed.notes[0] || 'No CREATE TABLE with a column list found.')}</span>`; return; }
    TABLE = { name: t.name, cols: t.cols.map(c => ({ name: c.name, type: c.type, kind: kindOf(c.type), partition: c.partition })) };
    ['src', 'tgt'].forEach(side => {
      const el = $(side === 'src' ? 'rqSrcTable' : 'rqTgtTable');
      if (!el.value.trim() || el.value === auto[side]) { el.value = t.name; auto[side] = t.name; }
    });
    const n = TABLE.cols.filter(c => c.kind === 'num').length, sk = TABLE.cols.filter(c => c.kind === 'skip').length;
    $('rqColsLabel').textContent = `Columns in ${t.name}: ${TABLE.cols.length} (${n} summed, ${TABLE.cols.length - n - sk} text/date${sk ? `, ${sk} skipped` : ''})`;
    $('rqCols').innerHTML = TABLE.cols.map(c => `<label class="${c.kind === 'skip' ? 'off' : ''}" title="${esc(c.type)}"><input type="checkbox" value="${esc(c.name)}"${c.kind === 'skip' ? ' disabled' : ' checked'}> ${esc(c.name)}<span class="rqtag ${c.kind === 'num' ? 'num' : c.kind === 'skip' ? '' : 'txt'}">${LABEL[c.kind]}</span></label>`).join('');
    const prev = $('rqGroup').value;
    $('rqGroup').innerHTML = '<option value="">Whole table (one row)</option>' + TABLE.cols.filter(c => c.kind !== 'skip')
      .map(c => `<option value="${esc(c.name)}">${esc(c.name)}${c.partition ? ' (partition)' : ''}</option>`).join('');
    if (prev && TABLE.cols.some(c => c.name === prev)) $('rqGroup').value = prev;
    if (parsed.tables.length > 1) R.toast('toastRq', `Using the first table (${t.name}).`, true);
  }

  function build() {
    if (!TABLE) throw new Error('Paste or fetch a CREATE TABLE first.');
    if (!picked().length) throw new Error('Tick at least one column.');
    const out = { src: buildSql('src'), tgt: buildSql('tgt') };
    const warn = out.src.measure !== out.tgt.measure && picked().some(c => c.kind !== 'num')
      ? ` Note: source uses ${out.src.measure.toUpperCase()} and target uses ${out.tgt.measure.toUpperCase()} for text, so text columns won't match. Pick the same on both sides to compare them.` : '';
    LAST = out;
    return { out, warn };
  }

  function put() {
    const { out, warn } = build();
    Q.setMode('query');
    ['src', 'tgt'].forEach(side => {
      $('qsql-' + side).value = out[side].sql;
      $('qsql-' + side).dispatchEvent(new Event('change'));
    });
    R.S.built = { src: out.src.sql, tgt: out.tgt.sql, key: $('rqGroup').value || '__pos' };
    return warn;
  }

  $('rqDdl').addEventListener('input', () => { clearTimeout(readDdl.t); readDdl.t = setTimeout(readDdl, 250); });
  $('rqPut').addEventListener('click', () => {
    try { const w = put(); R.toast('toastRq', 'Queries are in the Source and Target boxes above.' + w, !w); $('decks').scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    catch (e) { R.toast('toastRq', e.message, false); }
  });
  $('rqRun').addEventListener('click', () => {
    try {
      const w = put(); R.tab('cmp');
      R.toast('toastRq', 'Queries built and sent to Run.' + w, !w);
      $('qRun').click();
      $('decks').scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (e) { R.toast('toastRq', e.message, false); }
  });
  async function copy(side) {
    try {
      const sql = build().out[side].sql;
      try { await navigator.clipboard.writeText(sql); }
      catch (e) { const ta = document.createElement('textarea'); ta.value = sql; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove(); }
      R.toast('toastRq', `${side === 'src' ? 'Source' : 'Target'} SQL copied.`, true);
    } catch (e) { R.toast('toastRq', e.message, false); }
  }
  $('rqCopySrc').addEventListener('click', () => copy('src'));
  $('rqCopyTgt').addEventListener('click', () => copy('tgt'));

  $('rqFetch').addEventListener('click', async () => {
    const c = Q.conn('src'), t = $('rqFetchTable').value.trim();
    if (!c) { R.toast('toastRq', 'Pick a source connection above first.', false); return; }
    if (!t) { R.toast('toastRq', 'Enter the table to fetch, e.g. imp.loan_impairments', false); return; }
    const cred = {}; $('qcred-src').querySelectorAll('input').forEach(i => { cred[i.dataset.key] = i.value; });
    $('rqFetch').disabled = true; R.toast('toastRq', 'Reading the table definition…', true);
    try {
      const out = await Q.api('/api/ddl/fetch', { method: 'POST', json: { source: { connection_id: c.id, tables: t, credentials: cred } } });
      const r = out.source || {};
      if (r.error) throw new Error(r.error);
      $('rqDdl').value = r.ddl; readDdl();
      R.toast('toastRq', `Fetched ${t} from ${c.name}.`, true);
    } catch (e) { R.toast('toastRq', e.message, false); }
    $('rqFetch').disabled = false;
  });

  window.ReconSql = { build: () => build().out, read: readDdl, dialectOf };
})();
