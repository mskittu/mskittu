/* Server features: per-user history, saved reports, rule presets, admin. */
(function () {
  const $ = id => document.getElementById(id);
  const R = window.Recon;
  const ME = window.RECON_ME, CSRF = window.RECON_CSRF, BASE = window.RECON_BASE || '';
  const esc = R.esc;
  const KIND_LABEL = { compare: 'Compare records', stats: 'Statistics', dq: 'Data quality', code: 'Code compare', ddl: 'DDL compare', json: 'JSON compare', trend: 'Trends' };

  async function api(path, opts = {}) {
    const headers = { 'X-CSRF-Token': CSRF };
    let body = opts.body;
    if (opts.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.json); }
    const res = await fetch(BASE + path, { method: opts.method || 'GET', headers, body, credentials: 'same-origin' });
    if (res.status === 401) { location.href = BASE + '/login'; throw new Error('Signed out'); }
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Request failed (' + res.status + ').');
    return data;
  }
  const when = s => { if (!s) return '—'; const d = new Date(s.replace(' ', 'T') + 'Z'); return isNaN(d) ? s : d.toLocaleString(); };
  const size = n => n == null ? '' : n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : (n / 1048576).toFixed(1) + ' MB';

  /* ---------- Excel library check ---------- */
  if (!window.XLSX) {
    const warn = document.createElement('div');
    warn.setAttribute('role', 'alert');
    warn.style.cssText = 'background:var(--bad-soft);color:var(--bad);border:1px solid var(--bad);border-radius:12px;padding:12px 16px;font-weight:700';
    warn.textContent = 'Excel downloads are switched off: static/xlsx.bundle.js is missing and the CDN is blocked. Ask your Recon admin to add the file (see DEPLOY.md, step 3).';
    document.querySelector('main.wrap').prepend(warn);
  }

  /* ---------- header ---------- */
  $('whoName').textContent = ME.full_name || ME.username;
  if (ME.is_admin) { $('roleChip').hidden = false; $('tab-admin').hidden = false; }
  if (ME.auth_source === 'hue') $('btnPw').hidden = true;  // Hue / LDAP password: changed the usual company way

  /* ---------- password dialog ---------- */
  const dlg = $('pwDlg');
  function openPw(forced) {
    $('pwForm').reset(); $('pwErr').textContent = '';
    $('pwTitle').textContent = forced ? 'Set your own password' : 'Change password';
    $('pwHint').textContent = forced ? 'You signed in with a temporary password. Choose a new one to continue.' : '';
    $('pwCancel').hidden = !!forced;
    dlg.dataset.forced = forced ? '1' : '';
    dlg.showModal(); $('pwCur').focus();
  }
  dlg.addEventListener('cancel', e => { if (dlg.dataset.forced) e.preventDefault(); });
  $('pwCancel').addEventListener('click', () => dlg.close());
  $('btnPw').addEventListener('click', () => openPw(false));
  $('pwForm').addEventListener('submit', async e => {
    e.preventDefault();
    const cur = $('pwCur').value, n1 = $('pwNew').value, n2 = $('pwNew2').value;
    if (n1.length < 8) { $('pwErr').textContent = 'Use at least 8 characters.'; return; }
    if (n1 !== n2) { $('pwErr').textContent = 'The two new passwords are different.'; return; }
    try {
      await api('/api/me/password', { method: 'POST', json: { current: cur, new: n1 } });
      const wasForced = !!dlg.dataset.forced; dlg.dataset.forced = ''; dlg.close();
      ME.must_change = false;
      if (wasForced) { loadPresets(); if (window.ReconQuery) window.ReconQuery.reload(); }
    } catch (err) { $('pwErr').textContent = err.message; }
  });
  if (ME.must_change) openPw(true);

  /* ---------- save every run to history ---------- */
  const TOAST = { compare: 'toastCmp', stats: 'toastStat', dq: 'toastDQ', code: 'toastCode', ddl: 'toastDDL', json: 'toastJSON', trend: 'toastTrend' };
  function isSample() { return /\(example\)$/.test(R.S.src?.name || '') || /\(example\)$/.test(R.S.tgt?.name || ''); }
  function describe(kind) {
    const S = R.S;
    if (kind === 'compare') {
      const X = S.result, colMismatch = {};
      S.pairs.forEach((p, k) => { if (X.colBad[k]) colMismatch[p.name] = X.colBad[k]; });
      const bad = X.rows.length - X.goodRows;
      return {
        title: `${S.src.name} vs ${S.tgt.name}`, wb: window.XLSX ? R.buildCompareWb() : null, file: 'compared_results',
        summary: {
          text: `${X.rows.length} rows · ${X.goodRows} matched · ${bad} with differences` + (X.srcOnly ? ` · ${X.srcOnly} source only` : '') + (X.tgtOnly ? ` · ${X.tgtOnly} target only` : ''),
          status: bad ? 'FAIL' : 'PASS', rows: X.rows.length, matched: X.goodRows, different: bad, source_only: X.srcOnly, target_only: X.tgtOnly,
          matched_by: X.keyLabel, column_mismatches: colMismatch, columns_compared: S.pairs.length,
          columns_only_in_source: X.onlySrcCols, columns_only_in_target: X.onlyTgtCols
        }
      };
    }
    if (kind === 'stats') {
      const rows = S.stats.rows, mi = S.stats.header.indexOf('match'), off = rows.filter(r => r[mi] === false).length;
      return {
        title: `Statistics · ${S.src ? S.src.name : '—'}${S.tgt ? ' vs ' + S.tgt.name : ''}`, wb: window.XLSX ? R.buildStatsWb() : null, file: 'statistics',
        summary: { text: `${rows.length} figures · ${off} not matching`, status: off ? 'FAIL' : 'PASS', figures: rows.length, not_matching: off }
      };
    }
    if (kind === 'dq') {
      const D = S.dq, pass = D.sum.filter(r => r[5] === 'PASS').length, fail = D.sum.filter(r => r[5] === 'FAIL').length;
      return {
        title: `Data quality · ${[S.src, S.tgt].filter(Boolean).map(x => x.name).join(' / ')}`, wb: window.XLSX ? R.buildDQWb() : null, file: 'validation_report',
        summary: {
          text: `${pass} checks passed · ${fail} failed · ${D.det.length} failed rows`, status: fail ? 'FAIL' : 'PASS',
          checks: D.sum.map(r => ({ check: r[0], side: r[1], columns: r[2], failed_rows: r[4], status: r[5] }))
        }
      };
    }
    if (kind === 'code') {
      const c = S.code.counts, diff = c.chg + c.del + c.add;
      const src = $('codeSrc').value, tgt = $('codeTgt').value;
      const first = (src.split('\n').find(l => l.trim()) || 'code').trim().slice(0, 60);
      return {
        title: 'Code · ' + first, wb: window.XLSX ? R.buildCodeWb() : null, file: 'code_compare',
        summary: {
          text: diff ? `${c.chg} changed · ${c.del} only in source · ${c.add} only in target` : 'Identical',
          status: diff ? 'FAIL' : 'PASS', same: c.same, changed: c.chg, only_in_source: c.del, only_in_target: c.add,
          source_code: src.length <= 400000 ? src : null, target_code: tgt.length <= 400000 ? tgt : null
        }
      };
    }
    if (kind === 'trend') {
      const T = S.trend, sm = T.summary, o = T.opts, bad = sm.unusual + sm.mismatches;
      return {
        title: `Trends · ${[S.src, S.tgt].filter(Boolean).map(x => x.name).join(' vs ')}`, wb: window.XLSX ? R.buildTrendWb() : null, file: 'monthly_trends',
        summary: {
          text: `${o.cdes.join(', ')} · ${sm.periods} periods (${sm.from} to ${sm.to}) · ${sm.unusual} unusual changes` + (S.src && S.tgt ? ` · ${sm.mismatches} source/target mismatches` : ''),
          status: bad ? 'FAIL' : 'PASS', cdes: o.cdes, measure: `${o.gran} ${o.agg}`, periods: sm.periods, unusual: sm.unusual, mismatches: sm.mismatches,
          directions: Object.fromEntries(Object.entries(T.series).map(([n, s]) => [n, { source: s.dirSrc && s.dirSrc.label, target: s.dirTgt && s.dirTgt.label, source_total: s.totSrc, target_total: s.totTgt }]))
        }
      };
    }
    if (kind === 'ddl') {
      const D = S.ddl, c = D.cnt, n = c.diff + c.src + c.tgt + c.props + c.tblSrc + c.tblTgt;
      const names = [...new Set(D.rows.map(r => r[0]))];
      return {
        title: 'DDL · ' + (names.slice(0, 3).join(', ') + (names.length > 3 ? ` +${names.length - 3} more` : '')), wb: window.XLSX ? R.buildDdlWb() : null, file: 'ddl_compare',
        summary: {
          text: n ? `${c.tables} tables · ${c.diff} columns different · ${c.src} only in source · ${c.tgt} only in target · ${c.props} property differences` : `${c.tables} tables · identical`,
          status: n ? 'FAIL' : 'PASS', tables: c.tables, same: c.same, different: c.diff, only_in_source: c.src, only_in_target: c.tgt, property_differences: c.props,
          source_code: D.src.length <= 400000 ? D.src : null, target_code: D.tgt.length <= 400000 ? D.tgt : null
        }
      };
    }
    if (kind === 'json') {
      const J = S.json, c = J.cnt, n = c.changed + c.type + c.added + c.removed;
      return {
        title: 'JSON · ' + (n ? n + ' differences' : 'identical'), wb: window.XLSX ? R.buildJsonWb() : null, file: 'json_compare',
        summary: {
          text: n ? `${c.changed} changed · ${c.type} type changed · ${c.removed} only in source · ${c.added} only in target` : 'Identical',
          status: n ? 'FAIL' : 'PASS', same: c.same, changed: c.changed, type_changed: c.type, only_in_source: c.removed, only_in_target: c.added,
          source_code: J.src.length <= 400000 ? J.src : null, target_code: J.tgt.length <= 400000 ? J.tgt : null
        }
      };
    }
  }
  window.ReconHooks = {
    async onRun(kind) {
      if (['compare', 'stats', 'dq', 'trend'].includes(kind) && isSample()) return; // don't save the built-in example files
      const t = $(TOAST[kind]), base = t.textContent;
      try {
        const d = describe(kind);
        const q = ['compare', 'stats', 'dq', 'trend'].includes(kind) && window.ReconQuery ? window.ReconQuery.current() : null;
        if (q) { d.summary.query = q; const nm = [q.source, q.target].filter(Boolean).map(x => x.connection); d.title = (kind === 'compare' ? '' : KIND_LABEL[kind] + ' · ') + nm.join(' vs '); }
        const fd = new FormData();
        fd.append('meta', JSON.stringify({ kind, title: d.title, src_name: R.S.src?.name || '', tgt_name: R.S.tgt?.name || '', summary: d.summary }));
        if (d.wb) {
          const buf = XLSX.write(d.wb, { bookType: 'xlsx', type: 'array' });
          const KMAP = { compare: 'cmp', stats: 'stat', dq: 'dq', code: 'code', ddl: 'ddl', json: 'json', trend: 'trend' };
          const fname = R.fileNameFor ? R.fileNameFor(KMAP[kind]) : d.file + '_' + R.stamp() + '.xlsx';
          fd.append('report', new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }), fname);
        }
        await api('/api/runs', { method: 'POST', body: fd });
        t.textContent = base + ' Saved to Team history.';
        if (!$('pane-hist').hidden) loadHistory();
      } catch (err) { t.textContent = base + ' Not saved to history: ' + err.message; t.className = 'toast bad'; }
    }
  };

  /* ---------- team history ---------- */
  let HIST = [], RETAIN = 7, qTimer = null;
  const initials = n => (String(n || '?').trim().split(/[\s._-]+/).map(w => w[0]).join('').slice(0, 2) || '?').toUpperCase();
  const dayLabel = s => {
    const d = new Date(s.replace(' ', 'T') + 'Z'); if (isNaN(d)) return s;
    const t = new Date(), y = new Date(); y.setDate(t.getDate() - 1);
    const hm = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    if (d.toDateString() === t.toDateString()) return 'Today ' + hm;
    if (d.toDateString() === y.toDateString()) return 'Yesterday ' + hm;
    return d.toLocaleDateString([], { day: '2-digit', month: 'short' }) + ' ' + hm;
  };
  const leftLabel = s => {
    const ms = new Date(s.replace(' ', 'T') + 'Z') - new Date();
    if (ms <= 0) return 'today';
    const days = Math.floor(ms / 86400000), hrs = Math.floor(ms / 3600000);
    return days >= 1 ? `in ${days} day${days > 1 ? 's' : ''}` : `in ${Math.max(1, hrs)} h`;
  };
  async function loadHistory() {
    const q = new URLSearchParams({ limit: 500 });
    if ($('histKind').value) q.set('kind', $('histKind').value);
    if ($('histWho').value === 'mine') q.set('who', 'mine');
    if ($('histQ').value.trim()) q.set('q', $('histQ').value.trim());
    try {
      const out = await api('/api/runs?' + q);
      HIST = out.runs; RETAIN = out.retention_days;
      $('histKeep').textContent = `Everyone on the team can open and download these runs. Each run is kept for ${RETAIN} days, then removed automatically.`;
      const people = new Set(HIST.map(r => r.user_id)).size, mine = HIST.filter(r => r.user_id === ME.id).length, failed = HIST.filter(r => r.summary.status === 'FAIL').length;
      $('histSummary').innerHTML = `<div class="pill"><span>Runs shown</span><b>${HIST.length}</b></div><div class="pill ok"><span>Run by you</span><b>${mine}</b></div>` +
        `<div class="pill"><span>People</span><b>${people}</b></div><div class="pill ${failed ? 'bad' : 'ok'}"><span>With differences</span><b>${failed}</b></div>`;
      if (!HIST.length) { $('histTable').innerHTML = `<p class="note" style="padding:14px;margin:0">No runs in the last ${RETAIN} days${$('histQ').value.trim() || $('histKind').value || $('histWho').value === 'mine' ? ' match these filters' : ''}. Run any compare and it appears here under your name.</p>`; return; }
      $('histTable').innerHTML = '<table><tr><th>Run by</th><th>When</th><th>Tool</th><th>Run</th><th>Result</th><th>Status</th><th>Report</th><th>Removed</th><th></th></tr>' +
        HIST.map(r => `<tr class="${r.user_id === ME.id ? 'mine' : ''}"><td><span class="who-cell"><i>${esc(initials(r.full_name))}</i><span>${esc(r.full_name)}${r.user_id === ME.id ? ' <em>(you)</em>' : ''}<small>${esc(r.username)}</small></span></span></td>` +
          `<td>${esc(dayLabel(r.created_at))}</td><td>${esc(KIND_LABEL[r.kind] || r.kind)}</td>` +
          `<td class="tdtext">${esc(r.title)}</td><td class="tdtext">${esc(r.summary.text || '')}</td>` +
          `<td class="${r.summary.status === 'PASS' ? 'T' : r.summary.status === 'FAIL' ? 'F' : 'miss'}">${esc(r.summary.status || '')}</td>` +
          `<td>${r.has_report ? `<a class="linkbtn" href="${BASE}/api/runs/${r.id}/report" title="${esc(r.report_name || '')}">Download</a> <span class="note">${size(r.report_size)}</span>` : '—'}</td>` +
          `<td><span class="expiry">${esc(leftLabel(r.expires_at))}</span></td>` +
          `<td><button class="linkbtn" data-open="${r.id}" type="button">Open</button>${r.can_delete ? `<button class="linkbtn" data-del="${r.id}" type="button">Delete</button>` : ''}</td></tr>`).join('') + '</table>';
    } catch (err) { R.toast('toastHist', err.message, false); }
  }
  function showRun(r) {
    const s = r.summary, d = $('histDetail');
    const REOPEN = { ddl: ['ddlSrc', 'ddlTgt', 'ddl', 'compareDDL', 'toastDDL'], json: ['jsSrc', 'jsTgt', 'json', 'compareJSON', 'toastJSON'], code: ['codeSrc', 'codeTgt', 'code', 'compareCode', 'toastCode'] };
    if (REOPEN[r.kind] && s.source_code != null) {
      const [a, b, t, fn, ts] = REOPEN[r.kind];
      $(a).value = s.source_code; $(b).value = s.target_code || '';
      R.tab(t); R[fn](); R.toast(ts, `Loaded ${r.full_name}'s run from ${dayLabel(r.created_at)}.`, true); return;
    }
    const rows = [['Run by', `${r.full_name} (${r.username})`], ['Tool', KIND_LABEL[r.kind]], ['When', when(r.created_at)], ['Removed', when(r.expires_at)], ['Source', r.src_name], ['Target', r.tgt_name], ['Result', s.text], ['Status', s.status]];
    if (s.matched_by) rows.push(['Rows matched by', s.matched_by]);
    if (s.checks == null && s.figures != null) rows.push(['Figures', `${s.figures} (${s.not_matching} not matching)`]);
    if (s.column_mismatches && Object.keys(s.column_mismatches).length) rows.push(['Mismatches by column', Object.entries(s.column_mismatches).map(([k, v]) => k + ': ' + v).join(', ')]);
    if (s.columns_only_in_source?.length) rows.push(['Only in source', s.columns_only_in_source.join(', ')]);
    if (s.columns_only_in_target?.length) rows.push(['Only in target', s.columns_only_in_target.join(', ')]);
    if (s.checks) s.checks.forEach(c => rows.push([`${c.check} · ${c.side} · ${c.columns}`, `${c.status}${c.failed_rows !== '' ? ' (' + c.failed_rows + ' rows)' : ''}`]));
    if (s.query) {
      if (s.query.source) rows.push([`Source query · ${s.query.source.connection}`, s.query.source.sql + (s.query.source.truncated ? '  [stopped at row limit]' : '')]);
      if (s.query.target) rows.push([`Target query · ${s.query.target.connection}`, s.query.target.sql + (s.query.target.truncated ? '  [stopped at row limit]' : '')]);
    }
    d.innerHTML = `<h3>${esc(r.title)}</h3><dl class="kv">${rows.filter(x => x[1] != null && x[1] !== '').map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join('')}</dl>` +
      `<div class="actions">${r.has_report ? `<a class="btn primary" style="text-decoration:none;background:var(--accent);color:var(--accent-ink);border-color:var(--accent)" href="${BASE}/api/runs/${r.id}/report">Download Excel report</a>` : ''}${s.query && window.ReconQuery ? '<button type="button" id="histLoadQ">Load these queries</button>' : ''}<button type="button" id="histClose">Close</button></div>`;
    d.hidden = false; $('histClose').addEventListener('click', () => { d.hidden = true; });
    if ($('histLoadQ')) $('histLoadQ').addEventListener('click', () => {
      const q = s.query, a = q.source || {}, b = q.target || {}, miss = window.ReconQuery.load({ src_conn: a.connection_id, tgt_conn: b.connection_id, src_sql: a.sql || '', tgt_sql: b.sql || '', src_name: a.connection, tgt_name: b.connection, tab: { stats: 'stat', dq: 'dq', trend: 'trend' }[r.kind] || 'cmp' });
      R.toast('toastQ', miss.length ? `Loaded the queries. These connections no longer exist: ${miss.join(', ')}.` : `Loaded ${r.full_name}'s queries. Enter credentials if asked, then click Run.`, !miss.length);
    }); d.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
  $('histTable').addEventListener('click', async e => {
    const open = e.target.closest('[data-open]'), del = e.target.closest('[data-del]');
    if (open) showRun(HIST.find(r => r.id === +open.dataset.open));
    if (del) {
      const r = HIST.find(x => x.id === +del.dataset.del);
      if (!confirm(`Delete "${r.title}" and its report for everyone?`)) return;
      try { await api('/api/runs/' + r.id, { method: 'DELETE' }); $('histDetail').hidden = true; loadHistory(); R.toast('toastHist', 'Deleted.', true); }
      catch (err) { R.toast('toastHist', err.message, false); }
    }
  });
  ['histKind', 'histWho'].forEach(id => $(id).addEventListener('change', loadHistory));
  $('histQ').addEventListener('input', () => { clearTimeout(qTimer); qTimer = setTimeout(loadHistory, 300); });
  $('histRefresh').addEventListener('click', loadHistory);

  /* ---------- rule presets ---------- */
  let PRESETS = [];
  const checkedNames = (boxId, list) => [...$(boxId).querySelectorAll('input:checked')].map(i => list[+i.value]?.name).filter(Boolean);
  function collect() {
    const S = R.S, cols = R.allCols(), kv = $('keySel').value;
    return {
      key: kv === '__pos' ? '__pos' : (S.pairs[+kv]?.name || '__pos'),
      ignore_case: $('optCase').checked, trim: $('optTrim').checked, numbers_by_value: $('optNum').checked,
      measures: [...$('measures').querySelectorAll('input:checked')].map(i => i.value),
      stat_columns: [...$('statCols').querySelectorAll('input:checked')].map(i => (S.statCols || S.pairs)[+i.value]?.name).filter(Boolean),
      stat_group: $('statGroup').selectedOptions[0] && $('statGroup').value !== '' ? $('statGroup').selectedOptions[0].text : '', stat_tol_abs: $('statTolAbs').value, stat_tol_pct: $('statTolPct').value,
      dq_rules: R.dqRules ? R.dqRules() : [], dq_count_same: $('dqCountSame').checked, dq_count_tol: $('dqCountTol').value, dq_min_rows: $('dqMinRows').value,
      dq_key: $('dqKeyCol').value !== '' ? $('dqKeyCol').selectedOptions[0].text : '',
      null_columns: checkedNames('dqNullCols', cols), dup_columns: checkedNames('dqDupCols', cols),
      null_text: $('dqNullText').checked, full_row_duplicates: $('dqFullRow').checked,
      code: { ignore_ws: $('cIgnWs').checked, ignore_case: $('cIgnCase').checked, ignore_blank: $('cIgnBlank').checked },
      ddl: Object.fromEntries(['ddlCase', 'ddlSchema', 'ddlSyn', 'ddlFamily', 'ddlProps', 'ddlLoc', 'ddlOrder', 'ddlCmt'].map(id => [id, $(id).checked])),
      query: window.ReconQuery ? window.ReconQuery.state() : null,
      trend: { date: $('trDate').selectedOptions[0] ? $('trDate').selectedOptions[0].text : '', cdes: [...$('trCdes').querySelectorAll('input:checked')].map(i => i.dataset.name), agg: $('trAgg').value, gran: $('trGran').value, pct: $('trPct').value, tol: $('trTol').value },
      json: { order: $('jsOrder').checked, key: $('jsKey').value, ignore: $('jsIgnore').value, ci: $('jsCase').checked, num_str: $('jsNumStr').checked }
    };
  }
  function apply(p) {
    const S = R.S, n = R.norm, cols = R.allCols(), missing = [];
    if (p.key) {
      if (p.key === '__pos') $('keySel').value = '__pos';
      else { const k = S.pairs.findIndex(x => n(x.name) === n(p.key)); if (k >= 0) $('keySel').value = String(k); else missing.push(p.key); }
    }
    $('optCase').checked = !!p.ignore_case; $('optTrim').checked = !!p.trim; $('optNum').checked = !!p.numbers_by_value;
    if (p.measures) $('measures').querySelectorAll('input').forEach(i => { i.checked = p.measures.includes(i.value); });
    const setBoxes = (boxId, list, names) => {
      if (!names) return; const want = new Set(names.map(n));
      $(boxId).querySelectorAll('input').forEach(i => { i.checked = want.has(n(list[+i.value]?.name || '')); });
      names.forEach(x => { if (!list.some(c => n(c.name) === n(x))) missing.push(x); });
    };
    setBoxes('statCols', S.statCols || S.pairs, p.stat_columns);
    if (p.stat_group != null) { const o = [...$('statGroup').options].find(x => x.text === p.stat_group); $('statGroup').value = o ? o.value : ''; }
    if (p.stat_tol_abs != null) $('statTolAbs').value = p.stat_tol_abs; if (p.stat_tol_pct != null) $('statTolPct').value = p.stat_tol_pct;
    if (p.dq_rules && R.dqRefreshRules) R.dqRefreshRules(p.dq_rules);
    if (p.dq_count_same != null) $('dqCountSame').checked = !!p.dq_count_same; if (p.dq_count_tol != null) $('dqCountTol').value = p.dq_count_tol; if (p.dq_min_rows != null) $('dqMinRows').value = p.dq_min_rows;
    if (p.dq_key != null) { const o = [...$('dqKeyCol').options].find(x => x.text === p.dq_key); $('dqKeyCol').value = o ? o.value : ''; } setBoxes('dqNullCols', cols, p.null_columns); setBoxes('dqDupCols', cols, p.dup_columns);
    $('dqNullText').checked = p.null_text !== false; $('dqFullRow').checked = !!p.full_row_duplicates;
    if (p.code) { $('cIgnWs').checked = !!p.code.ignore_ws; $('cIgnCase').checked = !!p.code.ignore_case; $('cIgnBlank').checked = !!p.code.ignore_blank; }
    if (p.ddl) Object.entries(p.ddl).forEach(([id, v]) => { if ($(id)) $(id).checked = !!v; });
    if (p.trend) {
      const t = p.trend, o = [...$('trDate').options].find(x => x.text === t.date); if (o) $('trDate').value = o.value;
      if (t.cdes) $('trCdes').querySelectorAll('input').forEach(i => { i.checked = t.cdes.includes(i.dataset.name); });
      ['agg', 'gran', 'pct', 'tol'].forEach(k => { if (t[k] != null) $('tr' + k[0].toUpperCase() + k.slice(1)).value = t[k]; });
    }
    if (p.query && window.ReconQuery && (p.query.src_sql || p.query.tgt_sql)) window.ReconQuery.load(p.query);
    if (p.json) { $('jsOrder').checked = !!p.json.order; $('jsKey').value = p.json.key || ''; $('jsIgnore').value = p.json.ignore || ''; $('jsCase').checked = !!p.json.ci; $('jsNumStr').checked = !!p.json.num_str; }
    return [...new Set(missing)];
  }
  async function loadPresets() {
    try {
      PRESETS = await api('/api/presets');
      const cur = $('presetSel').value;
      $('presetSel').innerHTML = '<option value="">Choose a saved preset…</option>' + PRESETS.map(p => `<option value="${p.id}">${esc(p.name)}</option>`).join('');
      if (PRESETS.some(p => String(p.id) === cur)) $('presetSel').value = cur;
    } catch (err) { if (!ME.must_change) R.toast('toastPreset', err.message, false); }
  }
  $('presetApply').addEventListener('click', () => {
    const p = PRESETS.find(x => String(x.id) === $('presetSel').value);
    if (!p) { R.toast('toastPreset', 'Choose a preset first.', false); return; }
    const missing = apply(p.data); $('presetName').value = p.name;
    R.toast('toastPreset', missing.length ? `Applied "${p.name}". Not in these files: ${missing.join(', ')}` : `Applied "${p.name}". Run any compare to use it.`, !missing.length);
  });
  $('presetSave').addEventListener('click', async () => {
    const name = $('presetName').value.trim();
    if (!name) { R.toast('toastPreset', 'Type a name for the preset.', false); $('presetName').focus(); return; }
    try { await api('/api/presets', { method: 'POST', json: { name, data: collect() } }); await loadPresets(); const p = PRESETS.find(x => x.name === name); if (p) $('presetSel').value = p.id; R.toast('toastPreset', `Saved "${name}".`, true); }
    catch (err) { R.toast('toastPreset', err.message, false); }
  });
  $('presetDel').addEventListener('click', async () => {
    const p = PRESETS.find(x => String(x.id) === $('presetSel').value);
    if (!p) { R.toast('toastPreset', 'Choose a preset to delete.', false); return; }
    if (!confirm(`Delete preset "${p.name}"?`)) return;
    try { await api('/api/presets/' + p.id, { method: 'DELETE' }); await loadPresets(); R.toast('toastPreset', `Deleted "${p.name}".`, true); }
    catch (err) { R.toast('toastPreset', err.message, false); }
  });

  /* ---------- admin ---------- */
  async function loadAdmin() {
    if (!ME.is_admin) return;
    try {
      const users = await api('/api/admin/users');
      $('userTable').innerHTML = '<table><tr><th>Username</th><th>Name</th><th>Role</th><th>Status</th><th>Last sign-in</th><th>Runs</th><th>Actions</th></tr>' +
        users.map(u => `<tr><td>${esc(u.username)}${u.id === ME.id ? ' <span class="note">(you)</span>' : ''}</td><td>${esc(u.full_name)}</td>` +
          `<td>${u.is_admin ? 'Admin' : 'User'}</td><td class="${u.active ? 'T' : 'F'}">${u.active ? 'Active' : 'Disabled'}${u.auth_source === 'hue' ? ' · Hue sign-in' : (u.must_change ? ' · temp password' : '')}</td>` +
          `<td>${esc(when(u.last_login))}</td><td>${u.run_count}</td><td>` +
          (u.auth_source === 'hue' ? '' : `<button class="linkbtn" type="button" data-act="reset" data-id="${u.id}" data-name="${esc(u.username)}">Reset password</button>`) +
          (u.id === ME.id ? '' : `<button class="linkbtn" type="button" data-act="${u.active ? 'disable' : 'enable'}" data-id="${u.id}">${u.active ? 'Disable' : 'Enable'}</button>` +
            `<button class="linkbtn" type="button" data-act="${u.is_admin ? 'demote' : 'promote'}" data-id="${u.id}">${u.is_admin ? 'Remove admin' : 'Make admin'}</button>`) +
          '</td></tr>').join('') + '</table>';
      const act = await api('/api/admin/activity');
      $('actTable').innerHTML = '<table><tr><th>When</th><th>User</th><th>Action</th><th>Detail</th><th>IP</th></tr>' +
        act.map(a => `<tr><td>${esc(when(a.at))}</td><td>${esc(a.username || '')}</td><td>${esc(a.action)}</td><td class="tdtext">${esc(a.detail || '')}</td><td>${esc(a.ip || '')}</td></tr>`).join('') + '</table>';
    } catch (err) { R.toast('toastAdmin', err.message, false); }
  }
  $('userTable').addEventListener('click', async e => {
    const b = e.target.closest('[data-act]'); if (!b) return;
    const id = +b.dataset.id, a = b.dataset.act;
    const body = a === 'reset' ? { reset_password: true } : a === 'disable' ? { active: false } : a === 'enable' ? { active: true } : a === 'promote' ? { is_admin: true } : { is_admin: false };
    if (a === 'reset' && !confirm(`Reset the password for ${b.dataset.name}?`)) return;
    try {
      const out = await api('/api/admin/users/' + id, { method: 'PATCH', json: body });
      if (out.temp_password) $('newUserOut').innerHTML = `Temporary password for <b>${esc(b.dataset.name)}</b>: <code class="mono">${esc(out.temp_password)}</code>. Share it privately; they must change it at sign-in.`;
      R.toast('toastAdmin', 'Updated.', true); loadAdmin();
    } catch (err) { R.toast('toastAdmin', err.message, false); }
  });
  $('newUserForm').addEventListener('submit', async e => {
    e.preventDefault();
    try {
      const out = await api('/api/admin/users', { method: 'POST', json: { username: $('nuUser').value.trim(), full_name: $('nuName').value.trim(), password: $('nuPw').value, is_admin: $('nuAdmin').checked } });
      $('newUserOut').innerHTML = `Created <b>${esc(out.username)}</b>. Temporary password: <code class="mono">${esc(out.temp_password)}</code>. Share it privately; they must change it at first sign-in.`;
      $('newUserForm').reset(); R.toast('toastAdmin', 'User created.', true); loadAdmin();
    } catch (err) { R.toast('toastAdmin', err.message, false); }
  });

  document.addEventListener('recon:tab', e => { if (e.detail === 'hist') loadHistory(); if (e.detail === 'admin') loadAdmin(); });
  if (!ME.must_change) loadPresets();
})();
