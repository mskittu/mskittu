@echo off
REM Source Target Recon - local test on a Windows laptop / VDI.
REM Double-click this file. First run creates .venv and installs packages.
cd /d "%~dp0.."
if not exist ".venv\Scripts\python.exe" (
  echo Creating Python 3.11 environment...
  py -3.11 -m venv .venv || python -m venv .venv
  ".venv\Scripts\python.exe" -m pip install --upgrade pip
  ".venv\Scripts\pip.exe" install -r requirements-vdi.txt
)
if not exist ".env" copy ".env.vdi.example" ".env" >nul
echo.
echo Open http://127.0.0.1:5000 in Chrome or Edge. Press Ctrl+C here to stop.
echo.
".venv\Scripts\python.exe" app.py
pause
