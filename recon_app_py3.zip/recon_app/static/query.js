/* Query mode: run read-only SQL on Hive / Oracle / Athena / Redshift and feed the results into Compare records. */
(function () {
  const $ = id => document.getElementById(id);
  const R = window.Recon, CSRF = window.RECON_CSRF, BASE = window.RECON_BASE || '', ME = window.RECON_ME;
  const esc = R.esc;
  const SIDES = { src: 'Source', tgt: 'Target' };
  let CONNS = [], LIMITS = {}, RUN = null, TIMER = null;

  const store = {
    get(k) { try { return JSON.parse(localStorage.getItem('recon_q_' + k)); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem('recon_q_' + k, JSON.stringify(v)); } catch (e) { /* ignore */ } }
  };
  async function api(path, opts = {}) {
    const res = await fetch(BASE + path, {
      method: opts.method || 'GET', credentials: 'same-origin', signal: opts.signal,
      headers: { 'X-CSRF-Token': CSRF, ...(opts.json !== undefined ? { 'Content-Type': 'application/json' } : {}) },
      body: opts.json !== undefined ? JSON.stringify(opts.json) : undefined
    });
    if (res.status === 401) { location.href = BASE + '/login'; throw new Error('Signed out'); }
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Request failed (' + res.status + ').');
    return data;
  }
  const conn = id => CONNS.find(c => String(c.id) === String(id));

  /* ---------- mode switch ---------- */
  function setMode(mode) {
    const decks = $('decks');
    decks.classList.toggle('querymode', mode === 'query');
    decks.classList.toggle('filemode', mode === 'file');
    document.querySelectorAll('.modebar .mode').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.mode === mode)));
    store.set('mode', mode);
    const S = R.S, example = s => ((S[s] && S[s].name) || '').endsWith('(example)');
    ['src', 'tgt'].forEach(s => {
      if (mode === 'query' && example(s)) {
        $('info-' + s).innerHTML = '<span class="note">Query results appear here after you click Run.</span>';
        $('cols-' + s).innerHTML = ''; $('peek-' + s).innerHTML = '';
      }
    });
    if (mode === 'file' && example('src') && !$('cols-src').innerHTML) { R.refresh(); R.compare(); }
  }
  document.querySelectorAll('.modebar .mode').forEach(b => b.addEventListener('click', () => setMode(b.dataset.mode)));

  /* ---------- connection pickers ---------- */
  function fillSelect(side) {
    const sel = $('qconn-' + side), prev = sel.value || store.get('conn_' + side);
    const groups = {};
    CONNS.forEach(c => { (groups[c.type_label] = groups[c.type_label] || []).push(c); });
    sel.innerHTML = CONNS.length ? Object.entries(groups).map(([g, list]) =>
      `<optgroup label="${esc(g)}">${list.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('')}</optgroup>`).join('')
      : '<option value="">No connections yet: ask your Recon admin to add one</option>';
    if (prev && conn(prev)) sel.value = prev;
    else if (CONNS.length) {
      const want = side === 'src' ? /hive|oracle|demo source/i : /athena|redshift|demo target/i;
      const pick = CONNS.find(c => want.test(c.type) || want.test(c.name)) || CONNS[side === 'src' ? 0 : Math.min(1, CONNS.length - 1)];
      sel.value = pick.id;
    }
    showConn(side);
  }
  function showConn(side) {
    const c = conn($('qconn-' + side).value);
    $('qmeta-' + side).innerHTML = c ? `<span class="tchip">${esc(c.type_label)}</span><span class="mono">${esc(c.summary)}</span>${c.description ? `<span>· ${esc(c.description)}</span>` : ''}` : '';
    const box = $('qcred-' + side), keep = {};
    box.querySelectorAll('input').forEach(i => { keep[i.dataset.key] = i.value; });
    box.innerHTML = c ? c.ask_fields.map(f => `<div class="field"><label class="label" for="qc-${side}-${f.key}">${esc(f.label)}</label>` +
      `<input type="${f.secret ? 'password' : 'text'}" id="qc-${side}-${f.key}" data-key="${f.key}" autocomplete="${f.secret ? 'new-password' : 'off'}" spellcheck="false"></div>`).join('') : '';
    box.querySelectorAll('input').forEach(i => { if (keep[i.dataset.key] && i.type !== 'password') i.value = keep[i.dataset.key]; });
    const ta = $('qsql-' + side);
    ta.placeholder = c ? c.sql_hint : '';
    if (c && c.type === 'sqlite' && !ta.value.trim()) ta.value = 'SELECT account_id, customer_name, ifrs9_stage, ead, ecl, region, as_of_date\nFROM loan_impairments\nORDER BY account_id';
  }
  ['src', 'tgt'].forEach(side => {
    $('qconn-' + side).addEventListener('change', () => { store.set('conn_' + side, $('qconn-' + side).value); showConn(side); status(side, '', ''); });
    $('qsql-' + side).addEventListener('change', () => store.set('sql_' + side, $('qsql-' + side).value));
    const saved = store.get('sql_' + side); if (saved) $('qsql-' + side).value = saved;
    $('qtest-' + side).addEventListener('click', () => testConn(side));
  });
  const creds = side => { const o = {}; $('qcred-' + side).querySelectorAll('input').forEach(i => { o[i.dataset.key] = i.value; }); return o; };
  function status(side, cls, html) { const el = $('qstat-' + side); el.className = 'qstatus ' + cls; el.innerHTML = html; }

  async function testConn(side) {
    const c = conn($('qconn-' + side).value); if (!c) return;
    status(side, 'run', '<span class="spin"></span>Testing ' + esc(c.name) + '…');
    try {
      const out = await api(`/api/connections/${c.id}/test`, { method: 'POST', json: { credentials: creds(side) } });
      out.ok ? status(side, 'ok', `Connected to ${esc(c.name)} in ${out.seconds} s.`) : status(side, 'bad', esc(out.error));
    } catch (err) { status(side, 'bad', esc(err.message)); }
  }

  async function loadConnections() {
    try {
      const out = await api('/api/connections');
      CONNS = out.connections; LIMITS = out;
      $('qLimits').textContent = `Up to ${out.max_rows.toLocaleString()} rows per side · ${out.timeout} s time limit`;
      fillSelect('src'); fillSelect('tgt'); fillDdlSide('src'); fillDdlSide('tgt');
    } catch (err) { R.toast('toastQ', err.message, false); }
  }

  /* ---------- run ---------- */
  function busy(on) {
    $('qRun').disabled = on; $('qCancel').hidden = !on;
    ['src', 'tgt'].forEach(s => { $('qconn-' + s).disabled = on; $('qtest-' + s).disabled = on; });
  }
  const ACTIONS = { cmp: () => R.compare(), stat: () => R.calcStats(), dq: () => R.runDQ(), trend: () => R.calcTrends() };
  const TAB_LABEL = { cmp: 'Compare records', stat: 'Statistics', dq: 'Data quality', trend: 'Trends' };
  function currentTab() {
    const t = document.querySelector('.hero .tab[aria-selected=true]');
    const id = t ? t.id.replace('tab-', '') : 'cmp';
    return ACTIONS[id] ? id : 'cmp';
  }
  function showNext(cur) {
    const both = !!(R.S.src && R.S.tgt), bar = $('qNext');
    bar.hidden = !(R.S.src || R.S.tgt);
    bar.querySelectorAll('[data-next]').forEach(b => {
      b.setAttribute('aria-current', String(b.dataset.next === cur));
      b.disabled = b.dataset.next === 'cmp' && !both;
      b.title = b.disabled ? 'Run both queries to compare records' : '';
    });
  }
  function goTo(t) {
    R.tab(t);
    if (t === 'cmp' && !(R.S.src && R.S.tgt)) return;
    ACTIONS[t](); showNext(t);
    $('pane-' + t).scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  $('qNext').addEventListener('click', e => { const b = e.target.closest('[data-next]'); if (b && !b.disabled) goTo(b.dataset.next); });
  document.addEventListener('recon:tab', e => { if (ACTIONS[e.detail]) showNext(e.detail); });

  async function runBoth() {
    const cur = currentTab(), spec = {}, problems = [];
    for (const side of ['src', 'tgt']) {
      const c = conn($('qconn-' + side).value), sql = $('qsql-' + side).value.trim();
      store.set('sql_' + side, sql);
      if (!sql && cur !== 'cmp') continue;              // Statistics / Data quality can run on one side
      if (!c) problems.push(`Pick a ${SIDES[side].toLowerCase()} connection.`);
      if (!sql) problems.push(`Enter the ${SIDES[side].toLowerCase()} query.`);
      spec[side] = { connection_id: c && c.id, sql, credentials: creds(side) };
    }
    if (!spec.src && !spec.tgt) problems.push('Enter at least one query.');
    if (problems.length) { R.toast('toastQ', problems.join(' '), false); return; }
    const runId = Math.random().toString(36).slice(2) + Date.now().toString(36);
    const abort = new AbortController();
    RUN = { runId, abort };
    busy(true); R.toast('toastQ', '', true); $('qNext').hidden = true;
    const t0 = Date.now();
    const tick = () => { const sec = Math.round((Date.now() - t0) / 1000); ['src', 'tgt'].forEach(s => spec[s] ? status(s, 'run', `<span class="spin"></span>Running on ${esc(conn(spec[s].connection_id).name)} · ${sec} s`) : status(s, '', 'Not run (no query on this side).')); };
    tick(); TIMER = setInterval(tick, 1000);
    let out;
    try {
      out = await api('/api/query/run', { method: 'POST', signal: abort.signal, json: {
        run_id: runId, options: { normalize_dates: $('qDates').checked },
        source: spec.src || {}, target: spec.tgt || {} } });
    } catch (err) {
      clearInterval(TIMER); busy(false); RUN = null;
      const msg = err.name === 'AbortError' ? 'Cancelled.' : err.message;
      ['src', 'tgt'].forEach(s => spec[s] && status(s, 'bad', esc(msg))); return;
    }
    clearInterval(TIMER); busy(false); RUN = null;
    const res = { src: spec.src ? (out.source || { error: 'No result.' }) : null, tgt: spec.tgt ? (out.target || { error: 'No result.' }) : null };
    let ok = true;
    for (const side of ['src', 'tgt']) {
      const r = res[side]; if (!r) continue;
      if (r.error) { ok = false; status(side, 'bad', esc(r.error)); continue; }
      status(side, 'ok', `${r.row_count.toLocaleString()} rows · ${r.columns.length} columns · ${r.seconds} s` +
        (r.truncated ? `<span class="warnline">Stopped at ${r.max_rows.toLocaleString()} rows. Add a WHERE filter or aggregate so the full set is checked.</span>` : ''));
    }
    if (!ok) { R.toast('toastQ', 'Fix the error above and run again.', false); return; }
    const S = R.S;
    const mk = r => r ? { name: `${r.connection.name} (${r.connection.type_label})`, headers: r.columns, rows: r.rows } : null;
    const meta = (r, sp) => r ? { connection_id: r.connection.id, connection: r.connection.name, type: r.connection.type, sql: sp.sql, rows: r.row_count, truncated: r.truncated, seconds: r.seconds } : null;
    S.src = mk(res.src); S.tgt = mk(res.tgt);
    ['src', 'tgt'].forEach(side => { if (!S[side]) { $('info-' + side).innerHTML = '<span class="note">No query run on this side.</span>'; $('cols-' + side).innerHTML = ''; $('peek-' + side).innerHTML = ''; } });
    S.query = { srcName: S.src ? S.src.name : null, tgtName: S.tgt ? S.tgt.name : null, ran_at: new Date().toISOString(),
      source: meta(res.src, spec.src), target: meta(res.tgt, spec.tgt) };
    R.refresh();
    ACTIONS[cur]();
    showNext(cur);
    const counts = [res.src && `${res.src.row_count.toLocaleString()} source rows`, res.tgt && `${res.tgt.row_count.toLocaleString()} target rows`].filter(Boolean).join(' and ');
    const trunc = (res.src && res.src.truncated) || (res.tgt && res.tgt.truncated);
    R.toast('toastQ', `Fetched ${counts} and ran ${TAB_LABEL[cur]}. Use the buttons below for the other checks.` + (trunc ? ' One side hit the row limit, so not every row was checked.' : ''), !trunc);
    $('pane-' + cur).scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  $('qRun').addEventListener('click', runBoth);
  $('qCancel').addEventListener('click', async () => {
    if (!RUN) return;
    const { runId, abort } = RUN;
    try { await api('/api/query/cancel', { method: 'POST', json: { run_id: runId } }); } catch (e) { /* ignore */ }
    abort.abort();
  });
  ['qsql-src', 'qsql-tgt'].forEach(id => $(id).addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); runBoth(); } }));

  /* ---------- Trends: build monthly SUM queries per dialect ---------- */
  const IDENT = /^[A-Za-z_][A-Za-z0-9_$#]*(\.[A-Za-z_][A-Za-z0-9_$#]*){0,2}$/;
  function monthExpr(type, col) {
    if (type === 'oracle' || type === 'redshift') return `TO_CHAR(${col}, 'YYYY-MM')`;
    if (type === 'hive') return `date_format(${col}, 'yyyy-MM')`;
    if (type === 'athena') return `date_format(CAST(${col} AS timestamp), '%Y-%m')`;
    return `substr(${col}, 1, 7)`;  // SQLite demo / text dates
  }
  function fromExpr(type, col, ym) {
    if (!ym) return '';
    if (type === 'oracle') return `\nWHERE ${col} >= TO_DATE('${ym}-01', 'YYYY-MM-DD')`;
    if (type === 'athena') return `\nWHERE CAST(${col} AS date) >= DATE '${ym}-01'`;
    return `\nWHERE ${col} >= '${ym}-01'`;
  }
  $('trBuild').addEventListener('click', () => {
    const date = $('trbDate').value.trim(), cdes = $('trbCdes').value.split(',').map(x => x.trim()).filter(Boolean), ym = $('trbFrom').value.trim();
    const tables = { src: $('trbSrcTable').value.trim(), tgt: $('trbTgtTable').value.trim() };
    const bad = [date, ...cdes, ...Object.values(tables).filter(Boolean)].find(x => !IDENT.test(x));
    if (!date || !cdes.length || !(tables.src || tables.tgt)) { R.toast('toastTrBuild', 'Enter a table, the date column and at least one CDE column.', false); return; }
    if (bad) { R.toast('toastTrBuild', `"${bad}" is not a valid column or table name.`, false); return; }
    if (ym && !/^\d{4}-\d{2}$/.test(ym)) { R.toast('toastTrBuild', 'From month looks like 2025-10.', false); return; }
    ['src', 'tgt'].forEach(side => {
      if (!tables[side]) return;
      const c = conn($('qconn-' + side).value), type = c ? c.type : 'sqlite', m = monthExpr(type, date);
      $('qsql-' + side).value = `SELECT ${m} AS month,\n       ${cdes.map(x => `SUM(${x}) AS ${x}`).join(',\n       ')}\nFROM ${tables[side]}${fromExpr(type, date, ym)}\nGROUP BY ${m}\nORDER BY 1`;
      store.set('sql_' + side, $('qsql-' + side).value);
    });
    setMode('query');
    R.toast('toastTrBuild', 'Queries are in the Source and Target boxes above. Click "Run both queries & compare".', true);
    $('decks').scrollIntoView({ behavior: 'smooth', block: 'start' });
  });

  /* ---------- DDL compare: fetch definitions from connections ---------- */
  function fillDdlSide(side) {
    const sel = $('dconn-' + side), prev = sel.value || store.get('dconn_' + side) || $('qconn-' + side).value;
    sel.innerHTML = '<option value="">Paste DDL instead</option>' + $('qconn-' + side).innerHTML.replace(/<option value="">[^<]*<\/option>/, '');
    if (prev && conn(prev)) sel.value = prev;
    ddlCreds(side);
    const t = store.get('dtab_' + side); if (t) $('dtab-' + side).value = t;
  }
  function ddlCreds(side) {
    const c = conn($('dconn-' + side).value), box = $('dcred-' + side);
    box.innerHTML = c ? c.ask_fields.map(f => `<div class="field"><label class="label" for="dc-${side}-${f.key}">${esc(f.label)}</label>` +
      `<input type="${f.secret ? 'password' : 'text'}" id="dc-${side}-${f.key}" data-key="${f.key}" autocomplete="${f.secret ? 'new-password' : 'off'}" spellcheck="false"></div>`).join('') : '';
    $('dtab-' + side).disabled = !c;
    if (c && c.type === 'sqlite' && !$('dtab-' + side).value) $('dtab-' + side).value = 'loan_impairments';
  }
  ['src', 'tgt'].forEach(side => $('dconn-' + side).addEventListener('change', () => { store.set('dconn_' + side, $('dconn-' + side).value); ddlCreds(side); }));
  $('dFetch').addEventListener('click', async () => {
    const body = {}, use = [];
    ['src', 'tgt'].forEach(side => {
      const c = conn($('dconn-' + side).value), t = $('dtab-' + side).value.trim();
      $('dstat-' + side).className = 'qstatus'; $('dstat-' + side).textContent = '';
      if (!c) return;
      if (!t) { $('dstat-' + side).className = 'qstatus bad'; $('dstat-' + side).textContent = 'Enter the table names.'; return; }
      const o = {}; $('dcred-' + side).querySelectorAll('input').forEach(i => { o[i.dataset.key] = i.value; });
      body[side === 'src' ? 'source' : 'target'] = { connection_id: c.id, tables: t, credentials: o }; use.push(side);
      store.set('dtab_' + side, t);
      $('dstat-' + side).className = 'qstatus run'; $('dstat-' + side).innerHTML = '<span class="spin"></span>Reading table definitions…';
    });
    if (!use.length) { R.toast('toastDFetch', 'Pick a connection and tables on at least one side, or paste DDL below.', false); return; }
    $('dFetch').disabled = true;
    try {
      const out = await api('/api/ddl/fetch', { method: 'POST', json: body });
      let ok = true;
      use.forEach(side => {
        const r = out[side === 'src' ? 'source' : 'target'] || { error: 'No result.' }, st = $('dstat-' + side);
        if (r.error) { ok = false; st.className = 'qstatus bad'; st.textContent = r.error; return; }
        $(side === 'src' ? 'ddlSrc' : 'ddlTgt').value = r.ddl;
        st.className = 'qstatus ok'; st.innerHTML = `Fetched ${r.tables} table${r.tables > 1 ? 's' : ''} from ${esc(r.connection.name)}.` + (r.missing.length ? `<span class="warnline">Not found or no access: ${esc(r.missing.join(', '))}</span>` : '');
      });
      if (ok && $('ddlSrc').value.trim() && $('ddlTgt').value.trim()) { $('btnDDL').click(); R.toast('toastDFetch', 'Fetched and compared.', true); }
      else if (ok) R.toast('toastDFetch', 'Fetched. Fetch or paste the other side, then click Compare DDL.', true);
    } catch (err) { R.toast('toastDFetch', err.message, false); }
    $('dFetch').disabled = false;
  });

  /* ---------- hooks used by history and presets ---------- */
  window.ReconQuery = {
    current() {
      const S = R.S;
      const nm = x => x ? x.name : null;
      return S.query && nm(S.src) === S.query.srcName && nm(S.tgt) === S.query.tgtName ? S.query : null;
    },
    state() { return { src_conn: $('qconn-src').value, tgt_conn: $('qconn-tgt').value, src_sql: $('qsql-src').value, tgt_sql: $('qsql-tgt').value, dates: $('qDates').checked }; },
    load(q) {
      setMode('query'); R.tab(q.tab || 'cmp');
      const missing = [];
      [['src', q.src_conn, q.src_sql, q.src_name], ['tgt', q.tgt_conn, q.tgt_sql, q.tgt_name]].forEach(([side, id, sql, name]) => {
        if (id && conn(id)) { $('qconn-' + side).value = id; showConn(side); } else if (id) missing.push(name || ('connection ' + id));
        if (sql != null) $('qsql-' + side).value = sql;
        status(side, '', '');
      });
      if (q.dates != null) $('qDates').checked = !!q.dates;
      $('decks').scrollIntoView({ behavior: 'smooth', block: 'start' });
      return missing;
    },
    reload: loadConnections
  };

  /* ---------- admin: connections ---------- */
  let ADMIN = null, EDIT = null;
  async function loadAdminConns() {
    if (!ME.is_admin) return;
    try {
      ADMIN = await api('/api/admin/connections');
      const T = ADMIN.types;
      $('cfType').innerHTML = Object.entries(T).map(([k, t]) => `<option value="${k}">${esc(t.label)}</option>`).join('');
      $('connTable').innerHTML = ADMIN.connections.length ? '<table><tr><th>Name</th><th>Type</th><th>Where</th><th>Credentials</th><th>Status</th><th></th></tr>' +
        ADMIN.connections.map(c => `<tr><td><b>${esc(c.name)}</b>${c.description ? `<br><span class="note">${esc(c.description)}</span>` : ''}</td>` +
          `<td><span class="tpill ${c.type}">${esc(c.type_label)}</span></td><td class="mono">${esc(c.summary)}</td>` +
          `<td>${esc(({ none: 'Kerberos / IAM role', ask: 'Each user', env: 'Server env variable', aws_secret: 'AWS Secrets Manager' })[c.secret_mode] || c.secret_mode)}${c.secret_ref ? `<br><span class="mono">${esc(c.secret_ref)}</span>` : ''}</td>` +
          `<td class="${c.active ? 'T' : 'F'}">${c.active ? 'Active' : 'Disabled'}</td>` +
          `<td style="white-space:nowrap"><button class="linkbtn" type="button" data-cedit="${c.id}">Edit</button>` +
          `<button class="linkbtn" type="button" data-ctoggle="${c.id}">${c.active ? 'Disable' : 'Enable'}</button>` +
          `<button class="linkbtn" type="button" data-cdel="${c.id}">Delete</button></td></tr>`).join('') + '</table>'
        : '<p class="note" style="padding:12px;margin:0">No connections yet. Add your Hive, Oracle, Athena or Redshift systems.</p>';
    } catch (err) { R.toast('toastConn', err.message, false); }
  }
  function renderForm(c) {
    const T = ADMIN.types, type = $('cfType').value, t = T[type], cfg = (c && c.type === type && c.config) || {};
    $('cfFields').innerHTML = t.fields.map(f => {
      const v = cfg[f.key] != null ? cfg[f.key] : (f.default || '');
      const input = f.choices ? `<select id="cff-${f.key}" data-key="${f.key}">${f.choices.map(o => `<option${o === v ? ' selected' : ''}>${esc(o)}</option>`).join('')}</select>`
        : `<input type="text" id="cff-${f.key}" data-key="${f.key}" value="${esc(v)}" autocomplete="off" spellcheck="false">`;
      return `<div class="field"><label class="label" for="cff-${f.key}">${esc(f.label)}${f.required ? ' *' : ''}</label>${input}</div>`;
    }).join('');
    const cur = c && c.type === type ? c.secret_mode : t.secret_modes[0];
    $('cfMode').innerHTML = t.secret_modes.map(m => `<option value="${m}"${m === cur ? ' selected' : ''}>${esc(ADMIN.secret_modes[m])}</option>`).join('');
    $('cfRef').value = c && c.type === type ? (c.secret_ref || '') : '';
    syncRef();
  }
  function syncRef() {
    const m = $('cfMode').value;
    $('cfRefWrap').hidden = !(m === 'env' || m === 'aws_secret');
    $('cfRefLabel').textContent = m === 'env' ? 'Environment variable holding the password' : 'AWS Secrets Manager secret ID or ARN';
    $('cfRef').placeholder = m === 'env' ? 'e.g. RECON_ORACLE_IMP_PASSWORD' : 'e.g. recon/oracle-imp-prod';
  }
  function openForm(c) {
    EDIT = c || null;
    $('connFormTitle').textContent = c ? 'Edit ' + c.name : 'Add connection';
    $('cfName').value = c ? c.name : ''; $('cfDesc').value = c ? c.description : '';
    if (c) $('cfType').value = c.type;
    renderForm(c); $('connForm').hidden = false; $('cfName').focus();
  }
  if ($('connNew')) {
    $('connNew').addEventListener('click', () => openForm(null));
    $('connCancel').addEventListener('click', () => { $('connForm').hidden = true; });
    $('cfType').addEventListener('change', () => renderForm(EDIT));
    $('cfMode').addEventListener('change', syncRef);
    $('connForm').addEventListener('submit', async e => {
      e.preventDefault();
      const config = {}; $('cfFields').querySelectorAll('[data-key]').forEach(i => { config[i.dataset.key] = i.value; });
      const body = { name: $('cfName').value, type: $('cfType').value, description: $('cfDesc').value, config, secret_mode: $('cfMode').value, secret_ref: $('cfRef').value };
      try {
        await api(EDIT ? '/api/admin/connections/' + EDIT.id : '/api/admin/connections', { method: EDIT ? 'PATCH' : 'POST', json: body });
        $('connForm').hidden = true; R.toast('toastConn', 'Saved.', true); await loadAdminConns(); loadConnections();
      } catch (err) { R.toast('toastConn', err.message, false); }
    });
    $('connTable').addEventListener('click', async e => {
      const b = e.target.closest('button'); if (!b) return;
      const id = b.dataset.cedit || b.dataset.ctoggle || b.dataset.cdel, c = ADMIN.connections.find(x => String(x.id) === id);
      if (b.dataset.cedit) return openForm(c);
      try {
        if (b.dataset.ctoggle) await api('/api/admin/connections/' + id, { method: 'PATCH', json: { active: !c.active } });
        if (b.dataset.cdel) { if (!confirm(`Delete connection "${c.name}"?`)) return; await api('/api/admin/connections/' + id, { method: 'DELETE' }); }
        await loadAdminConns(); loadConnections();
      } catch (err) { R.toast('toastConn', err.message, false); }
    });
  }
  document.addEventListener('recon:tab', e => { if (e.detail === 'admin') loadAdminConns(); });

  /* ---------- start ---------- */
  setMode(store.get('mode') || 'query');
  if (!ME.must_change) loadConnections();
  window.ReconQuery.afterPassword = loadConnections;
})();
