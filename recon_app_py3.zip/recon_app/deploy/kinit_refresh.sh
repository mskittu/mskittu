#!/usr/bin/env bash
# Keep a Kerberos ticket for the Recon service account so Hive connections set to
# "No password (Kerberos ticket)" work. Run every 8 hours from cron as the recon user:
#   0 */8 * * * /opt/recon/app/deploy/kinit_refresh.sh >> /opt/recon/backups/kinit.log 2>&1
set -euo pipefail
KEYTAB="${RECON_KEYTAB:-/opt/recon/recon.keytab}"            # from your Hadoop / AD team, chmod 400
PRINCIPAL="${RECON_PRINCIPAL:-svc_recon@YOUR.REALM.COM}"
export KRB5CCNAME="${KRB5CCNAME:-FILE:/opt/recon/krb5cc_recon}"
kinit -kt "$KEYTAB" "$PRINCIPAL"
klist | head -5
