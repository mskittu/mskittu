#!/usr/bin/env bash
# Nightly backup of the Recon database and saved reports.
# Cron example (02:30 every night):
#   30 2 * * * /opt/recon/app/deploy/backup.sh >> /var/log/recon-backup.log 2>&1
set -euo pipefail
DATA_DIR="${RECON_DATA_DIR:-/opt/recon/data}"
BACKUP_DIR="${RECON_BACKUP_DIR:-/opt/recon/backups}"
# keep backups no longer than the app keeps runs, so deleted reports really disappear
KEEP_DAYS="${RECON_BACKUP_KEEP_DAYS:-${RECON_RETENTION_DAYS:-7}}"
STAMP="$(date +%Y-%m-%d_%H%M)"
mkdir -p "$BACKUP_DIR"
# consistent copy of SQLite even while the app is running
sqlite3 "$DATA_DIR/recon.db" ".backup '$BACKUP_DIR/recon_$STAMP.db'"
tar -czf "$BACKUP_DIR/reports_$STAMP.tar.gz" -C "$DATA_DIR" reports
find "$BACKUP_DIR" -type f -mtime +"$KEEP_DAYS" -delete
echo "$(date -Is) backup ok: $BACKUP_DIR/recon_$STAMP.db"
