"""
Read-only query connectors for Source Target Recon.

Supported: Hive (PyHive / impyla), Oracle (python-oracledb), AWS Athena (boto3),
AWS Redshift (redshift_connector), plus a local SQLite demo.

Every connector:
  * runs ONE read-only statement (SELECT / WITH), checked before it is sent
  * stops after `max_rows` rows and reports truncation
  * honours a timeout and can be cancelled from another thread
  * returns every value as a string so source and target compare like-for-like

Drivers are imported lazily; a missing driver produces a clear message instead of a crash.
"""
import datetime as dt
import json
import os
import re
import sqlite3
import threading
import time
from decimal import Decimal


class QueryError(Exception):
    """An error that is safe to show to the user."""


# ---------------------------------------------------------------- connection types (drives the admin form)
F = lambda key, label, **kw: dict(key=key, label=label, **kw)  # noqa: E731

TYPES = {
    "hive": dict(
        label="Hive", icon="db", test_sql="SELECT 1",
        sql_hint="SELECT id, name, village FROM db.customers WHERE load_date = '2026-10-19'",
        fields=[F("host", "HiveServer2 host", required=True), F("port", "Port", default="10000"),
                F("database", "Database", default="default"),
                F("auth", "Authentication", choices=["KERBEROS", "LDAP", "NONE", "NOSASL", "CUSTOM"], default="KERBEROS"),
                F("kerberos_service_name", "Kerberos service name", default="hive"),
                F("transport", "Transport", choices=["binary", "http"], default="binary"),
                F("http_path", "HTTP path (http transport)", default="cliservice"),
                F("use_ssl", "Use SSL (http transport)", choices=["no", "yes"], default="no"),
                F("username", "Username (if fixed)")],
        secret_modes=["none", "ask", "env", "aws_secret"],
        ask_fields=[F("username", "Username"), F("password", "Password", secret=True)]),
    "oracle": dict(
        label="Oracle", icon="db", test_sql="SELECT 1 FROM dual",
        sql_hint="SELECT id, name, village FROM imp.customers WHERE load_date = DATE '2026-10-19'",
        fields=[F("host", "Host"), F("port", "Port", default="1521"), F("service_name", "Service name"),
                F("dsn", "Full DSN / TNS descriptor (optional, overrides host/port/service)"),
                F("username", "Username (if fixed)")],
        secret_modes=["ask", "env", "aws_secret"],
        ask_fields=[F("username", "Username"), F("password", "Password", secret=True)]),
    "athena": dict(
        label="AWS Athena", icon="cloud", test_sql="SELECT 1",
        sql_hint="SELECT id, name, village FROM customers WHERE load_date = DATE '2026-10-19'",
        fields=[F("region", "AWS region", required=True, default="eu-west-1"),
                F("database", "Glue database", required=True), F("catalog", "Data catalog", default="AwsDataCatalog"),
                F("workgroup", "Workgroup", default="primary"),
                F("output_location", "Query results S3 path (if the workgroup has none)"),
                F("aws_profile", "AWS profile on the server (optional)"),
                F("role_arn", "IAM role to assume (optional)")],
        secret_modes=["none", "ask", "aws_secret"],
        ask_fields=[F("aws_access_key_id", "Access key ID"), F("aws_secret_access_key", "Secret access key", secret=True),
                    F("aws_session_token", "Session token (optional)", secret=True, optional=True)]),
    "redshift": dict(
        label="AWS Redshift", icon="cloud", test_sql="SELECT 1",
        sql_hint="SELECT id, name, village FROM imp.customers WHERE load_date = '2026-10-19'",
        fields=[F("auth_mode", "Sign-in", choices=["password", "iam"], default="password"),
                F("host", "Endpoint host"), F("port", "Port", default="5439"), F("database", "Database", required=True),
                F("region", "AWS region (IAM)", default="eu-west-1"),
                F("cluster_identifier", "Cluster identifier (IAM, provisioned)"),
                F("serverless_workgroup", "Serverless workgroup (IAM, serverless)"),
                F("aws_profile", "AWS profile on the server (IAM, optional)"),
                F("username", "Database user (if fixed)")],
        secret_modes=["ask", "env", "aws_secret", "none"],
        ask_fields=[F("username", "Username"), F("password", "Password", secret=True)]),
    "sqlite": dict(
        label="SQLite (demo)", icon="db", test_sql="SELECT 1",
        sql_hint="SELECT * FROM customers",
        fields=[F("path", "Database file inside the data folder", required=True)],
        secret_modes=["none"], ask_fields=[]),
}
SECRET_MODE_LABEL = {
    "none": "No password (Kerberos ticket / IAM role on the server)",
    "ask": "Each user enters their own credentials",
    "env": "Server environment variable",
    "aws_secret": "AWS Secrets Manager",
}


def public_type_info():
    return {k: dict(label=v["label"], icon=v["icon"], fields=v["fields"], secret_modes=v["secret_modes"],
                    ask_fields=v["ask_fields"], sql_hint=v["sql_hint"]) for k, v in TYPES.items()}


# ---------------------------------------------------------------- read-only guard
_FORBIDDEN = re.compile(
    r"\b(INSERT|UPDATE|DELETE|MERGE|UPSERT|DROP|CREATE|ALTER|TRUNCATE|RENAME|GRANT|REVOKE|"
    r"CALL|EXEC|EXECUTE|BEGIN|COMMIT|ROLLBACK|LOCK|UNLOAD|COPY|VACUUM|ANALYZE|MSCK|LOAD|EXPORT|IMPORT|"
    r"SET|USE|DECLARE|DO|INTO)\b", re.I)


def _strip_sql(sql):
    """Remove comments and string/identifier literals so keyword checks only see real SQL."""
    out, i, n = [], 0, len(sql)
    while i < n:
        c = sql[i]
        if c == "-" and sql[i:i + 2] == "--":
            j = sql.find("\n", i)
            i = n if j < 0 else j
            continue
        if c == "/" and sql[i:i + 2] == "/*":
            j = sql.find("*/", i + 2)
            i = n if j < 0 else j + 2
            out.append(" ")
            continue
        if c in "'\"`":
            j = i + 1
            while j < n:
                if sql[j] == "\\" and c != "`":
                    j += 2
                    continue
                if sql[j] == c:
                    if j + 1 < n and sql[j + 1] == c:
                        j += 2
                        continue
                    break
                j += 1
            out.append(" '' ")
            i = j + 1
            continue
        out.append(c)
        i += 1
    return "".join(out)


def check_read_only(sql):
    """Return the statement without a trailing ';' or raise QueryError."""
    if not sql or not sql.strip():
        raise QueryError("Enter a query.")
    if len(sql) > 200_000:
        raise QueryError("The query is too long.")
    bare = _strip_sql(sql).strip()
    while bare.endswith(";"):
        bare = bare[:-1].rstrip()
    if ";" in bare:
        raise QueryError("Run one statement at a time (remove the extra ';').")
    first = re.match(r"\(*\s*(\w+)", bare)
    if not first or first.group(1).upper() not in ("SELECT", "WITH"):
        raise QueryError("Only SELECT queries (or WITH ... SELECT) can be run. This is a read-only validation tool.")
    bad = _FORBIDDEN.search(bare)
    if bad:
        raise QueryError(f"'{bad.group(1).upper()}' is not allowed. Only read-only SELECT queries can be run.")
    clean = sql.strip()
    while clean.endswith(";"):
        clean = clean[:-1].rstrip()
    return clean


# ---------------------------------------------------------------- value normalisation
_TS_MIDNIGHT = re.compile(r"^(\d{4}-\d{2}-\d{2})[ T]00:00:00(\.0+)?$")
_TS_ZERO_FRAC = re.compile(r"^(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2})\.0+$")


def normalize_value(v, dates=True):
    if v is None:
        return ""
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, Decimal):
        s = format(v, "f")
        return s.rstrip("0").rstrip(".") if "." in s else s
    if isinstance(v, float):
        if v != v:
            return "NaN"
        return str(int(v)) if v.is_integer() and abs(v) < 1e15 else repr(v)
    if isinstance(v, dt.datetime):
        if dates and v.hour == v.minute == v.second == v.microsecond == 0 and v.tzinfo is None:
            return v.strftime("%Y-%m-%d")
        return v.isoformat(sep=" ", timespec="seconds" if not v.microsecond else "microseconds")
    if isinstance(v, dt.date):
        return v.isoformat()
    if isinstance(v, (bytes, bytearray, memoryview)):
        return bytes(v).hex()
    if isinstance(v, (list, tuple, dict)):
        return json.dumps(v, default=str)
    s = str(v)
    if dates and len(s) <= 30:
        m = _TS_MIDNIGHT.match(s)
        if m:
            return m.group(1)
        m = _TS_ZERO_FRAC.match(s)
        if m:
            return m.group(1).replace("T", " ")
    return s


def _fetch(cur, max_rows, dates, strip_prefix=False):
    if not cur.description:
        raise QueryError("The query returned no result set.")
    cols = [str(d[0]) for d in cur.description]
    if strip_prefix:  # Hive returns "table.column" when hive.resultset.use.unique.column.names=true
        cols = [c.split(".", 1)[1] if "." in c else c for c in cols]
    rows, truncated = [], False
    while True:
        batch = cur.fetchmany(5000)
        if not batch:
            break
        for r in batch:
            if len(rows) >= max_rows:
                truncated = True
                break
            rows.append([normalize_value(v, dates) for v in r])
        if truncated:
            break
    return cols, rows, truncated


# ---------------------------------------------------------------- run context (timeout + cancel)
class RunContext:
    def __init__(self, timeout):
        self.timeout = timeout
        self.deadline = time.time() + timeout
        self.cancelled = threading.Event()
        self._hooks = []
        self._lock = threading.Lock()

    def on_cancel(self, fn):
        with self._lock:
            self._hooks.append(fn)

    def cancel(self):
        self.cancelled.set()
        with self._lock:
            hooks = list(self._hooks)
        for fn in hooks:
            try:
                fn()
            except Exception:
                pass

    def check(self):
        if self.cancelled.is_set():
            raise QueryError("Cancelled.")
        if time.time() > self.deadline:
            raise QueryError(f"Timed out after {self.timeout} seconds.")


def _need(module, pip_name):
    try:
        return __import__(module, fromlist=["_"])
    except ImportError:
        raise QueryError(f"The {pip_name} driver is not installed on the server. "
                         f"Ask your Recon admin to run: pip install {pip_name}")


def _aws_session(cfg, cred, region):
    boto3 = _need("boto3", "boto3")
    kw = {"region_name": region}
    if cfg.get("aws_profile"):
        kw["profile_name"] = cfg["aws_profile"]
    if cred.get("aws_access_key_id"):
        kw.update(aws_access_key_id=cred["aws_access_key_id"], aws_secret_access_key=cred.get("aws_secret_access_key"),
                  aws_session_token=cred.get("aws_session_token") or None)
    session = boto3.Session(**kw)
    if cfg.get("role_arn"):
        c = session.client("sts").assume_role(RoleArn=cfg["role_arn"], RoleSessionName="source-target-recon",
                                              DurationSeconds=3600)["Credentials"]
        session = boto3.Session(aws_access_key_id=c["AccessKeyId"], aws_secret_access_key=c["SecretAccessKey"],
                                aws_session_token=c["SessionToken"], region_name=region)
    return session


# ---------------------------------------------------------------- drivers
def _run_hive(cfg, cred, sql, max_rows, ctx, dates):
    auth = (cfg.get("auth") or "KERBEROS").upper()
    host, port = cfg["host"], int(cfg.get("port") or 10000)
    database = cfg.get("database") or "default"
    user = cred.get("username") or cfg.get("username") or None
    if cfg.get("transport") == "http" or cfg.get("use_ssl") == "yes":
        dbapi = _need("impala.dbapi", "impyla")
        mech = {"NONE": "NOSASL", "NOSASL": "NOSASL", "LDAP": "LDAP", "KERBEROS": "GSSAPI", "CUSTOM": "PLAIN"}.get(auth, "PLAIN")
        conn = dbapi.connect(host=host, port=port, database=database, auth_mechanism=mech,
                             user=user, password=cred.get("password"),
                             use_ssl=cfg.get("use_ssl") == "yes", use_http_transport=cfg.get("transport") == "http",
                             http_path=cfg.get("http_path") or "cliservice",
                             kerberos_service_name=cfg.get("kerberos_service_name") or "hive", timeout=ctx.timeout)
    else:
        hive = _need("pyhive.hive", "pyhive[hive]")
        kw = dict(host=host, port=port, database=database, auth=auth)
        if auth in ("LDAP", "CUSTOM"):
            if not (user and cred.get("password")):
                raise QueryError("This Hive connection needs a username and password.")
            kw.update(username=user, password=cred["password"])
        elif auth == "KERBEROS":
            kw["kerberos_service_name"] = cfg.get("kerberos_service_name") or "hive"
        elif user:
            kw["username"] = user
        conn = hive.Connection(**kw)
    try:
        cur = conn.cursor()
        ctx.on_cancel(lambda: (getattr(cur, "cancel", None) or getattr(cur, "cancel_operation"))())
        ctx.check()
        cur.execute(sql)
        ctx.check()
        return _fetch(cur, max_rows, dates, strip_prefix=True)
    finally:
        try:
            conn.close()
        except Exception:
            pass


def _run_oracle(cfg, cred, sql, max_rows, ctx, dates):
    oracledb = _need("oracledb", "oracledb")
    oracledb.defaults.fetch_lobs = False      # CLOB -> str
    oracledb.defaults.fetch_decimals = True   # NUMBER -> exact Decimal
    dsn = cfg.get("dsn") or oracledb.makedsn(cfg["host"], int(cfg.get("port") or 1521), service_name=cfg.get("service_name"))
    user = cred.get("username") or cfg.get("username")
    if not user or not cred.get("password"):
        raise QueryError("This Oracle connection needs a username and password.")
    conn = oracledb.connect(user=user, password=cred["password"], dsn=dsn)
    try:
        conn.call_timeout = int(ctx.timeout * 1000)
        ctx.on_cancel(conn.cancel)
        cur = conn.cursor()
        cur.arraysize = 5000
        cur.execute("SET TRANSACTION READ ONLY")
        ctx.check()
        cur.execute(sql)
        return _fetch(cur, max_rows, dates)
    finally:
        try:
            conn.rollback()
            conn.close()
        except Exception:
            pass


def _run_athena(cfg, cred, sql, max_rows, ctx, dates):
    region = cfg.get("region") or "eu-west-1"
    ath = _aws_session(cfg, cred, region).client("athena", region_name=region)
    params = dict(QueryString=sql, WorkGroup=cfg.get("workgroup") or "primary",
                  QueryExecutionContext={"Database": cfg["database"], "Catalog": cfg.get("catalog") or "AwsDataCatalog"})
    if cfg.get("output_location"):
        params["ResultConfiguration"] = {"OutputLocation": cfg["output_location"]}
    qid = ath.start_query_execution(**params)["QueryExecutionId"]
    ctx.on_cancel(lambda: ath.stop_query_execution(QueryExecutionId=qid))
    delay = 0.4
    while True:
        status = ath.get_query_execution(QueryExecutionId=qid)["QueryExecution"]["Status"]
        state = status["State"]
        if state == "SUCCEEDED":
            break
        if state in ("FAILED", "CANCELLED"):
            raise QueryError(f"Athena query {state.lower()}: {status.get('StateChangeReason', 'no reason given')}")
        try:
            ctx.check()
        except QueryError:
            try:
                ath.stop_query_execution(QueryExecutionId=qid)
            except Exception:
                pass
            raise
        time.sleep(delay)
        delay = min(delay * 1.5, 3.0)
    cols, rows, truncated, first = None, [], False, True
    for page in ath.get_paginator("get_query_results").paginate(QueryExecutionId=qid, PaginationConfig={"PageSize": 1000}):
        rs = page["ResultSet"]
        if cols is None:
            cols = [c["Name"] for c in rs["ResultSetMetadata"]["ColumnInfo"]]
        data = rs.get("Rows", [])
        if first:
            first = False
            if data and [d.get("VarCharValue", "") for d in data[0]["Data"]] == cols:
                data = data[1:]  # Athena repeats the header as the first row of a SELECT
        for r in data:
            if len(rows) >= max_rows:
                truncated = True
                break
            rows.append([normalize_value(d.get("VarCharValue"), dates) for d in r["Data"]])
        if truncated:
            break
        ctx.check()
    return cols or [], rows, truncated


def _run_redshift(cfg, cred, sql, max_rows, ctx, dates):
    rc = _need("redshift_connector", "redshift_connector")
    user = cred.get("username") or cfg.get("username")
    if cfg.get("auth_mode") == "iam":
        kw = dict(iam=True, database=cfg["database"], db_user=user, region=cfg.get("region") or "eu-west-1")
        if cfg.get("host"):
            kw.update(host=cfg["host"], port=int(cfg.get("port") or 5439))
        if cfg.get("cluster_identifier"):
            kw["cluster_identifier"] = cfg["cluster_identifier"]
        if cfg.get("serverless_workgroup"):
            kw.update(is_serverless=True, serverless_work_group=cfg["serverless_workgroup"])
        if cfg.get("aws_profile"):
            kw["profile"] = cfg["aws_profile"]
        conn = rc.connect(**kw)
    else:
        if not user or not cred.get("password"):
            raise QueryError("This Redshift connection needs a username and password.")
        conn = rc.connect(host=cfg["host"], port=int(cfg.get("port") or 5439), database=cfg["database"],
                          user=user, password=cred["password"], ssl=True, timeout=ctx.timeout)
    try:
        ctx.on_cancel(conn.close)
        cur = conn.cursor()
        cur.execute(f"SET statement_timeout TO {int(ctx.timeout * 1000)}")
        ctx.check()
        cur.execute(sql)
        return _fetch(cur, max_rows, dates)
    finally:
        try:
            conn.rollback()
            conn.close()
        except Exception:
            pass


def _run_sqlite(cfg, cred, sql, max_rows, ctx, dates, data_dir=None):
    base = os.path.realpath(data_dir or ".")
    path = os.path.realpath(os.path.join(base, cfg["path"]))
    if not path.startswith(base + os.sep) or not os.path.exists(path):
        raise QueryError("The demo database file was not found in the data folder.")
    conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True, check_same_thread=False)
    try:
        ctx.on_cancel(conn.interrupt)
        cur = conn.cursor()
        cur.execute(sql)
        return _fetch(cur, max_rows, dates)
    except sqlite3.OperationalError as exc:
        raise QueryError(str(exc))
    finally:
        conn.close()


DRIVERS = {"hive": _run_hive, "oracle": _run_oracle, "athena": _run_athena, "redshift": _run_redshift, "sqlite": _run_sqlite}


def run_query(conn_type, cfg, cred, sql, max_rows, ctx, dates=True, data_dir=None):
    """Run one read-only query. Returns dict(columns, rows, truncated, seconds)."""
    if conn_type not in DRIVERS:
        raise QueryError(f"Unknown connection type '{conn_type}'.")
    clean = check_read_only(sql)
    started = time.time()
    try:
        if conn_type == "sqlite":
            cols, rows, truncated = _run_sqlite(cfg, cred, clean, max_rows, ctx, dates, data_dir=data_dir)
        else:
            cols, rows, truncated = DRIVERS[conn_type](cfg, cred, clean, max_rows, ctx, dates)
    except QueryError:
        raise
    except Exception as exc:  # driver errors: keep the message, drop the stack
        if ctx.cancelled.is_set():
            raise QueryError("Cancelled.")
        msg = str(exc).strip().splitlines()[0] if str(exc).strip() else exc.__class__.__name__
        raise QueryError(f"{TYPES[conn_type]['label']} error: {msg[:500]}")
    if len(set(c.lower() for c in cols)) != len(cols):
        raise QueryError("The query returns two columns with the same name. Give each column a unique alias.")
    return dict(columns=cols, rows=rows, truncated=truncated, seconds=round(time.time() - started, 2))


# ---------------------------------------------------------------- DDL fetch (fixed, read-only metadata queries)
_TABLE_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_$#]*(\.[A-Za-z_][A-Za-z0-9_$#]*){0,2}$")


def parse_table_list(text):
    if ";" in (text or ""):
        raise QueryError("Separate table names with commas, not ';'.")
    names = [t.strip().strip("`\"") for t in re.split(r"[,\s]+", text or "") if t.strip()]
    if not names:
        raise QueryError("Enter at least one table name, e.g. imp.loan_impairments")
    if len(names) > 20:
        raise QueryError("Fetch up to 20 tables at a time.")
    bad = [n for n in names if not _TABLE_RE.match(n)]
    if bad:
        raise QueryError(f"Not a valid table name: {bad[0]}. Use schema.table with letters, digits and _.")
    return names


def _split(name, default_schema=None):
    parts = name.split(".")
    return (parts[-2] if len(parts) >= 2 else default_schema), parts[-1]


def _oracle_type(dt_, length, prec, scale, char_len):
    t = (dt_ or "").upper()
    if t in ("VARCHAR2", "NVARCHAR2", "CHAR", "NCHAR", "VARCHAR"):
        return f"{t}({char_len or length})"
    if t == "NUMBER":
        if prec in ("", None):
            return "NUMBER" if scale in ("", None, "0") else f"NUMBER(38,{scale})"
        return f"NUMBER({prec},{scale})" if scale not in ("", None, "0") else f"NUMBER({prec})"
    if t == "FLOAT" and prec:
        return f"FLOAT({prec})"
    if t == "RAW":
        return f"RAW({length})"
    return t


def _pg_type(dt_, clen, prec, scale):
    t = (dt_ or "").lower()
    if t == "character varying":
        return f"VARCHAR({clen})" if clen else "VARCHAR"
    if t == "character":
        return f"CHAR({clen})" if clen else "CHAR"
    if t == "numeric":
        return f"NUMERIC({prec},{scale})" if prec else "NUMERIC"
    return {"timestamp without time zone": "TIMESTAMP", "timestamp with time zone": "TIMESTAMPTZ",
            "time without time zone": "TIME"}.get(t, t.upper())


def _glue_ddl(session, region, database, table):
    glue = session.client("glue", region_name=region)
    try:
        t = glue.get_table(DatabaseName=database, Name=table)["Table"]
    except Exception as exc:
        raise QueryError(f"Glue could not read {database}.{table}: {str(exc).splitlines()[0][:200]}")
    sd = t.get("StorageDescriptor", {}) or {}
    col = lambda c: f"  `{c['Name']}` {c['Type']}" + (f" COMMENT '{c['Comment']}'" if c.get("Comment") else "")  # noqa: E731
    lines = [col(c) for c in sd.get("Columns", [])]
    ddl = f"CREATE EXTERNAL TABLE `{database}`.`{t['Name']}` (\n" + ",\n".join(lines) + "\n)"
    if t.get("PartitionKeys"):
        ddl += "\nPARTITIONED BY (\n" + ",\n".join(col(c) for c in t["PartitionKeys"]) + "\n)"
    lib = ((sd.get("SerdeInfo") or {}).get("SerializationLibrary") or "") + " " + (sd.get("InputFormat") or "")
    fmt = next((f for k, f in (("parquet", "PARQUET"), ("orc", "ORC"), ("avro", "AVRO"), ("json", "JSONFILE"),
                               ("TextInputFormat", "TEXTFILE"), ("OpenCSV", "TEXTFILE")) if k.lower() in lib.lower()), "")
    if fmt:
        ddl += f"\nSTORED AS {fmt}"
    if sd.get("Location"):
        ddl += f"\nLOCATION '{sd['Location']}'"
    params = t.get("Parameters") or {}
    keep = {k: v for k, v in params.items() if k in ("table_type", "classification", "format", "write_compression", "parquet.compression")}
    if keep:
        ddl += "\nTBLPROPERTIES (" + ", ".join(f"'{k}'='{v}'" for k, v in sorted(keep.items())) + ")"
    return ddl + ";"


def fetch_ddl(conn_type, cfg, cred, tables, ctx, data_dir=None):
    """Return CREATE TABLE text for each table, using fixed metadata queries (never user SQL)."""
    names = parse_table_list(tables)
    out, missing = [], []

    def rows_of(sql):
        if conn_type == "sqlite":
            return _run_sqlite(cfg, cred, sql, 5000, ctx, False, data_dir=data_dir)[1]
        return DRIVERS[conn_type](cfg, cred, sql, 5000, ctx, False)[1]

    try:
        for name in names:
            ctx.check()
            if conn_type in ("hive",):
                text = "\n".join(r[0] for r in rows_of(f"SHOW CREATE TABLE {name}"))
                out.append(text.rstrip().rstrip(";") + ";")
            elif conn_type == "oracle":
                owner, tbl = _split(name)
                owner_sql = f"'{owner.upper()}'" if owner else "SYS_CONTEXT('USERENV','CURRENT_SCHEMA')"
                cols = rows_of("SELECT column_name, data_type, data_length, data_precision, data_scale, nullable, char_length "
                               f"FROM all_tab_columns WHERE owner = {owner_sql} AND table_name = '{tbl.upper()}' ORDER BY column_id")
                if not cols:
                    missing.append(name)
                    continue
                pk = [r[0] for r in rows_of(
                    "SELECT cc.column_name FROM all_constraints c JOIN all_cons_columns cc "
                    "ON c.owner = cc.owner AND c.constraint_name = cc.constraint_name "
                    f"WHERE c.constraint_type = 'P' AND c.owner = {owner_sql} AND c.table_name = '{tbl.upper()}' ORDER BY cc.position")]
                body = [f"  {c[0]} {_oracle_type(c[1], c[2], c[3], c[4], c[6])}{' NOT NULL' if c[5] == 'N' else ''}" for c in cols]
                if pk:
                    body.append(f"  PRIMARY KEY ({', '.join(pk)})")
                out.append(f"CREATE TABLE {(owner or 'CURRENT_SCHEMA').upper()}.{tbl.upper()} (\n" + ",\n".join(body) + "\n);")
            elif conn_type == "athena":
                region = cfg.get("region") or "eu-west-1"
                db_, tbl = _split(name, cfg.get("database"))
                out.append(_glue_ddl(_aws_session(cfg, cred, region), region, db_, tbl))
            elif conn_type == "redshift":
                schema, tbl = _split(name, "public")
                cols = rows_of("SELECT column_name, data_type, character_maximum_length, numeric_precision, numeric_scale, "
                               "is_nullable, column_default FROM information_schema.columns "
                               f"WHERE table_schema = '{schema.lower()}' AND table_name = '{tbl.lower()}' ORDER BY ordinal_position")
                if not cols:
                    missing.append(name)
                    continue
                pk = [r[0] for r in rows_of(
                    "SELECT kcu.column_name FROM information_schema.table_constraints tc "
                    "JOIN information_schema.key_column_usage kcu ON tc.constraint_name = kcu.constraint_name "
                    "AND tc.table_schema = kcu.table_schema "
                    f"WHERE tc.constraint_type = 'PRIMARY KEY' AND tc.table_schema = '{schema.lower()}' "
                    f"AND tc.table_name = '{tbl.lower()}' ORDER BY kcu.ordinal_position")]
                body = [f"  {c[0]} {_pg_type(c[1], c[2], c[3], c[4])}{' NOT NULL' if c[5] == 'NO' else ''}"
                        + (f" DEFAULT {c[6]}" if c[6] and not str(c[6]).startswith('"identity"') else "") for c in cols]
                if pk:
                    body.append(f"  PRIMARY KEY ({', '.join(pk)})")
                out.append(f"CREATE TABLE {schema.lower()}.{tbl.lower()} (\n" + ",\n".join(body) + "\n);")
            elif conn_type == "sqlite":
                r = rows_of(f"SELECT sql FROM sqlite_master WHERE type = 'table' AND lower(name) = lower('{_split(name)[1]}')")
                if not r:
                    missing.append(name)
                    continue
                out.append(r[0][0].rstrip(";") + ";")
            else:
                raise QueryError("DDL fetch is not available for this connection type.")
    except QueryError:
        raise
    except Exception as exc:
        msg = str(exc).strip().splitlines()[0] if str(exc).strip() else exc.__class__.__name__
        raise QueryError(f"{TYPES[conn_type]['label']} error: {msg[:400]}")
    if missing and not out:
        raise QueryError(f"Not found, or no access: {', '.join(missing)}")
    return dict(ddl="\n\n".join(out), tables=len(out), missing=missing)
