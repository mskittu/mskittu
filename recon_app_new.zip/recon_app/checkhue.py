"""
Check the Hive (Hue) connection step by step and say exactly what to fix.

    Windows:  double-click deploy\\check_hive.bat
    or:       .venv\\Scripts\\python checkhue.py

It reads the same .env as the website, then checks: settings -> network -> HTTPS certificate ->
Hue sign-in with your LDAP username/password -> SELECT 1 -> (optional) a query of your own.
Your password is only used for this check and is not saved anywhere.
"""
import getpass
import os
import socket
import sys
import time
from urllib.parse import urlparse

BASE = os.path.dirname(os.path.abspath(__file__))
OK, BAD, INFO = "[ OK ]", "[FAIL]", "[ .. ]"


def load_env():
    path = os.path.join(BASE, ".env")
    if not os.path.exists(path):
        print(BAD, "No .env file next to app.py. Copy .env.vdi.example to .env first (run_local_windows.bat does this).")
        return False
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
    return True


def fix(*lines):
    for l in lines:
        print("        ->", l)


def main():
    print("=" * 74)
    print(" Source Target Recon - Hive (Hue) connection check")
    print("=" * 74)
    print(INFO, f"Python {sys.version.split()[0]} on {sys.platform}")
    if sys.version_info[:2] != (3, 11):
        print(INFO, "Tested on Python 3.11. Other versions may work but 3.11 is recommended.")
    if not load_env():
        return 1
    try:
        import requests  # noqa: F401
    except ImportError:
        print(BAD, "The 'requests' package is missing.")
        fix(r".venv\Scripts\pip install -r requirements-vdi.txt")
        return 1
    sys.path.insert(0, BASE)
    import connectors as C
    C.SYSTEM_CERTS = C._use_system_certs() or C.SYSTEM_CERTS

    # 1. settings
    url = os.environ.get("RECON_HUE_URL", "").strip()
    auth = os.environ.get("RECON_AUTH", "local").strip().lower()
    print()
    print("1. Settings in .env")
    if not url:
        print(BAD, "RECON_HUE_URL is empty or still has a # in front of it.")
        fix("Open .env in Notepad and set:", "RECON_HUE_URL=https://nykpsr000012067.intranet.barcapint.com:8888")
        return 1
    if not url.lower().startswith(("http://", "https://")):
        url = "https://" + url
    u = urlparse(url)
    host, port = u.hostname, u.port or (443 if u.scheme == "https" else 80)
    print(OK, f"RECON_HUE_URL = {url}")
    if u.path.strip("/") and u.path.strip("/") not in ("hue",):
        print(INFO, f"The address has a path ({u.path}); Recon strips /hue/accounts/login automatically.")
    print(OK if auth == "hue" else INFO, f"RECON_AUTH = {auth}" + ("" if auth == "hue" else
          "   (set RECON_AUTH=hue so people sign in to Recon with their LDAP login and Hive runs as them)"))
    cfg = {k: v for k, v in dict(
        url=url, api=os.environ.get("RECON_HUE_API", "auto").strip().lower(),
        login_server=os.environ.get("RECON_HUE_LOGIN_SERVER", "").strip(),
        verify_ssl="no" if os.environ.get("RECON_HUE_VERIFY_SSL", "1") == "0" else "yes",
        ca_bundle=os.environ.get("RECON_HUE_CA_BUNDLE", "").strip(),
        dialect="hive", database=os.environ.get("RECON_HUE_DATABASE", "default").strip()).items() if v}
    print(INFO, f"Certificate check: {'OFF (RECON_HUE_VERIFY_SSL=0)' if cfg['verify_ssl'] == 'no' else 'on'}"
          + (f", CA file {cfg['ca_bundle']}" if cfg.get("ca_bundle") else "")
          + (", Windows certificate store: yes" if C.SYSTEM_CERTS else ", Windows certificate store: no (pip install truststore)"))
    if cfg.get("ca_bundle") and not os.path.exists(cfg["ca_bundle"]):
        print(BAD, f"RECON_HUE_CA_BUNDLE points to a file that does not exist: {cfg['ca_bundle']}")
        fix("Fix the path, or remove that line to use the Windows certificate store.")
        return 1
    for k in ("HTTPS_PROXY", "HTTP_PROXY", "NO_PROXY", "https_proxy", "no_proxy"):
        if os.environ.get(k):
            print(INFO, f"{k} = {os.environ[k]}")

    # 2. network
    print()
    print(f"2. Network: can this machine reach {host}:{port}?")
    try:
        ip = socket.gethostbyname(host)
        print(OK, f"{host} resolves to {ip}")
    except OSError:
        print(BAD, f"The name {host} could not be found (DNS).")
        fix("Check the spelling of the Hue address.", "Open the Hue page in Edge/Chrome on this same machine: if it opens there, ask IT why Python can't resolve it.")
        return 1
    import requests.utils as ru
    proxy = None if ru.should_bypass_proxies(url, no_proxy=os.environ.get("NO_PROXY") or os.environ.get("no_proxy")) else (ru.get_environ_proxies(url) or {}).get(u.scheme)
    if proxy:
        print(INFO, f"Requests to Hue go through the proxy {proxy} (from HTTPS_PROXY), so the direct port test is skipped.")
        print(INFO, "If Hue is internal, add its domain to NO_PROXY in .env, e.g. NO_PROXY=localhost,127.0.0.1,.intranet.barcapint.com")
    t = time.time()
    try:
        if proxy:
            raise StopIteration
        socket.create_connection((host, port), timeout=10).close()
        print(OK, f"Port {port} is open ({round((time.time() - t) * 1000)} ms)")
    except StopIteration:
        pass
    except OSError as exc:
        print(BAD, f"Can't open port {port}: {exc}")
        fix("A firewall or the VDI network blocks it. Open the Hue page in the browser on this machine.",
            "If the browser works only through a proxy, add the proxy to .env (HTTPS_PROXY=...) and remove the host from NO_PROXY.")
        return 1

    # 3. HTTPS + Hue sign-in page
    import requests
    print()
    print("3. Hue sign-in page and certificate")
    login_url = url.rstrip("/").split("/hue")[0] + "/hue/accounts/login/"
    verify = cfg.get("ca_bundle") or (cfg["verify_ssl"] == "yes")
    try:
        r = requests.get(login_url, timeout=20, verify=verify)
        print(OK, f"{login_url} answered HTTP {r.status_code}")
    except requests.exceptions.SSLError:
        print(BAD, "Hue's HTTPS certificate is not trusted (that is the 'Not secure' warning in the browser).")
        try:
            requests.get(login_url, timeout=20, verify=False)
            print(INFO, "Without the certificate check Hue answers, so only the certificate needs fixing.")
        except Exception:
            pass
        fix("Best: get the company root CA file from IT (e.g. C:\\certs\\company-root-ca.pem) and set",
            "RECON_HUE_CA_BUNDLE=C:\\certs\\company-root-ca.pem",
            "Or make sure 'truststore' is installed (uses the Windows certificate store):  .venv\\Scripts\\pip install truststore",
            "Local test only: RECON_HUE_VERIFY_SSL=0")
        return 1
    except requests.exceptions.ProxyError as exc:
        print(BAD, f"The proxy refused the request: {str(exc)[:200]}")
        fix("Add the Hue domain to NO_PROXY in .env, e.g.  NO_PROXY=localhost,127.0.0.1,.intranet.barcapint.com")
        return 1
    except requests.exceptions.RequestException as exc:
        print(BAD, f"Hue did not answer: {str(exc)[:200]}")
        fix("Check the address and port, and NO_PROXY in .env.")
        return 1
    import re
    servers = re.findall(r'<option[^>]*value=["\']([^"\']*)["\']', (re.search(r'<select[^>]*name=["\']server["\'][^>]*>(.*?)</select>', r.text, re.S | re.I) or [None, ""])[1] or "")
    if servers:
        print(INFO, f"The Hue page has a sign-in server dropdown with: {', '.join(servers)}")
        if cfg.get("login_server") and cfg["login_server"] not in servers:
            print(BAD, f"RECON_HUE_LOGIN_SERVER={cfg['login_server']} is not one of them.")
            fix(f"Set RECON_HUE_LOGIN_SERVER={servers[0]}")
            return 1

    # 4. sign in
    print()
    print("4. Sign in to Hue with your LDAP username and password (used for this check only)")
    user = input("        Username: ").strip()
    pw = getpass.getpass("        Password (not shown): ")
    if not user or not pw:
        print(BAD, "Username and password are needed for the next steps.")
        return 1
    try:
        C.hue_check_login(cfg, user, pw)
        print(OK, "Hue accepted your username and password.")
    except C.QueryError as exc:
        print(BAD, str(exc))
        fix("Use exactly the login you use on the Hue page in the browser.",
            "If Hue has a server dropdown, RECON_HUE_LOGIN_SERVER must match it (e.g. LDAP).",
            "Too many wrong passwords can lock your LDAP account - stop and check before retrying.")
        return 1

    # 5. SELECT 1
    print()
    print("5. Run a test query through Hue: SELECT 1")
    cred = {"username": user, "password": pw}
    try:
        res = C.run_query("hue", cfg, cred, "SELECT 1", 10, C.RunContext(120))
        print(OK, f"SELECT 1 returned {res['rows'][0][0] if res['rows'] else 'no rows'} in {res['seconds']} s. Hive through Hue works.")
    except C.QueryError as exc:
        print(BAD, str(exc))
        fix("You can sign in but Hive did not run the query. Try SELECT 1 in the Hue editor yourself:",
            "if it fails there too, ask the Hadoop team for Hive access; if it works there, send this output to the Recon admin.")
        return 1

    # 6. own query (optional)
    print()
    q = input("6. Optional: type a table to read 5 rows from (e.g. imp.mds_monthly), or press Enter to finish: ").strip()
    if q:
        try:
            res = C.run_query("hue", cfg, cred, f"SELECT * FROM {q} LIMIT 5", 5, C.RunContext(300))
            print(OK, f"{q}: {len(res['columns'])} columns, {len(res['rows'])} rows in {res['seconds']} s")
            print("        columns:", ", ".join(res["columns"][:15]) + (" ..." if len(res["columns"]) > 15 else ""))
            for row in res["rows"]:
                print("        ", " | ".join(str(v)[:18] for v in row[:8]))
        except C.QueryError as exc:
            print(BAD, str(exc))
    print()
    print("All checks passed. Start the website (run_local_windows.bat), sign in with the same login,")
    print("pick 'Hive (Hue)' as Source on Compare records, press Test, then write your SELECT and Run.")
    return 0


if __name__ == "__main__":
    try:
        code = main()
    except KeyboardInterrupt:
        code = 1
    if os.name == "nt":
        input("\nPress Enter to close this window.")
    raise SystemExit(code)
