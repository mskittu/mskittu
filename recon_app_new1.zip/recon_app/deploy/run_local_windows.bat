@echo off
setlocal
REM ======================================================================
REM  Source Target Recon - start on a Windows laptop / VDI
REM  Double-click this file. See WINDOWS_SETUP.txt for the full steps.
REM ======================================================================
REM  If pip must use your company package mirror, put the options here, e.g.
REM  set "PIP_OPTS=--index-url https://artifactory.example.com/api/pypi/pypi/simple --trusted-host artifactory.example.com"
set "PIP_OPTS="
REM  If Python is still "not found", put the full path to python.exe here, e.g.
REM  set "PYTHON_EXE=C:\Users\YOURNAME\AppData\Local\Programs\Python\Python315\python.exe"
set "PYTHON_EXE="

cd /d "%~dp0.."

REM ---- find Python: your PYTHON_EXE, then 3.11, then any 3.10 or newer ----
set "PY="
if defined PYTHON_EXE call :trypy "%PYTHON_EXE%"
if not defined PY py -3.11 --version >nul 2>nul && set "PY=py -3.11"
if not defined PY py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul && set "PY=py -3"
if not defined PY python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul && set "PY=python"
if not defined PY python3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul && set "PY=python3"
REM ---- not on PATH: look in the usual install folders ----
if not defined PY for /d %%d in ("%LOCALAPPDATA%\Programs\Python\Python3*" "%ProgramFiles%\Python3*" "%ProgramFiles(x86)%\Python3*" "C:\Python3*" "%USERPROFILE%\AppData\Local\Python\*" "%USERPROFILE%\anaconda3" "%USERPROFILE%\miniconda3" "%LOCALAPPDATA%\anaconda3" "%LOCALAPPDATA%\miniconda3" "%ProgramData%\anaconda3" "%ProgramData%\miniconda3" "C:\Tools\Python3*" "D:\Python3*") do if exist "%%~d\python.exe" call :trypy "%%~d\python.exe"
if not defined PY (
  echo.
  echo  [FAIL] Python 3.10 or newer was not found.
  echo         1. Press Windows key, type  python , right-click "Python 3.x" - Open file location.
  echo            Copy the folder path of python.exe.
  echo         2. Open this file in Notepad, set PYTHON_EXE=that-folder\python.exe at the top, save.
  echo         3. Double-click this file again.
  echo         Or install Python from your company software portal / python.org with "Add python.exe to PATH".
  echo.
  pause
  exit /b 1
)
for /f "delims=" %%v in ('%PY% --version 2^>^&1') do echo  Using %%v

if not exist ".venv\Scripts\python.exe" (
  echo  Creating the Python environment .venv ...
  %PY% -m venv .venv
  if errorlevel 1 (
    echo  [FAIL] Could not create .venv. See WINDOWS_SETUP.txt, step 2.
    pause
    exit /b 1
  )
)

echo  Checking Python packages ...
".venv\Scripts\python.exe" -m pip install -q --disable-pip-version-check -r requirements-vdi.txt %PIP_OPTS%
if errorlevel 1 (
  if exist ".venv\.installed" (
    echo  [WARN] pip could not check for updates - starting with the packages already installed.
  ) else (
    echo.
    echo  [FAIL] pip could not download the packages.
    echo         Your VDI probably needs the company package mirror: edit PIP_OPTS at the top of this file.
    echo         See WINDOWS_SETUP.txt, step 3.
    pause
    exit /b 1
  )
) else (
  echo ok> ".venv\.installed"
)

REM ---- optional Oracle / AWS drivers: never block Hive ----
".venv\Scripts\python.exe" -m pip install -q --disable-pip-version-check -r requirements-vdi-optional.txt %PIP_OPTS% >nul 2>nul
if errorlevel 1 (
  echo  [INFO] Oracle / AWS drivers are not installed on this Python version. Hive through Hue works without them.
)

if not exist ".env" (
  copy ".env.vdi.example" ".env" >nul
  echo  Created .env from .env.vdi.example - check it in Notepad, see WINDOWS_SETUP.txt step 5.
)

echo.
echo  Starting Source Target Recon on http://127.0.0.1:5000
echo  Keep this window open while you use the website. Press Ctrl+C to stop.
echo.
start "" cmd /c "timeout /t 4 >nul & start http://127.0.0.1:5000"
".venv\Scripts\python.exe" app.py
echo.
echo  The website stopped. If you see an error above, see WINDOWS_SETUP.txt "Common problems".
pause
exit /b 0

:trypy
if defined PY goto :eof
if not exist "%~1" goto :eof
"%~1" -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
if errorlevel 1 goto :eof
set PY="%~1"
goto :eof
