"""
tests/test_validators.py
Unit tests for all PySpark validation check functions
"""

import pytest
from pyspark.sql import SparkSession
from backend.validation_engine.row_count import (
    validate_row_count, validate_nulls,
    validate_pk_integrity, validate_duplicates
)
from backend.validation_engine.pk_integrity import check_pk
from backend.validation_engine.duplicate_finder import check_duplicates


@pytest.fixture(scope="session")
def spark():
    return SparkSession.builder.master("local[2]").appName("test").getOrCreate()


@pytest.fixture
def sample_df(spark):
    data = [(1, "Alice", "alice@x.com"),
            (2, "Bob",   "bob@x.com"),
            (3, "Carol", None)]
    return spark.createDataFrame(data, ["id", "name", "email"])


@pytest.fixture
def dupe_df(spark):
    data = [(1, "Alice"), (2, "Bob"), (2, "Bob-dupe")]
    return spark.createDataFrame(data, ["id", "name"])


class TestRowCount:

    def test_equal_counts_pass(self, sample_df):
        result = validate_row_count(sample_df, sample_df)
        assert result.status == "PASS"

    def test_different_counts_fail(self, spark, sample_df):
        small_df = spark.createDataFrame([(1, "A", "a@b.com")], ["id", "name", "email"])
        result = validate_row_count(sample_df, small_df)
        assert result.status == "FAIL"


class TestNullCheck:

    def test_no_nulls_pass(self, sample_df):
        result = validate_nulls(sample_df, "id")
        assert result.status == "PASS"

    def test_nulls_below_threshold_warn(self, sample_df):
        result = validate_nulls(sample_df, "email", threshold=0.5)
        assert result.status == "WARN"

    def test_nulls_above_threshold_fail(self, sample_df):
        result = validate_nulls(sample_df, "email", threshold=0.01)
        assert result.status == "FAIL"


class TestPKIntegrity:

    def test_unique_pk_pass(self, sample_df):
        result = validate_pk_integrity(sample_df, "id")
        assert result.status == "PASS"

    def test_duplicate_pk_fail(self, dupe_df):
        result = validate_pk_integrity(dupe_df, "id")
        assert result.status == "FAIL"


class TestDuplicates:

    def test_no_duplicates_pass(self, sample_df):
        result = check_duplicates(sample_df, ["id"])
        assert result.status == "PASS"

    def test_duplicates_found_fail(self, dupe_df):
        result = check_duplicates(dupe_df, ["id"])
        assert result.status == "FAIL"
