"""
tests/test_schema.py
Unit tests for schema reader and schema diff logic
"""

import pytest
from unittest.mock import MagicMock, patch
from backend.validation_engine.test_generator import TestCaseGenerator
from backend.validation_engine.dtype_validator import validate_types, SAFE_CASTS


class TestSchemaDiff:

    def test_compute_diff_no_changes(self):
        schema = {"CUST_ID": "NUMBER", "NAME": "VARCHAR2"}
        gen = TestCaseGenerator.__new__(TestCaseGenerator)
        diff = gen._compute_diff(schema, schema)
        assert diff["added_in_source_missing_in_target"] == []
        assert diff["removed_from_source_present_in_target"] == []
        assert diff["type_mismatches"] == {}

    def test_compute_diff_missing_column(self):
        src = {"CUST_ID": "NUMBER", "NAME": "VARCHAR2", "LOYALTY": "VARCHAR2"}
        tgt = {"CUST_ID": "NUMBER", "NAME": "VARCHAR2"}
        gen = TestCaseGenerator.__new__(TestCaseGenerator)
        diff = gen._compute_diff(src, tgt)
        assert "LOYALTY" in diff["added_in_source_missing_in_target"]

    def test_compute_diff_type_mismatch(self):
        src = {"DOB": "DATE"}
        tgt = {"DOB": "STRING"}
        gen = TestCaseGenerator.__new__(TestCaseGenerator)
        diff = gen._compute_diff(src, tgt)
        assert "DOB" in diff["type_mismatches"]

    def test_safe_casts_defined(self):
        assert ("VARCHAR2", "STRING") in SAFE_CASTS
        assert ("NUMBER", "BIGINT") in SAFE_CASTS
        assert ("DATE", "TIMESTAMP") in SAFE_CASTS


class TestDtypeValidator:

    def test_matching_types_returns_no_results(self):
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.master("local").getOrCreate()
        data = [(1, "Alice")]
        src = spark.createDataFrame(data, ["id", "name"])
        tgt = spark.createDataFrame(data, ["id", "name"])
        results = validate_types(src, tgt)
        assert all(r.status != "FAIL" for r in results)

    def test_missing_column_is_fail(self):
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.master("local").getOrCreate()
        src = spark.createDataFrame([(1, "A", "GOLD")], ["id", "name", "tier"])
        tgt = spark.createDataFrame([(1, "A")], ["id", "name"])
        results = validate_types(src, tgt)
        fail_checks = [r for r in results if r.status == "FAIL"]
        assert any("tier" in r.check for r in fail_checks)
