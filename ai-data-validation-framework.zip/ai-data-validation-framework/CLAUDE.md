# AI Data Validation Framework — Claude Instructions

## Project Context
This is an AI-powered data validation framework that uses Claude API to dynamically
generate test cases for validating data across Oracle, Hive, and Azure ADLS Gen2.

## Key Modules
- `backend/validation_engine/test_generator.py` — Claude API integration
- `backend/validation_engine/row_count.py` — Core PySpark validation checks
- `backend/connectors/` — Oracle, Hive, Azure connectors
- `backend/api/routes.py` — FastAPI REST endpoints
- `data_pipelines/validation_dag.py` — Airflow orchestration

## Claude API Usage
Model: claude-sonnet-4-20250514
Purpose: Generate validation test cases from schema diffs
Always return JSON array from the prompt.

## Running Locally
```bash
pip install -r requirements.txt
cp .envire/.env.example .env
python backend/main.py
```

## Running Tests
```bash
pytest tests/ -v --cov=backend
```
