"""
report_engine/report_builder.py
Builds structured Pass/Fail validation reports and saves to ADLS
"""

import json
import uuid
from datetime import datetime, timezone
from typing import List
from ..validation_engine.row_count import CheckResult
from ..connectors.azure_conn import AzureADLSConnector


class ReportBuilder:
    """
    Assembles all CheckResult objects into a structured report,
    computes overall pass/fail status, and persists to Azure ADLS.
    """

    def __init__(self, results: List[CheckResult], metadata: dict = None):
        self.results = results
        self.metadata = metadata or {}
        self.adls = AzureADLSConnector()

    def build(self, run_id: str = None) -> dict:
        """Build the full report dict."""
        run_id = run_id or f"RUN-{uuid.uuid4().hex[:8].upper()}"

        passed   = [r for r in self.results if r.status == "PASS"]
        failed   = [r for r in self.results if r.status == "FAIL"]
        warnings = [r for r in self.results if r.status == "WARN"]

        # Overall: FAIL if any failures, WARN if only warnings, else PASS
        if failed:
            overall = "FAIL"
        elif warnings:
            overall = "WARN"
        else:
            overall = "PASS"

        total = len(self.results)
        pass_rate = len(passed) / total if total > 0 else 0.0

        return {
            "run_id": run_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "overall_status": overall,
            "metadata": self.metadata,
            "summary": {
                "total_checks": total,
                "passed": len(passed),
                "failed": len(failed),
                "warnings": len(warnings),
                "pass_rate": round(pass_rate, 4),
            },
            "checks": [
                {
                    "check": r.check,
                    "status": r.status,
                    "detail": r.detail,
                    "source_val": r.source_val,
                    "target_val": r.target_val,
                }
                for r in self.results
            ],
        }

    def save(self, run_id: str = None) -> dict:
        """Build and persist the report to ADLS. Returns the report dict."""
        report = self.build(run_id)
        self.adls.write_report(report, report["run_id"])
        print(f"[ReportBuilder] Report saved: {report['run_id']} "
              f"({report['overall_status']}, "
              f"{report['summary']['pass_rate']:.1%} pass rate)")
        return report

    def print_summary(self):
        """Print a human-readable summary to stdout."""
        report = self.build()
        s = report["summary"]
        print("=" * 50)
        print(f"  Validation Run: {report['run_id']}")
        print(f"  Overall Status: {report['overall_status']}")
        print(f"  Pass Rate:      {s['pass_rate']:.1%}")
        print(f"  Checks:         {s['total_checks']} total")
        print(f"    PASS={s['passed']}  FAIL={s['failed']}  WARN={s['warnings']}")
        print("=" * 50)
        for r in self.results:
            icon = "✓" if r.status == "PASS" else ("✕" if r.status == "FAIL" else "⚠")
            print(f"  {icon} [{r.status}] {r.check}: {r.detail}")
