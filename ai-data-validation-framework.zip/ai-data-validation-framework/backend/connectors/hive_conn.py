"""
connectors/hive_conn.py
Apache Hive connector using PyHive + PySpark with Hive support
"""

from pyhive import hive
import pandas as pd
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
import os
from typing import Optional


class HiveConnector:
    """
    Connects to Apache Hive via PyHive for metadata queries
    and via SparkSession (with Hive support) for large DataFrame ops.
    """

    def __init__(self, config: dict = None):
        cfg = config or {}
        self.host = cfg.get("host", os.getenv("HIVE_HOST", "hiveserver2"))
        self.port = int(cfg.get("port", os.getenv("HIVE_PORT", 10000)))
        self.database = cfg.get("database", os.getenv("HIVE_DB", "default"))
        self.username = cfg.get("username", os.getenv("HIVE_USER", "hive"))
        self._spark: Optional[SparkSession] = None
        self.config = {"type": "hive", **cfg}

    @property
    def spark(self) -> SparkSession:
        if not self._spark:
            self._spark = (
                SparkSession.builder
                .appName("DataValidationHive")
                .config("spark.sql.catalogImplementation", "hive")
                .enableHiveSupport()
                .getOrCreate()
            )
        return self._spark

    def _pyhive_conn(self):
        return hive.Connection(
            host=self.host,
            port=self.port,
            database=self.database,
            username=self.username
        )

    def get_schema(self, table: str) -> pd.DataFrame:
        """Return DESCRIBE output as a DataFrame."""
        conn = self._pyhive_conn()
        df = pd.read_sql(f"DESCRIBE {self.database}.{table}", conn)
        return df[~df["col_name"].str.startswith("#")].reset_index(drop=True)

    def get_row_count(self, table: str) -> int:
        conn = self._pyhive_conn()
        cur = conn.cursor()
        cur.execute(f"SELECT COUNT(*) FROM {self.database}.{table}")
        return cur.fetchone()[0]

    def read_table_spark(self, table: str) -> DataFrame:
        """Load full Hive table as Spark DataFrame."""
        return self.spark.sql(f"SELECT * FROM {self.database}.{table}")

    def get_duplicate_count(self, table: str, pk_col: str) -> int:
        df = self.read_table_spark(table)
        return (
            df.groupBy(pk_col)
              .count()
              .filter(F.col("count") > 1)
              .count()
        )

    def list_tables(self) -> list:
        conn = self._pyhive_conn()
        cur = conn.cursor()
        cur.execute(f"SHOW TABLES IN {self.database}")
        return [row[0] for row in cur.fetchall()]
