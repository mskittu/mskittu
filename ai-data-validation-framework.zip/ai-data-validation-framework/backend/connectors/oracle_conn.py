"""
connectors/oracle_conn.py
Oracle Database connector using cx_Oracle
"""

import cx_Oracle
import pandas as pd
from pyspark.sql import SparkSession, DataFrame
from typing import Optional
import os


class OracleConnector:
    """
    Connects to Oracle source systems.
    Supports schema extraction, row counts, null counts,
    and Spark DataFrame reads for large-scale validation.
    """

    def __init__(self, config: dict = None):
        cfg = config or {}
        self.host = cfg.get("host", os.getenv("ORACLE_HOST"))
        self.port = int(cfg.get("port", os.getenv("ORACLE_PORT", 1521)))
        self.service = cfg.get("service", os.getenv("ORACLE_SERVICE"))
        self.user = cfg.get("user", os.getenv("ORACLE_USER"))
        self.password = cfg.get("password", os.getenv("ORACLE_PASS"))
        self.conn: Optional[cx_Oracle.Connection] = None
        self.config = {"type": "oracle", **cfg}

    def connect(self):
        dsn = cx_Oracle.makedsn(self.host, self.port, service_name=self.service)
        self.conn = cx_Oracle.connect(self.user, self.password, dsn)
        return self

    def get_schema(self, table: str) -> pd.DataFrame:
        """Return column metadata for a given table."""
        sql = """
            SELECT COLUMN_NAME, DATA_TYPE, DATA_LENGTH,
                   NULLABLE, COLUMN_ID
            FROM ALL_TAB_COLUMNS
            WHERE TABLE_NAME = :tbl
            ORDER BY COLUMN_ID
        """
        return pd.read_sql(sql, self.conn, params={"tbl": table.upper()})

    def get_row_count(self, table: str) -> int:
        cur = self.conn.cursor()
        cur.execute(f"SELECT COUNT(*) FROM {table}")
        return cur.fetchone()[0]

    def get_null_count(self, table: str, col: str) -> int:
        cur = self.conn.cursor()
        cur.execute(f"SELECT COUNT(*) FROM {table} WHERE {col} IS NULL")
        return cur.fetchone()[0]

    def get_pk_columns(self, table: str) -> list:
        """Retrieve primary key columns for a table."""
        sql = """
            SELECT cols.COLUMN_NAME
            FROM ALL_CONSTRAINTS cons
            JOIN ALL_CONS_COLUMNS cols
              ON cons.CONSTRAINT_NAME = cols.CONSTRAINT_NAME
             AND cons.OWNER = cols.OWNER
            WHERE cons.CONSTRAINT_TYPE = 'P'
              AND cons.TABLE_NAME = :tbl
            ORDER BY cols.POSITION
        """
        df = pd.read_sql(sql, self.conn, params={"tbl": table.upper()})
        return df["COLUMN_NAME"].tolist()

    def read_spark(self, table: str) -> DataFrame:
        """Read Oracle table into a Spark DataFrame via JDBC."""
        spark = SparkSession.builder.getOrCreate()
        jdbc_url = f"jdbc:oracle:thin:@//{self.host}:{self.port}/{self.service}"
        return (
            spark.read.format("jdbc")
            .option("url", jdbc_url)
            .option("dbtable", table)
            .option("user", self.user)
            .option("password", self.password)
            .option("driver", "oracle.jdbc.driver.OracleDriver")
            .load()
        )

    def close(self):
        if self.conn:
            self.conn.close()
