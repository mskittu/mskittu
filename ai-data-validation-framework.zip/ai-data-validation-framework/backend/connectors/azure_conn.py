"""
connectors/azure_conn.py
Azure Data Lake Storage Gen2 connector
Uses Managed Identity (DefaultAzureCredential) for auth.
"""

from azure.storage.filedatalake import DataLakeServiceClient
from azure.identity import DefaultAzureCredential
from pyspark.sql import SparkSession, DataFrame
import json
import os


class AzureADLSConnector:
    """
    Azure ADLS Gen2 connector.
    - Reads Parquet/Delta tables as Spark DataFrames
    - Writes validation report JSON back to ADLS
    - Uses Managed Identity (no hardcoded secrets)
    """

    def __init__(self, config: dict = None):
        cfg = config or {}
        self.account = cfg.get("account", os.getenv("ADLS_ACCOUNT"))
        self.container = cfg.get("container", os.getenv("ADLS_CONTAINER"))
        credential = DefaultAzureCredential()
        self.client = DataLakeServiceClient(
            account_url=f"https://{self.account}.dfs.core.windows.net",
            credential=credential
        )
        self.config = {"type": "adls", **cfg}

    def _abfss_path(self, path: str) -> str:
        return (
            f"abfss://{self.container}@"
            f"{self.account}.dfs.core.windows.net/{path}"
        )

    def read_parquet_spark(self, path: str) -> DataFrame:
        """Read Parquet files from ADLS into a Spark DataFrame."""
        spark = SparkSession.builder.getOrCreate()
        return spark.read.parquet(self._abfss_path(path))

    def read_delta_spark(self, path: str) -> DataFrame:
        """Read Delta Lake table from ADLS into a Spark DataFrame."""
        spark = SparkSession.builder.getOrCreate()
        return spark.read.format("delta").load(self._abfss_path(path))

    def write_report(self, report: dict, run_id: str):
        """Write a validation report JSON file to ADLS reports folder."""
        fs = self.client.get_file_system_client(self.container)
        file_path = f"reports/{run_id}.json"
        file_client = fs.get_file_client(file_path)
        content = json.dumps(report, indent=2).encode("utf-8")
        file_client.upload_data(content, overwrite=True)

    def list_reports(self, prefix: str = "reports/") -> list:
        """List all validation report files in the reports directory."""
        fs = self.client.get_file_system_client(self.container)
        return [p.name for p in fs.get_paths(path=prefix)]
