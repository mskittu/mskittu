"""
validation_engine/dtype_validator.py
Data type validation and cross-system type mapping
"""

from pyspark.sql import DataFrame
from typing import Dict, List
from .row_count import CheckResult

# Known safe cross-system type casts (no data loss)
SAFE_CASTS = {
    ("NUMBER", "BIGINT"),
    ("NUMBER", "DOUBLE"),
    ("VARCHAR2", "STRING"),
    ("CHAR", "STRING"),
    ("DATE", "TIMESTAMP"),
    ("CLOB", "STRING"),
}


def validate_types(src_df: DataFrame, tgt_df: DataFrame) -> List[CheckResult]:
    """
    Compare column types between source and target.
    Flags unsafe casts as FAIL, known safe casts as WARN.
    """
    src_types = dict(src_df.dtypes)
    tgt_types = dict(tgt_df.dtypes)
    results = []

    for col, src_type in src_types.items():
        if col not in tgt_types:
            results.append(CheckResult(
                check=f"missing_col_{col}",
                status="FAIL",
                detail=f"Column '{col}' present in source but missing in target",
                source_val=src_type,
                target_val="N/A"
            ))
            continue

        tgt_type = tgt_types[col]
        if src_type != tgt_type:
            pair = (src_type.upper(), tgt_type.upper())
            status = "WARN" if pair in SAFE_CASTS else "FAIL"
            results.append(CheckResult(
                check=f"dtype_{col}",
                status=status,
                detail=f"Type mismatch on '{col}': {src_type} → {tgt_type}",
                source_val=src_type,
                target_val=tgt_type
            ))

    # Check for extra columns in target not in source
    for col in tgt_types:
        if col not in src_types:
            results.append(CheckResult(
                check=f"extra_col_{col}",
                status="WARN",
                detail=f"Column '{col}' present in target but not in source",
                source_val="N/A",
                target_val=tgt_types[col]
            ))

    return results
