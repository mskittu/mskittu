"""
validation_engine/null_checker.py
Null value analysis across all columns of a DataFrame
"""

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from typing import List, Dict
from .row_count import CheckResult


def check_all_nulls(df: DataFrame, threshold: float = 0.05) -> List[CheckResult]:
    """Run null checks on every column in the DataFrame."""
    total = df.count()
    results = []
    null_counts = df.select(
        [F.count(F.when(F.col(c).isNull(), c)).alias(c) for c in df.columns]
    ).collect()[0].asDict()

    for col, null_cnt in null_counts.items():
        pct = null_cnt / max(total, 1)
        if pct == 0:
            status = "PASS"
        elif pct < threshold:
            status = "WARN"
        else:
            status = "FAIL"
        results.append(CheckResult(
            check=f"null_{col}",
            status=status,
            detail=f"{null_cnt:,} nulls ({pct:.2%})",
            source_val=str(null_cnt),
            target_val=f"{threshold:.0%}"
        ))
    return results


def null_summary(df: DataFrame) -> Dict[str, float]:
    """Return {column: null_percentage} for all columns."""
    total = df.count()
    null_counts = df.select(
        [F.count(F.when(F.col(c).isNull(), c)).alias(c) for c in df.columns]
    ).collect()[0].asDict()
    return {col: cnt / max(total, 1) for col, cnt in null_counts.items()}
