"""
validation_engine/duplicate_finder.py
Finds and reports duplicate records in source or target DataFrames
"""

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from typing import List, Optional
from .row_count import CheckResult


def find_duplicates(df: DataFrame, key_cols: List[str]) -> DataFrame:
    """Return a DataFrame of rows where key_cols have duplicates."""
    window_count = (
        df.groupBy(key_cols)
          .agg(F.count("*").alias("_dup_count"))
          .filter(F.col("_dup_count") > 1)
    )
    return df.join(window_count, on=key_cols, how="inner")


def check_duplicates(df: DataFrame, key_cols: List[str],
                     label: str = "target") -> CheckResult:
    """Return a CheckResult for duplicate key validation."""
    dup_df = find_duplicates(df, key_cols)
    dup_count = dup_df.count()
    status = "PASS" if dup_count == 0 else "FAIL"
    return CheckResult(
        check=f"duplicates_{label}_{'_'.join(key_cols)}",
        status=status,
        detail=f"{dup_count} duplicate rows on keys: {key_cols}",
        source_val=str(dup_count),
        target_val="0"
    )
