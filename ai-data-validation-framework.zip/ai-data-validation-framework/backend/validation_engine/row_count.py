"""
validation_engine/row_count.py
PySpark row count, null, duplicate, dtype, PK validation checks
"""

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from dataclasses import dataclass, field
from typing import List


@dataclass
class CheckResult:
    check: str
    status: str       # PASS | FAIL | WARN
    detail: str
    source_val: str = ""
    target_val: str = ""


def validate_row_count(src: DataFrame, tgt: DataFrame,
                       threshold: float = 0.001) -> CheckResult:
    """Validate row counts match between source and target."""
    sc, tc = src.count(), tgt.count()
    diff_pct = abs(sc - tc) / max(sc, 1)
    if sc == tc:
        return CheckResult("row_count", "PASS", f"Both={sc:,}", str(sc), str(tc))
    elif diff_pct < threshold:
        return CheckResult("row_count", "WARN",
                           f"Diff {diff_pct:.4%} within threshold", str(sc), str(tc))
    return CheckResult("row_count", "FAIL",
                       f"src={sc:,} tgt={tc:,} diff={diff_pct:.2%}", str(sc), str(tc))


def validate_nulls(df: DataFrame, col: str,
                   threshold: float = 0.05) -> CheckResult:
    """Check null percentage for a column against a threshold."""
    total = df.count()
    nulls = df.filter(F.col(col).isNull()).count()
    pct = nulls / max(total, 1)
    if pct == 0:
        status = "PASS"
    elif pct < threshold:
        status = "WARN"
    else:
        status = "FAIL"
    return CheckResult(f"null_{col}", status,
                       f"{nulls:,} nulls ({pct:.2%})", str(nulls), f"{threshold:.0%}")


def validate_pk_integrity(df: DataFrame, pk_col: str) -> CheckResult:
    """Check for duplicate values in the primary key column."""
    total = df.count()
    distinct = df.select(pk_col).distinct().count()
    dupes = total - distinct
    status = "PASS" if dupes == 0 else "FAIL"
    return CheckResult(f"pk_{pk_col}", status,
                       f"{dupes} duplicate PKs found", str(dupes), "0")


def validate_dtype_match(src: DataFrame, tgt: DataFrame) -> List[CheckResult]:
    """Compare data types column by column between source and target."""
    src_types = dict(src.dtypes)
    results = []
    for col, tgt_type in tgt.dtypes:
        if col not in src_types:
            results.append(CheckResult(f"missing_{col}", "FAIL",
                                       f"Column '{col}' missing in source"))
        elif src_types[col] != tgt_type:
            results.append(CheckResult(f"dtype_{col}", "WARN",
                                       f"Type mismatch on '{col}'",
                                       src_types[col], tgt_type))
    return results


def validate_duplicates(df: DataFrame, subset: List[str] = None) -> CheckResult:
    """Check for duplicate rows across all or subset of columns."""
    total = df.count()
    distinct = df.dropDuplicates(subset).count() if subset else df.distinct().count()
    dupes = total - distinct
    status = "PASS" if dupes == 0 else "FAIL"
    return CheckResult("duplicates", status, f"{dupes} duplicate rows", str(dupes), "0")


def validate_business_rule(df: DataFrame, rule_expr: str,
                            rule_name: str) -> CheckResult:
    """Validate a custom business rule SQL expression (must evaluate to boolean)."""
    violations = df.filter(f"NOT ({rule_expr})").count()
    status = "PASS" if violations == 0 else "FAIL"
    return CheckResult(f"biz_{rule_name}", status,
                       f"{violations} violations for rule: {rule_expr}", str(violations), "0")
