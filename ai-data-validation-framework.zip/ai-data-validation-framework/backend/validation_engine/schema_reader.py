"""
validation_engine/schema_reader.py
Reads schema metadata from Oracle, Hive, or Azure ADLS
"""

from typing import Dict, Any


class SchemaReader:
    """
    Unified schema reader for Oracle, Hive, and Azure ADLS.
    Returns {column_name: data_type} dict.
    """

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.source_type = config.get("type")  # oracle | hive | adls

    def read(self) -> Dict[str, str]:
        if self.source_type == "oracle":
            return self._read_oracle()
        elif self.source_type == "hive":
            return self._read_hive()
        elif self.source_type == "adls":
            return self._read_adls()
        raise ValueError(f"Unsupported source type: {self.source_type}")

    def _read_oracle(self) -> Dict[str, str]:
        import cx_Oracle
        dsn = cx_Oracle.makedsn(
            self.config["host"], self.config.get("port", 1521),
            service_name=self.config["service"]
        )
        conn = cx_Oracle.connect(self.config["user"], self.config["password"], dsn)
        cur = conn.cursor()
        cur.execute("""
            SELECT COLUMN_NAME, DATA_TYPE
            FROM ALL_TAB_COLUMNS
            WHERE TABLE_NAME = :tbl
            ORDER BY COLUMN_ID
        """, tbl=self.config["table"].upper())
        result = {row[0]: row[1] for row in cur.fetchall()}
        conn.close()
        return result

    def _read_hive(self) -> Dict[str, str]:
        from pyhive import hive
        conn = hive.Connection(
            host=self.config["host"],
            port=self.config.get("port", 10000),
            database=self.config.get("database", "default")
        )
        cur = conn.cursor()
        cur.execute(f"DESCRIBE {self.config['table']}")
        return {row[0]: row[1] for row in cur.fetchall() if row[0] and not row[0].startswith("#")}

    def _read_adls(self) -> Dict[str, str]:
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.getOrCreate()
        path = (
            f"abfss://{self.config['container']}@"
            f"{self.config['account']}.dfs.core.windows.net/{self.config['path']}"
        )
        df = spark.read.parquet(path)
        return dict(df.dtypes)
