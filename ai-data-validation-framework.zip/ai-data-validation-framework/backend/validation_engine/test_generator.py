"""
validation_engine/test_generator.py
AI-powered test case generation using Claude API (claude-sonnet-4-20250514)
"""

import anthropic
import json
from dataclasses import dataclass
from typing import List, Dict, Any
from .schema_reader import SchemaReader


@dataclass
class TestCase:
    id: str
    name: str
    check_type: str
    expression: str
    expected: str


class TestCaseGenerator:
    """
    Uses Claude API to dynamically generate validation test cases
    based on schema comparison between source and target systems.
    Supports Oracle, Hive, and Azure ADLS Gen2.
    """

    def __init__(self, source_config: Dict[str, Any], target_config: Dict[str, Any]):
        self.client = anthropic.Anthropic()
        self.source = SchemaReader(source_config)
        self.target = SchemaReader(target_config)

    def generate(self) -> List[TestCase]:
        """Generate test cases from schema diff using Claude API."""
        src_schema = self.source.read()
        tgt_schema = self.target.read()
        schema_diff = self._compute_diff(src_schema, tgt_schema)

        prompt = f"""You are a senior data quality engineer.
Given this schema diff between source and target systems:
{json.dumps(schema_diff, indent=2)}

Generate comprehensive validation test cases covering:
- Row count validation
- Null value checks (per column)
- Duplicate / PK integrity checks
- Data type mismatch checks
- Business rule validations

Return ONLY a valid JSON array. Each object must have:
  id (string), name (string), check_type (string),
  expression (string), expected (string)

No extra text, no markdown fences."""

        response = self.client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=2000,
            messages=[{"role": "user", "content": prompt}]
        )

        raw_text = response.content[0].text.strip()
        raw = json.loads(raw_text)
        return [TestCase(**tc) for tc in raw]

    def _compute_diff(self, src: Dict, tgt: Dict) -> Dict:
        """Compute schema differences between source and target."""
        added_cols = [c for c in src if c not in tgt]
        removed_cols = [c for c in tgt if c not in src]
        type_diffs = {
            k: {"source": src[k], "target": tgt[k]}
            for k in src
            if k in tgt and src[k] != tgt[k]
        }
        return {
            "added_in_source_missing_in_target": added_cols,
            "removed_from_source_present_in_target": removed_cols,
            "type_mismatches": type_diffs,
        }
