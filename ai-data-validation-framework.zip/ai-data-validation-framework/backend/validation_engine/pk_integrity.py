"""
validation_engine/pk_integrity.py
Primary key integrity checks: uniqueness and not-null on PK column
"""

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from typing import List
from .row_count import CheckResult


def check_pk(df: DataFrame, pk_col: str, label: str = "") -> List[CheckResult]:
    """
    Run both PK null check and PK uniqueness check.
    Returns a list of two CheckResult objects.
    """
    results = []
    total = df.count()

    # 1. Null check on PK
    pk_nulls = df.filter(F.col(pk_col).isNull()).count()
    results.append(CheckResult(
        check=f"pk_null_{pk_col}_{label}",
        status="PASS" if pk_nulls == 0 else "FAIL",
        detail=f"{pk_nulls} null values in PK column '{pk_col}'",
        source_val=str(pk_nulls),
        target_val="0"
    ))

    # 2. Uniqueness check on PK
    distinct = df.select(pk_col).distinct().count()
    dupes = total - distinct
    results.append(CheckResult(
        check=f"pk_unique_{pk_col}_{label}",
        status="PASS" if dupes == 0 else "FAIL",
        detail=f"{dupes} duplicate PK values in '{pk_col}'",
        source_val=str(dupes),
        target_val="0"
    ))

    return results
