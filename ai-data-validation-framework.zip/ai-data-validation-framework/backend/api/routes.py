"""
api/routes.py
FastAPI REST endpoints for triggering and querying validation runs
"""

import time
import json
from fastapi import FastAPI, BackgroundTasks, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from .models import RunRequest, RunResponse, RunListItem
from ..validation_engine.test_generator import TestCaseGenerator
from ..validation_engine.row_count import (
    validate_row_count, validate_nulls,
    validate_pk_integrity, validate_dtype_match
)
from ..validation_engine.null_checker import check_all_nulls
from ..validation_engine.duplicate_finder import check_duplicates
from ..validation_engine.pk_integrity import check_pk
from ..validation_engine.dtype_validator import validate_types
from ..connectors.oracle_conn import OracleConnector
from ..connectors.hive_conn import HiveConnector
from ..connectors.azure_conn import AzureADLSConnector
from ..report_engine.report_builder import ReportBuilder

app = FastAPI(
    title="AI Data Validation API",
    description="AI-powered automated data validation across Oracle, Hive, and Azure ADLS",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

CONNECTOR_MAP = {
    "oracle": OracleConnector,
    "hive":   HiveConnector,
    "adls":   AzureADLSConnector,
}


def _get_connector(source_type: str):
    cls = CONNECTOR_MAP.get(source_type)
    if not cls:
        raise ValueError(f"Unknown source type: {source_type}")
    return cls()


def _run_validation_task(run_id: str, req: RunRequest):
    """Background task: run full validation pipeline and save report."""
    src_conn = _get_connector(req.source_type)
    tgt_conn = _get_connector(req.target_type)

    all_results = []
    for table in req.tables:
        src_df = src_conn.read_spark(table)
        tgt_df = tgt_conn.read_parquet_spark(table)
        pk = req.pk_columns.get(table, "id")

        # Generate AI test cases
        gen = TestCaseGenerator(
            {"type": req.source_type, "table": table},
            {"type": req.target_type, "table": table}
        )
        ai_tests = gen.generate()
        print(f"[{run_id}] AI generated {len(ai_tests)} test cases for {table}")

        # Run standard checks
        all_results += [
            validate_row_count(src_df, tgt_df, req.row_count_threshold),
            validate_nulls(src_df, pk, threshold=0.0),
            *check_pk(src_df, pk, "source"),
            *check_pk(tgt_df, pk, "target"),
            *check_all_nulls(tgt_df, req.null_threshold),
            check_duplicates(tgt_df, [pk], "target"),
            *validate_types(src_df, tgt_df),
        ]

    metadata = {
        "tables": req.tables,
        "source_type": req.source_type,
        "target_type": req.target_type,
        "tags": req.tags,
    }
    ReportBuilder(all_results, metadata).save(run_id)


@app.post("/api/v1/validate", response_model=dict, status_code=202)
async def trigger_validation(req: RunRequest, bg: BackgroundTasks):
    """Trigger a new async validation run."""
    run_id = f"RUN-{int(time.time())}"
    bg.add_task(_run_validation_task, run_id, req)
    return {"run_id": run_id, "status": "queued", "message": "Validation started"}


@app.get("/api/v1/runs/{run_id}", response_model=RunResponse)
async def get_run(run_id: str):
    """Fetch full results for a specific validation run."""
    adls = AzureADLSConnector()
    reports = adls.list_reports()
    match = next((r for r in reports if run_id in r), None)
    if not match:
        raise HTTPException(status_code=404, detail=f"Run {run_id} not found")
    # In production: read from ADLS and return
    return {"run_id": run_id, "status": "fetched"}


@app.get("/api/v1/runs", response_model=list)
async def list_runs(limit: int = 20):
    """List recent validation runs."""
    adls = AzureADLSConnector()
    return adls.list_reports()[:limit]


@app.get("/health")
async def health():
    return {"status": "ok", "service": "ai-data-validation"}


@app.get("/")
async def root():
    return {"message": "AI Data Validation Framework API v1.0.0"}
