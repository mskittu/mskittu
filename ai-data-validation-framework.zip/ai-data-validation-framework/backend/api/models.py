"""
api/models.py
Pydantic request/response models for the validation REST API
"""

from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from enum import Enum


class SourceType(str, Enum):
    oracle = "oracle"
    hive   = "hive"
    adls   = "adls"


class CheckStatus(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    WARN = "WARN"


class RunRequest(BaseModel):
    source_type: SourceType
    target_type: SourceType
    tables: List[str] = Field(..., min_items=1)
    pk_columns: Optional[Dict[str, str]] = {}
    null_threshold: Optional[float] = 0.05
    row_count_threshold: Optional[float] = 0.001
    tags: Optional[Dict[str, str]] = {}


class CheckResultResponse(BaseModel):
    check: str
    status: CheckStatus
    detail: str
    source_val: Optional[str] = ""
    target_val: Optional[str] = ""


class RunSummary(BaseModel):
    total_checks: int
    passed: int
    failed: int
    warnings: int
    pass_rate: float


class RunResponse(BaseModel):
    run_id: str
    timestamp: str
    overall_status: CheckStatus
    metadata: Dict[str, Any] = {}
    summary: RunSummary
    checks: List[CheckResultResponse]


class RunListItem(BaseModel):
    run_id: str
    timestamp: str
    overall_status: CheckStatus
    pass_rate: float
    total_checks: int
