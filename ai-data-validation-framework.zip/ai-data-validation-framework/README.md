# AI-Powered Automated Data Validation Framework

Validates data across Oracle, Hive, and Azure ADLS Gen2 using Claude AI
to auto-generate test cases from schema diffs.

## Stack
- **AI**: Claude API (Anthropic) — test case generation
- **Processing**: PySpark — row counts, nulls, duplicates, type checks
- **Connectors**: cx_Oracle, PyHive, Azure ADLS Gen2 SDK
- **Quality**: dbt, Great Expectations
- **Orchestration**: Apache Airflow
- **API**: FastAPI + Uvicorn
- **Frontend**: React dashboard

## Quick Start
```bash
git clone <repo>
cd ai-data-validation-framework
pip install -r requirements.txt
cp .envire/.env.example .env   # fill in your credentials
python backend/main.py
```

## API Endpoints
| Method | Path | Description |
|--------|------|-------------|
| POST | /api/v1/validate | Trigger validation run |
| GET  | /api/v1/runs/{id} | Get run results |
| GET  | /api/v1/runs | List recent runs |
| GET  | /health | Health check |
