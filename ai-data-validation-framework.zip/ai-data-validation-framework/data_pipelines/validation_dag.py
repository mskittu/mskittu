"""
data_pipelines/validation_dag.py
Apache Airflow DAG — schedules the full validation pipeline daily at 8AM
"""

from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.email import EmailOperator
from airflow.utils.dates import days_ago
from datetime import timedelta
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from backend.validation_engine.test_generator import TestCaseGenerator
from backend.validation_engine.row_count import (
    validate_row_count, validate_nulls,
    validate_pk_integrity, validate_dtype_match
)
from backend.validation_engine.null_checker import check_all_nulls
from backend.validation_engine.duplicate_finder import check_duplicates
from backend.validation_engine.pk_integrity import check_pk
from backend.validation_engine.dtype_validator import validate_types
from backend.connectors.oracle_conn import OracleConnector
from backend.connectors.azure_conn import AzureADLSConnector
from backend.report_engine.report_builder import ReportBuilder

# Tables and their PK columns
VALIDATION_TARGETS = {
    "CUST_MASTER":   "CUST_ID",
    "ORDERS_FACT":   "ORDER_ID",
    "PRODUCT_DIM":   "PRODUCT_ID",
    "EMPLOYEE_HR":   "EMP_ID",
    "FINANCE_TXN":   "TXN_ID",
}

default_args = {
    "owner":            "data-engineering",
    "depends_on_past":  False,
    "retries":          2,
    "retry_delay":      timedelta(minutes=5),
    "email_on_failure": True,
    "email":            ["data-team@company.com"],
}


def read_schema(**ctx):
    """Task 1: Read source schemas from Oracle."""
    oracle = OracleConnector()
    oracle.connect()
    schemas = {}
    for table in VALIDATION_TARGETS:
        schemas[table] = oracle.get_schema(table).to_dict()
    oracle.close()
    ctx["ti"].xcom_push(key="schemas", value=schemas)
    print(f"[read_schema] Read {len(schemas)} table schemas")


def generate_test_cases(**ctx):
    """Task 2: Use Claude API to generate AI test cases per table."""
    schemas = ctx["ti"].xcom_pull(key="schemas", task_ids="read_schema")
    all_tests = {}
    for table in VALIDATION_TARGETS:
        gen = TestCaseGenerator(
            {"type": "oracle", "table": table},
            {"type": "adls",   "table": table}
        )
        tests = gen.generate()
        all_tests[table] = [t.__dict__ for t in tests]
        print(f"[generate_test_cases] {table}: {len(tests)} AI test cases generated")
    ctx["ti"].xcom_push(key="test_cases", value=all_tests)


def run_spark_validation(**ctx):
    """Task 3: Execute PySpark validation checks against source and target."""
    oracle = OracleConnector(); oracle.connect()
    adls   = AzureADLSConnector()
    all_results = []

    for table, pk in VALIDATION_TARGETS.items():
        print(f"[run_spark_validation] Validating {table}...")
        src_df = oracle.read_spark(table)
        tgt_df = adls.read_parquet_spark(f"data/{table.lower()}")

        results = [
            validate_row_count(src_df, tgt_df),
            validate_nulls(src_df, pk, threshold=0.0),
            *check_pk(src_df, pk, "source"),
            *check_pk(tgt_df, pk, "target"),
            *check_all_nulls(tgt_df, threshold=0.05),
            check_duplicates(tgt_df, [pk], "target"),
            *validate_types(src_df, tgt_df),
        ]
        all_results.extend(results)
        print(f"[run_spark_validation] {table}: {len(results)} checks run")

    oracle.close()
    ctx["ti"].xcom_push(key="result_count", value=len(all_results))
    # In production: serialize results to temp storage for next task
    return len(all_results)


def build_and_save_report(**ctx):
    """Task 4: Build final report and save to ADLS."""
    run_id = ctx["run_id"]
    result_count = ctx["ti"].xcom_pull(key="result_count", task_ids="run_spark_validation")
    print(f"[build_and_save_report] Building report for run {run_id}, {result_count} checks")
    # In production: deserialize from temp storage and call ReportBuilder.save()


with DAG(
    dag_id="ai_data_validation_pipeline",
    default_args=default_args,
    description="AI-powered automated data validation across Oracle → Azure ADLS",
    schedule_interval="0 8 * * *",   # Daily at 8:00 AM
    start_date=days_ago(1),
    catchup=False,
    max_active_runs=1,
    tags=["validation", "ai", "data-quality", "pyspark"],
) as dag:

    t1 = PythonOperator(task_id="read_schema",         python_callable=read_schema)
    t2 = PythonOperator(task_id="generate_test_cases", python_callable=generate_test_cases)
    t3 = PythonOperator(task_id="run_spark_validation",python_callable=run_spark_validation)
    t4 = PythonOperator(task_id="build_report",        python_callable=build_and_save_report)

    t1 >> t2 >> t3 >> t4
