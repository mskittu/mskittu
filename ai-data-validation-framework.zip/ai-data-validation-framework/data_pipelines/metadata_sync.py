"""
data_pipelines/metadata_sync.py
Syncs schema metadata using dbt and Great Expectations
"""

import subprocess
import os
from pathlib import Path


DBT_PROJECT_DIR = Path(__file__).parent.parent / "dbt_project"
GE_DIR = Path(__file__).parent.parent / "great_expectations"


def run_dbt_test(model: str = None):
    """Run dbt tests for all models or a specific model."""
    cmd = ["dbt", "test", "--project-dir", str(DBT_PROJECT_DIR)]
    if model:
        cmd += ["--models", model]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"[dbt] FAILED:\n{result.stderr}")
    else:
        print(f"[dbt] PASSED:\n{result.stdout}")
    return result.returncode == 0


def run_dbt_source_freshness():
    """Check source freshness via dbt."""
    cmd = ["dbt", "source", "freshness", "--project-dir", str(DBT_PROJECT_DIR)]
    result = subprocess.run(cmd, capture_output=True, text=True)
    print(result.stdout)
    return result.returncode == 0


def run_great_expectations(suite: str, batch_path: str):
    """
    Run a Great Expectations checkpoint for a named expectation suite.
    suite: name of the .json expectation suite
    batch_path: path to the data file or table
    """
    import great_expectations as ge
    context = ge.data_context.DataContext(str(GE_DIR))
    result = context.run_checkpoint(checkpoint_name=suite)
    success = result["success"]
    print(f"[Great Expectations] Suite '{suite}': {'PASS' if success else 'FAIL'}")
    return success


def generate_ge_suite_from_profile(df, suite_name: str):
    """
    Auto-generate a Great Expectations suite by profiling a Pandas/Spark DataFrame.
    """
    import great_expectations as ge
    ge_df = ge.from_pandas(df.toPandas() if hasattr(df, "toPandas") else df)
    suite = ge_df.profile(profiler=ge.profile.BasicDatasetProfiler)
    print(f"[Great Expectations] Suite '{suite_name}' auto-generated with "
          f"{len(suite.expectations)} expectations")
    return suite
