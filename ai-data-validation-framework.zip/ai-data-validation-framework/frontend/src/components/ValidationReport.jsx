import React, { useEffect, useState } from "react";

export default function ValidationReport({ runId }) {
  const [report, setReport] = useState(null);

  useEffect(() => {
    fetch(`/api/v1/runs/${runId}`)
      .then(r => r.json())
      .then(setReport);
  }, [runId]);

  if (!report) return <div>Loading...</div>;

  const statusColor = { PASS: "green", FAIL: "red", WARN: "orange" };

  return (
    <div style={{ padding: 24 }}>
      <h2>Run: {report.run_id}</h2>
      <p style={{ color: statusColor[report.overall_status], fontWeight: "bold", fontSize: 20 }}>
        {report.overall_status}
      </p>
      <p>Pass Rate: {(report.summary.pass_rate * 100).toFixed(1)}%</p>
      <table border="1" cellPadding={8} style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr><th>Check</th><th>Status</th><th>Detail</th><th>Source</th><th>Target</th></tr>
        </thead>
        <tbody>
          {report.checks.map(c => (
            <tr key={c.check}>
              <td>{c.check}</td>
              <td style={{ color: statusColor[c.status], fontWeight: "bold" }}>{c.status}</td>
              <td>{c.detail}</td>
              <td>{c.source_val}</td>
              <td>{c.target_val}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
