import React from "react";

export default function SchemaCompare({ sourceCols, targetCols }) {
  const all = [...new Set([...Object.keys(sourceCols), ...Object.keys(targetCols)])];
  return (
    <table border="1" cellPadding={8} style={{ width: "100%", borderCollapse: "collapse" }}>
      <thead>
        <tr><th>Column</th><th>Source Type</th><th>Target Type</th><th>Match</th></tr>
      </thead>
      <tbody>
        {all.map(col => {
          const src = sourceCols[col] || "MISSING";
          const tgt = targetCols[col] || "MISSING";
          const match = src === tgt;
          return (
            <tr key={col}>
              <td>{col}</td>
              <td>{src}</td>
              <td>{tgt}</td>
              <td style={{ color: match ? "green" : "red" }}>{match ? "✓" : "✕"}</td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}
